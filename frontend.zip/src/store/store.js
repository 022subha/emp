import { configureStore } from '@reduxjs/toolkit'

import uiSlice from './slices/uiSlice'
import planSlice from './slices/planSlice'
import userSlice from './slices/userSlice'
import masterReducer from './slices/masterSlice'
import supplierSlice from './slices/supplierSlice'
import customizerSlice from './slices/customizerSlice'

export const store = configureStore({
  reducer: {
    ui: uiSlice,
    user: userSlice,
    plan: planSlice,
    master: masterReducer,
    supplier: supplierSlice,
    customizer: customizerSlice
  }
})

export default store
