import React from 'react'
import { Card, CardBody, CardTitle, CardText, Button, Container, Row, Col, Label } from 'reactstrap'
import { IoRocketSharp } from 'react-icons/io5'
import { FaEye } from 'react-icons/fa'
import { IoIosSend } from 'react-icons/io'
import { BiSolidPlaneAlt } from 'react-icons/bi'
import './MyPlanStyles.scss'

const MyPlan = () => {
  return (
    <Card className="planCardWrapper border p-4 rounded bg-transparent shadow-none">
      <Row className="justify-content-center">
        {/* Selected Plan Card */}
        <Col
          xs={12}
          className="mb-4 leftAside">
          <Row>
            <Col xs="12">
              <h1 className="display-6">My Plan</h1>
              <h5>Manage your mjPROConnect subscription plan</h5>
            </Col>
            <Col
              xs="12"
              className="pt-5 position-relative">
              <Card className="selectedPlanCard">
                <CardBody>
                  <CardTitle
                    tag="h5"
                    className="selectedPlanTitle">
                    <IoRocketSharp /> Enterprise Plan: <span>10,000/month</span>
                  </CardTitle>
                  <Row>
                    <Col
                      sm="6"
                      md="4">
                      <Label className="fw-bold mb-0">Plan selected</Label> <p>12 August 2024</p>
                    </Col>
                    <Col
                      sm="6"
                      md="4">
                      <Label className="fw-bold mb-0">Next payment</Label> <p>12 December 2024</p>
                    </Col>
                    <Col
                      sm="6"
                      md="4">
                      <Label className="fw-bold mb-0">Plan ends</Label> <p>12 February 2025</p>
                    </Col>
                    <Col
                      sm="6"
                      md="4">
                      <Label className="fw-bold mb-0">Last invoice</Label> <p>15 November 2024. </p>
                    </Col>
                    <Col
                      sm="6"
                      md="4">
                      <Label className="fw-bold mb-0">Invoice number</Label> <p>INV15082024</p>
                    </Col>
                    <Col
                      xs="12"
                      md="4"
                      xl="12">
                      <Button className="mt-3 paymentHistoryBtn">
                        <FaEye /> <span className="ms-2">Payment History</span>
                      </Button>
                    </Col>
                  </Row>
                  <p className="fw-bold fs-6 text-light mt-4 mb-0">
                    <i>**Renew your plan before 12-02-2025 for seamless transaction**</i>
                  </p>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Col>
        <Col
          xs="12"
          className="rightAside">
          <Row>
            {/* Basic Plan Card */}
            <Col
              md={6}
              className="mb-4 pt-5 position-relative">
              <div className="badge rounded-pill bg-dark px-4 py-2 fs-6 cardPill">
                <IoIosSend /> <span className="ms-2"> Basic Plan</span>
              </div>
              <Card
                className="shadow"
                style={{ border: '1px solid #3B3B3B' }}>
                <CardBody>
                  <CardTitle
                    tag="h5"
                    className="display-6">
                    Free
                  </CardTitle>
                  <CardText>
                    <p>Ideal for small businesses or suppliers starting out who want to establish their presence and begin connecting with buyers.</p>
                    <ol>
                      <li className="fw-bold mb-2">
                        Access to standard supplier profile: Showcase your products and services with basic information (contact details, product
                        categories).
                      </li>
                      <li className="fw-bold mb-2">Ability to post 1 Ad in the Advertisement Repository per month.</li>
                      <li className="fw-bold mb-2">Basic ad slot for 30-day visibility within the marketplace.</li>
                      <li className="fw-bold mb-2">View basic ad performance metrics: Number of views (how many times your ad was seen).</li>
                    </ol>
                  </CardText>
                  <Button
                    color="dark"
                    className="d-block w-100 border border-2">
                    Start Free
                  </Button>
                </CardBody>
              </Card>
            </Col>

            {/* Premium Plan Card */}
            <Col
              md={6}
              className="mb-4 pt-5 position-relative">
              <div className="badge rounded-pill px-4 py-2 fs-6 cardPill premium">
                <BiSolidPlaneAlt /> <span className="ms-2"> Premium Plan</span>
              </div>
              <Card
                className="shadow"
                style={{ border: '1px solid #A211D2' }}>
                <CardBody>
                  <CardTitle
                    tag="h5"
                    style={{ color: '#6f42c1' }}
                    className="display-6">
                    ₹3,000/month
                  </CardTitle>
                  <CardText>
                    <p>Best suited for growing suppliers who want increased visibility and advanced advertising options to reach more buyers.</p>
                    <ol>
                      <li className="fw-bold mb-2">
                        Access to an enhanced supplier profile: Include additional details to better showcase your business.
                      </li>
                      <li className="fw-bold mb-2">Ability to post 5 Ads per month with higher placement in the Advertisement Repository.</li>
                      <li className="fw-bold mb-2">Ads placed in premium ad slots for 30-day visibility with higher priority for targeted buyers.</li>
                      <li className="fw-bold mb-2">Access to advanced ad performance analytics: Number of views, Buyer Info will be displayed</li>
                    </ol>
                  </CardText>
                  <Button
                    color="primary"
                    className="d-block w-100 premiumBtn">
                    Get Premium
                  </Button>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Col>
      </Row>
    </Card>
  )
}

export default MyPlan
