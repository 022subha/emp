import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { FaCheckCircle } from 'react-icons/fa'
import { useNavigate } from 'react-router-dom'
import { MdRocketLaunch } from 'react-icons/md'
import { Badge, Card, CardBody, Button, CardTitle, CardText, Container, ListGroup, ListGroupItem } from 'reactstrap'
import { setPlanDuration } from '../../../store/slices/planSlice'

const EnterpriseCard = () => {
  const dispatch = useDispatch()
  const planId = useSelector((state) => state.plan.planId)
  const planDuration = useSelector((state) => state.plan.planDuration)
  const subscriptionPlans = useSelector((state) => state.master.subscriptionPlans)

  const plan = subscriptionPlans.find((item) => item.id === planId)

  return (
    <Container
      fluid
      className="ps-0">
      <Card
        body
        color="primary"
        className="selected-plan-card__container GlossBg"
        outline>
        <Badge
          pill
          bg="light"
          className="enterprise selected-plan-card__badge fs-3">
          <MdRocketLaunch /> {plan?.planName} Plan
        </Badge>
        <CardBody className="p-0">
          {/* <CardTitle tag="h5">
            <h3 className="display-5 text-light mb-0">{new Intl.NumberFormat('en-IN').format(subscriptionPlans[0]?.planPrice)}/month</h3>
          </CardTitle> */}
          <CardText className="text-light fs-4 fw-bold mb-2">
            For large suppliers who want maximum visibility, detailed analytics, and the ability to post multiple high-impact ads to attract top
            buyers.
          </CardText>
          <CardText>
            <ListGroup numbered>
              <ListGroupItem className="px-0 border-0">
                Access to an enhanced supplier profile: Include additional details to better showcase your business.
              </ListGroupItem>
              <ListGroupItem className="px-0 border-0">
                Ability to post {plan?.adCountPerMonth} Ads/month in the Advertisement Repository, allowing for maximum exposure.
              </ListGroupItem>
              <ListGroupItem className="px-0 border-0">
                Ads placed in featured ad slots with 60-day visibility and guaranteed top placement in ad rotations.
              </ListGroupItem>
              <ListGroupItem className="px-0 border-0">
                Access to full ad analytics:
                <ul>
                  <li>Number of views, Viewer</li>
                  <li>Info will be displayed</li>
                  <li>Demographic breakdown of viewers (location, industry).</li>
                </ul>
              </ListGroupItem>
              <ListGroupItem className="px-0 border-0">
                Highest-priority listing in the supplier search results for maximum exposure to buyers.
              </ListGroupItem>
            </ListGroup>
          </CardText>
        </CardBody>
        <div className="d-flex justify-content-center align-items-center gap-4">
          <Button className="enterprise selected-btn">
            <FaCheckCircle className="me-2" />
            {planDuration === 1 ? '6 month' : '12 month'} plan selected
          </Button>

          {planDuration === 1 ? (
            <Button
              // className="w-auto border-0 fs-4 fw-bold Premium"
              className="w-auto fs-4  fw-bold Premium"
              onClick={() => {
                dispatch(setPlanDuration(2))
              }}>
              Switch to 12 month plan
            </Button>
          ) : (
            <Button
              className="w-auto fs-4  fw-bold Premium"
              onClick={() => {
                dispatch(setPlanDuration(1))
              }}>
              Switch to 6 month plan
            </Button>
          )}
        </div>
      </Card>
    </Container>
  )
}

const PlanCardSelected = () => {
  const planId = useSelector((state) => state.plan.planId)

  const navigate = useNavigate()

  useEffect(() => {
    if (planId === -1) {
      navigate('/')
    }
  }, [planId])

  return (
    <div>
      <EnterpriseCard />
    </div>
  )
}

export default PlanCardSelected
