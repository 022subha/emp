import React from 'react'
import { useSelector } from 'react-redux'
import { Card, CardTitle, CardText, Button, Row, Col } from 'reactstrap'

export default function AvailableSlots({ toggle }) {
  const adSlotsRemaining = useSelector((state) => state.supplier.adSlotsRemaining)

  return (
    <div>
      <Row>
        {Array.from({ length: adSlotsRemaining })
          .slice(0, 6)
          .map((item) => (
            <Col
              xs={12}
              sm={6}
              xl={4}
              xxl={2}>
              <Card
                body
                className="my-2 available-slots__card">
                <CardTitle
                  tag="h6"
                  className="fw-bold">
                  Slot Available to Use
                </CardTitle>
                <CardText className="mb-4">This ad slot is currently unused.</CardText>
                <Button
                  className="available-slots__button py-2"
                  onClick={() => toggle('2')}>
                  Use
                </Button>
              </Card>
            </Col>
          ))}
      </Row>
    </div>
  )
}
