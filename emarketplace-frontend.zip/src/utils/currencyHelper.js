export const formatIndianCurrency = (value) => {
  if (!value) return null

  if (value >= 10000000) {
    return (value / 10000000).toFixed(1) + ' Cr'
  } else if (value >= 100000) {
    return (value / 100000).toFixed(1) + ' lakhs'
  } else if (value >= 1000) {
    return (value / 1000).toFixed(1) + ' thousands'
  }
  return value.toString()
}
