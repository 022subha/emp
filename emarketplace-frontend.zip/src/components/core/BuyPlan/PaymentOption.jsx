import { toast } from 'react-toastify'
import React, { useState } from 'react'
import { MdDiscount } from 'react-icons/md'
import { useDispatch, useSelector } from 'react-redux'
import { changeLoginCode } from '../../../services/controller/authAPI'
import { makePayment, validateDiscountCode } from '../../../services/controller/paymentAPI'
import { Col, Row, Card, Form, Label, Table, Button, CardBody, Modal, ModalHeader, ModalBody, Input, ModalFooter, FormGroup } from 'reactstrap'

function PaymentOption({ otpVerificationToken }) {
  const dispatch = useDispatch()

  const planId = useSelector((state) => state.plan.planId)
  const planDuration = useSelector((state) => state.plan.planDuration)
  const subscriptionPlans = useSelector((state) => state.master.subscriptionPlans)

  const plan = subscriptionPlans.find((item) => item.id === planId)

  const [couponCode, setCouponCode] = useState('')
  const [discountPercentage, setDiscountPercentage] = useState(0)
  const [applied, setApplied] = useState(false)
  const [modalOpen, setModalOpen] = useState(false)
  const [loginCodeSelectionModal, setLoginCodeSelectionModal] = useState(false)
  const [loginCodeList, setLoginCodeList] = useState([])
  const [selectedAccount, setSelectedAccount] = useState('')
  const [loginCodeChangeToken, setLoginCodeChangeToken] = useState('')

  const toggleModal = () => setModalOpen((prev) => !prev)
  const toggleLoginCodeSelectionModal = () => setLoginCodeSelectionModal((prev) => !prev)

  const handleApplyCoupon = () => {
    dispatch(validateDiscountCode(couponCode)).then((res) => {
      if (res) {
        toast.success('Coupon Applied Successfully')
        setDiscountPercentage(res.discountPercentage)
        setApplied(true)
        toggleModal()
      }
    })
  }

  const handleRemoveCoupon = () => {
    setApplied(false)
    setDiscountPercentage(0)
    setCouponCode('')
  }

  const handleMakePayment = (amount, subscriptionId, planDuration) => {
    dispatch(makePayment(amount, subscriptionId, planDuration, otpVerificationToken)).then((res) => {
      console.log(res)
      if (res.mjPROLoginCodeList.length > 1) {
        setLoginCodeList(res.mjPROLoginCodeList)
        setLoginCodeChangeToken(res.jwtToken)
        toggleLoginCodeSelectionModal()
      }
    })
  }

  const handleChangeLoginCode = () => {
    dispatch(changeLoginCode(selectedAccount, loginCodeChangeToken)).then((success) => {})
  }

  return (
    <div
      style={{ minHeight: '100%' }}
      className="mt-3">
      <Form>
        <Row className="g-2">
          <Col>
            <Card className="mb-0 rounded-15">
              <CardBody className="d-flex flex-column">
                <Row className="mb-1">
                  <Col
                    md={8}
                    lg={9}>
                    <div className="d-flex justify-content-start align-items-center gap-2 h-100">
                      <MdDiscount style={{ fontSize: '20px', color: '00b1f1' }} />
                      {!applied ? (
                        <h3
                          className="m-0"
                          style={{ color: '#00b1f1' }}>
                          Apply Coupon
                        </h3>
                      ) : (
                        <div className="d-flex flex-column justify-content-center align-items-start">
                          <h3
                            className="m-0"
                            style={{ color: '#000' }}>
                            Coupon Applied
                          </h3>
                          <p
                            className="m-0"
                            style={{ color: '#00b1f1' }}>
                            You Saved ₹
                            {new Intl.NumberFormat('en-IN').format(
                              ((planDuration === 1 ? plan?.planPrice6Months : plan?.planPrice12Months) * discountPercentage) / 100.0
                            )}
                          </p>
                        </div>
                      )}
                    </div>
                  </Col>
                  <Col
                    md={4}
                    lg={3}>
                    {applied ? (
                      <Button
                        type="button"
                        className="btn"
                        color="danger"
                        block
                        onClick={handleRemoveCoupon}>
                        Remove
                      </Button>
                    ) : (
                      <Button
                        type="button"
                        color="brand-color"
                        className="btn outlined"
                        block
                        outline
                        onClick={toggleModal}>
                        Apply
                      </Button>
                    )}
                  </Col>
                </Row>

                <Table
                  className="no-wrap"
                  responsive>
                  <thead>
                    <tr>
                      <th className="p-1 pt-3 px-0 fs-4">Plan Price</th>
                      <th className="text-end p-1 pt-3 px-0 fs-5">
                        Rs {new Intl.NumberFormat('en-IN').format(planDuration === 1 ? plan?.planPrice6Months : plan?.planPrice12Months)}
                      </th>
                    </tr>
                    <tr>
                      <th className="p-1 px-0 fs-4">Coupon Discount</th>
                      <th className="text-end p-1 px-0 fs-5">
                        - Rs{' '}
                        {new Intl.NumberFormat('en-IN').format(
                          ((planDuration === 1 ? plan?.planPrice6Months : plan?.planPrice12Months) * discountPercentage) / 100.0
                        )}
                      </th>
                    </tr>
                    <tr>
                      <th className="pb-0 px-0 border-0"></th>
                      <th className="text-end pb-0 px-0 fs-2 fw-semibold border-0">
                        Rs{' '}
                        {new Intl.NumberFormat('en-IN').format(
                          (planDuration === 1 ? plan?.planPrice6Months : plan?.planPrice12Months) -
                            ((planDuration === 1 ? plan?.planPrice6Months : plan?.planPrice12Months) * discountPercentage) / 100.0
                        )}
                      </th>
                    </tr>
                  </thead>
                </Table>

                <Button
                  type="button"
                  className="btn px-4 border-0 py-2 mt-3 fs-4"
                  color="brand-color"
                  onClick={() => {
                    handleMakePayment(
                      (planDuration === 1 ? plan?.planPrice6Months : plan?.planPrice12Months) -
                        ((planDuration === 1 ? plan?.planPrice6Months : plan?.planPrice12Months) * discountPercentage) / 100.0,
                      planId,
                      planDuration
                    )
                  }}>
                  Pay ₹
                  {new Intl.NumberFormat('en-IN').format(
                    (planDuration === 1 ? plan?.planPrice6Months : plan?.planPrice12Months) -
                      ((planDuration === 1 ? plan?.planPrice6Months : plan?.planPrice12Months) * discountPercentage) / 100.0
                  )}
                </Button>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Form>

      <Modal
        centered={true}
        isOpen={modalOpen}
        toggle={toggleModal}>
        <ModalHeader
          tag="h4"
          style={{ color: '#00b1f1' }}
          toggle={toggleModal}>
          Apply Coupon
        </ModalHeader>
        <ModalBody>
          <Row className="">
            <Col md={9}>
              <Input
                type="text"
                placeholder="Enter Coupon Code"
                onChange={(e) => {
                  setCouponCode(e.target.value)
                }}
              />
            </Col>

            <Col md={3}>
              <Button
                type="button"
                className="btn w-100"
                color="brand-color"
                onClick={handleApplyCoupon}>
                Apply
              </Button>
            </Col>
          </Row>
        </ModalBody>
      </Modal>

      <Modal
        size="lg"
        centered={true}
        isOpen={loginCodeSelectionModal}
        toggle={toggleLoginCodeSelectionModal}
        className="d-flex justify-content-center align-items-center">
        <ModalHeader
          tag="h2"
          style={{ backgroundColor: '#00b1f1', color: '#fff' }}
          toggle={toggleLoginCodeSelectionModal}>
          Multiple accounts have been found against the provided email id
        </ModalHeader>
        <ModalBody>
          <h3
            className="mb-3"
            style={{ color: '#00b1f1', fontSize: '22px' }}>
            Please Select Your Account
          </h3>
          <FormGroup
            tag="fieldset"
            className="px-4">
            {loginCodeList.map((item) => (
              <FormGroup
                check
                key={item.maskUsercode}
                className="mb-2">
                <Label
                  check
                  style={{ fontSize: '20px', color: 'black' }}>
                  <Input
                    type="checkbox"
                    name="selectedAccount"
                    value={item.createid}
                    checked={selectedAccount == item.createid}
                    onChange={(e) => {
                      setSelectedAccount(e.target.value)
                    }}
                    className="cursor-pointer me-4"
                    style={selectedAccount === item.createid ? { backgroundColor: '#00b1f1' } : { borderColor: '#00b1f1' }}
                  />
                  {item.maskUsercode} ({item.maskFullName}, {item.maskContact})
                </Label>
              </FormGroup>
            ))}
          </FormGroup>
        </ModalBody>
        <ModalFooter>
          <Button
            color="brand-color"
            type="button"
            onClick={handleChangeLoginCode}
            disabled={!selectedAccount}>
            Submit
          </Button>
        </ModalFooter>
      </Modal>
    </div>
  )
}

export default PaymentOption
