import React from "react";
import "./AdContainerComponentsStyle.scss";
import { Outlet } from "react-router-dom";
import AdFilterBar from "./AdFilterBar";

const AdContainer = () => {
  return (
    <div
      className="h-100 w-100"
      style={{ paddingRight: "250px", overflow: "hidden" }}
    >
      <AdFilterBar />
      <Outlet />
    </div>
  );
};

export default AdContainer;
