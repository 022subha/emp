export const USER_TYPE = {
  SUPPLIER: "supplier",
  BUYER: "buyer",
};

export const SUPPLIER_STATUS = {
  DRAFT: "draft",
  PUBLISHED: "published",
};

export const CONTACT_TYPE = {
  PRIMARY: "primary",
  ADDITIONAL: "additional",
};
