import React from 'react'
import { FaTag } from 'react-icons/fa6'
import { MdShoppingBasket } from 'react-icons/md'
import { Card, CardBody, Button, Row, Col } from 'reactstrap'

const OfferCard = ({ showPlanSelectionPage }) => {
  return (
    <div>
      <Row className="mb-3">
        <Col>
          <h1 className="display-5 text-white fw-medium text-lg-start mb-1">What mjPROConnect Offers?</h1>
        </Col>
        <Col
          md="auto"
          className="text-center text-lg-end mt-2">
          <Button
            className="regBtn d-none d-sm-flex"
            onClick={showPlanSelectionPage}>
            Register
          </Button>
        </Col>
      </Row>

      <Row className="">
        <Col
          lg="6"
          style={{ paddingRight: 0 }}>
          <Card className="CustomOfferCard GlossBg">
            <CardBody className="p-0">
              <div className="d-flex align-items-center gap-3">
                <MdShoppingBasket className="card-area-icon mb-2" />
                <h2 className="display-6 text-white fw-bold">For Buyers</h2>
              </div>
              <ul className="custom-list">
                <li className="fs-4">Access a comprehensive list of vetted suppliers across industries. </li>
                <li className="fs-4">Discover unique offers that provide great value for your business. </li>
                <li className="fs-4">Find suppliers by category, location, ratings, and more with ease. </li>
                <li className="fs-4">Directly connect, negotiate, and manage discussions with suppliers. </li>
                <li className="fs-4">Make informed purchasing decisions with complete pricing transparency.</li>
              </ul>
            </CardBody>
          </Card>
        </Col>
        <Col lg="6">
          <Card className="CustomOfferCard GlossBg">
            <CardBody className="p-0">
              <div className="d-flex align-items-center gap-3">
                <FaTag className="card-area-icon mb-2" />
                <h2 className="display-6 text-white fw-bold">For Suppliers</h2>
              </div>
              <ul className="custom-list">
                <li className="fs-4">Connect with potential buyers actively seeking your products and services. </li>
                <li className="fs-4">Stand out with verified credentials and boost trust with buyers. </li>
                <li className="fs-4">Promote your offerings with customizable ads to attract more attention. </li>
                <li className="fs-4">Understand buyer interactions with view counts, engagement metrics, and more.</li>
              </ul>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </div>
  )
}

export default OfferCard
