import React from 'react'
import { Table } from 'reactstrap'

export default function ProductionCapacityTable({ productionCapacity }) {
  return (
    <div>
      <Table
        bordered
        responsive
        rounded>
        <thead>
          <tr>
            <th>Material</th>
            <th>Production Capacity</th>
            <th>UOM</th>
          </tr>
        </thead>
        <tbody>
          {productionCapacity &&
            productionCapacity.map((element) => {
              return (
                <tr key={element.id}>
                  <td
                    scope="row"
                    style={{ minWidth: '500px' }}>
                    {element?.materialName || 'Not available'}
                  </td>
                  <td>{element?.productionCapacity || 'Not available'}</td>
                  <td>{element?.productionCapacityUOM?.name || 'Not available'}</td>
                </tr>
              )
            })}
        </tbody>
      </Table>
    </div>
  )
}
