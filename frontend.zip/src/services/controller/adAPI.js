import { adEndPoints } from '../api'
import { toast } from 'react-toastify'
import { apiConnector } from '../apiConnector'
import { hideLoading, showLoading } from '../../store/slices/uiSlice'

const {
  postAd: postAdAPI,
  saveAdAsDraft: saveAdAsDraftAPI,
  myAds: myAdsAPI,
  myLiveAds: myLiveAdsAPI,
  adHistory,
  myDraftAds: myDraftAdsAPI,
  fetchAdDetail: fetchAdDetailAPI,
  deleteAd: deleteAdAPI,
  modifyAdAsDraft: modifyAdAsDraftAPI,
  postDraftAd: postDraftAdAPI,
  categoryWiseAdCount: categoryWiseAdCountAPI
} = adEndPoints

export const postAd = (data) => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('POST', postAdAPI, data)
      dispatch(hideLoading())
      toast.success(response.data.message)
      return true
    } catch (error) {
      dispatch(hideLoading())
      if (error.response) {
        toast.error(error?.response?.data?.message || 'Something Went Wrong')
      } else {
        console.log(error)
      }
    }

    return false
  }
}

export const saveAdAsDraft = (data) => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('POST', saveAdAsDraftAPI, data)
      dispatch(hideLoading())
      toast.success(response.data.message)
      return true
    } catch (error) {
      dispatch(hideLoading())
      if (error.response) {
        toast.error(error?.response?.data?.message || 'Something Went Wrong')
      } else {
        console.log(error)
      }
    }

    return false
  }
}

export const fetchAdDetail = (adId) => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('GET', fetchAdDetailAPI + '/' + adId)
      dispatch(hideLoading())
      return response.data.data.adDetail
    } catch (error) {
      dispatch(hideLoading())
      console.log(error)
    }
    return null
  }
}

export const fetchMyAds = () => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('GET', myAdsAPI)
      dispatch(hideLoading())
      return response.data.data.myAds
    } catch (error) {
      dispatch(hideLoading())

      console.log(error)
    }
    return []
  }
}

export const fetchMyLiveAds = () => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('GET', myLiveAdsAPI)
      dispatch(hideLoading())

      return response.data.data.myLiveAds
    } catch (error) {
      dispatch(hideLoading())
      console.log(error)
    }

    return []
  }
}

export const fetchAdHistory = () => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('GET', adHistory)
      dispatch(hideLoading())
      return response.data.data.myAdHistory
    } catch (error) {
      dispatch(hideLoading())
      console.log(error)
    }
    return []
  }
}

export const fetchMyDraftAdList = () => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('GET', myDraftAdsAPI)
      dispatch(hideLoading())
      return response.data.data.myDraftAds
    } catch (error) {
      dispatch(hideLoading())

      console.log(error)
    }

    return []
  }
}

export const modifyAdAsDraft = (adId, data) => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('PUT', modifyAdAsDraftAPI + '/' + adId, data)
      dispatch(hideLoading())
      toast.success(response.data.message)
      return true
    } catch (error) {
      dispatch(hideLoading())
      if (error.response) {
        toast.error(error?.response?.data?.message || 'Something Went Wrong')
      } else {
        console.log(error)
      }
    }

    return false
  }
}

export const postDraftAd = (adId, data) => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('POST', postDraftAdAPI + '/' + adId, data)
      dispatch(hideLoading())
      toast.success(response.data.message)
      return true
    } catch (error) {
      dispatch(hideLoading())
      if (error.response) {
        toast.error(error?.response?.data?.message || 'Something Went Wrong')
      } else {
        console.log(error)
      }
    }

    return false
  }
}
export const deleteAd = (adId) => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('DELETE', deleteAdAPI + '/' + adId)
      dispatch(hideLoading())
      toast.success(response.data.message)
      return true
    } catch (error) {
      dispatch(hideLoading())
      if (error.response) {
        toast.error(error?.response?.data?.message || 'Something Went Wrong')
      } else {
        console.log(error)
      }
    }
    return false
  }
}

export const getCategoryWiseAdCount = () => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('GET', categoryWiseAdCountAPI)
      dispatch(hideLoading())
      return response.data.data.adCounts
    } catch (error) {
      dispatch(hideLoading())
      console.log(error)
    }
    return { liveAd: 0, draftAd: 0, adHistory: 0 }
  }
}
