import React from 'react'
import { Table } from 'reactstrap'

export default function BusinessNatureTable({ natureOfBussiness, countriesDoingBussinessIn, top10Buyers, totalNumberOfEmployees, whyUs }) {
  return (
    <div>
      <Table
        bordered
        responsive
        rounded>
        <thead>
          <tr>
            <th>Nature of Business</th>
            <th>Countries Doing Business in</th>
            <th>Top 10 Buyers</th>
            <th>Total Number of Employess</th>
            <th>Why Us?</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">{natureOfBussiness}</th>
            <td>{countriesDoingBussinessIn?.join(', ')}</td>
            <td>
              <ul className="list-inline">
                {top10Buyers?.map((element, index) => {
                  return (
                    <>
                      <li className="list-inline-item">{element}</li>
                    </>
                  )
                })}
              </ul>
            </td>
            <td>{totalNumberOfEmployees}</td>
            <td>{whyUs}</td>
          </tr>
        </tbody>
      </Table>
    </div>
  )
}
