import React from 'react'
import { Table } from 'reactstrap'

export default function MaterialTable({ materialInformation }) {
  console.log('matrer', materialInformation)
  return (
    <div>
      <Table
        bordered
        responsive
        rounded>
        <thead>
          <tr>
            <th>Material</th>
            <th>Production Capacity</th>
            <th>UOM</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Address</th>
            <th>PIN</th>
          </tr>
        </thead>
        <tbody>
          {' '}
          {materialInformation &&
            materialInformation.map((element, index) => {
              return (
                <tr>
                  <th scope="row">{element?.materialName || 'Not available'}</th>
                  <td>{element?.productionCapacity || 'Not available'}</td>
                  <td>{element?.uom || 'Not available'}</td>
                  <td>{element?.country || 'Not available'}</td>
                  <td>{element?.state || 'Not available'}</td>
                  <td>{element?.city || 'Not available'}</td>
                  <td>{element?.address || 'Not available'}</td>
                  <td>{element?.pinCode || 'Not available'}</td>
                </tr>
              )
            })}
        </tbody>
      </Table>
    </div>
  )
}
