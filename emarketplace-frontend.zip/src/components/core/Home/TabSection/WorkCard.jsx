import React from 'react'
import { Card, CardBody, Button, Row, Col, Badge } from 'reactstrap'

export default function WorkCard({ showPlanSelectionPage }) {
  return (
    <div>
      <Row className="mb-3">
        <Col>
          <h1 className="display-5 text-white fw-medium text-lg-start mb-4">How mjPROConnect Works?</h1>
        </Col>
        <Col
          md="auto"
          className="text-center text-lg-start mt-2">
          <Button
            className="regBtn d-none d-sm-flex"
            onClick={showPlanSelectionPage}>
            Register
          </Button>
        </Col>
      </Row>

      <Row className="works-area">
        <Col
          md="6"
          lg="3"
          style={{ paddingRight: 0 }}>
          <Card className="CustomWorkCard GlossBg m-0">
            <CardBody className="p-0">
              <Badge
                color="light"
                className="custom-badge fw-bold"
                pill>
                1
              </Badge>
              <h2 className="text-white fw-bold mb-4">Register</h2>
              <p className="text-white fs-4">Quick and easy sign-up process for both buyers and suppliers.</p>
            </CardBody>
          </Card>
        </Col>

        <Col
          md="6"
          lg="3"
          style={{ paddingRight: 0 }}>
          <Card className="CustomWorkCard GlossBg m-0">
            <CardBody className="p-0">
              <Badge
                color="light"
                className="custom-badge fw-bold"
                pill>
                2
              </Badge>
              <h2 className="text-white fw-bold mb-4">Find Suppliers or Showcase Products</h2>
              <p className="text-white fs-4">
                Buyers can search through our extensive supplier database, while suppliers can showcase their offerings in our ad repository.
              </p>
            </CardBody>
          </Card>
        </Col>

        <Col
          md="6"
          lg="3"
          style={{ paddingRight: 0 }}>
          <Card className="CustomWorkCard GlossBg m-0">
            <CardBody className="p-0">
              <Badge
                color="light"
                className="custom-badge fw-bold"
                pill>
                3
              </Badge>
              <h2 className="text-white fw-bold mb-4">Connect & Do Business</h2>
              <p className="text-white fs-4">
                Buyers can directly contact suppliers for procurement or place bids, and suppliers can manage their ads and communications
                effortlessly.
              </p>
            </CardBody>
          </Card>
        </Col>

        <Col
          md="6"
          lg="3">
          <Card className="CustomWorkCard GlossBg m-0">
            <CardBody className="p-0">
              <Badge
                color="light"
                className="custom-badge fw-bold"
                pill>
                4
              </Badge>
              <h2 className="text-white fw-bold mb-4">Manage Everything in One Place</h2>
              <p className="text-white fs-4">Both buyers and suppliers have access to tools that help manage orders, ads, and interactions.</p>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </div>
  )
}
