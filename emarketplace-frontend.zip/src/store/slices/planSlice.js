import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  planId: -1,
  planDuration: -1
}

export const planSlice = createSlice({
  name: 'plan',
  initialState,
  reducers: {
    setPlanId: (state, action) => {
      state.planId = action.payload
    },

    setPlanDuration: (state, action) => {
      state.planDuration = action.payload
    }
  }
})

export const { setPlanId, setPlanDuration } = planSlice.actions

export default planSlice.reducer
