import {
  Row,
  Col,
  Form,
  Label,
  Input,
  Modal,
  Button,
  Popover,
  Spinner,
  FormGroup,
  Container,
  ModalBody,
  PopoverBody,
  ModalHeader,
  PopoverHeader
} from 'reactstrap'
import {
  PAN_REGEX,
  EMAIL_REGEX,
  MSME_NUMBER_REGEX,
  GSTIN_NUMBER_REGEX,
  PAN_HOLDER_DOB_REGEX,
  WHATSAPP_NUMBER_REGEX
} from '../../../utils/regexHelper'
import React, { useState } from 'react'
import './ProfilingComponentStyles.scss'
import { MdCancel, MdDelete } from 'react-icons/md'
import { INDIA_CODE } from '../../../../dotenv'
import AwardUploadSection from './AwardsUpload'
import OTPInputEmail from '../BuyPlan/OtpInputEmail'
import OTPInputMobile from '../BuyPlan/OtpInputMobile'
import { useDispatch, useSelector } from 'react-redux'
import { Controller, useFieldArray } from 'react-hook-form'
import { sendOtpToContactPerson } from '../../../services/controller/supplierAPI'
import { IoIosAdd, IoMdClose, IoMdInformationCircleOutline } from 'react-icons/io'
import { verifyOtpOfContactPerson } from '../../../services/controller/supplierAPI'
import { fetchCityList, fetchStateList } from '../../../services/controller/masterAPI'
import { verifyPAN, verifyMSME, verifyGSTIN } from '../../../services/controller/verificationAPI'
import { toast } from 'react-toastify'

const OrganizationForm = ({
  watch,
  errors,
  control,
  register,
  setValue,
  getValues,
  panHandleSubmit,
  contactErrors,
  contactControl,
  contactSetValue,
  contactHandleSubmit,
  changeOrgLogoHandler,
  orgAwards,
  setOrgAwards
}) => {
  const dispatch = useDispatch()

  const countryId = watch('countryId', '')
  const stateId = watch('stateId', '')
  const isMsme = watch('isMsme', 'N')
  const hasGstin = watch('hasGstin', 'Y')

  const {
    fields: gstinFields,
    append: addGstin,
    remove: removeGstin
  } = useFieldArray({
    control,
    name: 'gstinInformation'
  })

  const {
    fields: contactPersonFields,
    append: addContactPerson,
    remove: removeContactPerson
  } = useFieldArray({
    control,
    name: 'contactDetails'
  })

  const {
    fields: contactVerifyFields,
    append: addContactVerify,
    remove: removeContactVerify
  } = useFieldArray({ control: contactControl, name: 'contactDetails' })

  const currentYear = new Date().getFullYear()
  const years = Array.from({ length: 501 }, (_, i) => currentYear - i)

  const cities = useSelector((state) => state.master.cityList)
  const states = useSelector((state) => state.master.stateList)
  const countries = useSelector((state) => state.master.countryList)
  const bussinessSclaes = useSelector((state) => state.master.bussinessScales)

  const [modal, setModal] = useState(false)
  const [contactIndex, setContactIndex] = useState(-1)
  const [emailOtp, setEmailOtp] = useState(new Array(6).fill(''))
  const [whatsappNumberOtp, setWhatsappNumberOtp] = useState(new Array(6).fill(''))
  const [uinPopoverOpen, setUinPopoverOpen] = useState(false)
  const [bussinessScalePopoverOpen, setBussinessScalePopoverOpen] = useState(false)
  const [logoPopoverOpen, setLogoPopoverOpen] = useState(false)
  const [awardsPopoverOpen, setAwardsPopoverOpen] = useState(false)
  const [otpSendingLoading, setOtpSendingLoading] = useState([])
  const [panVerificationLoading, setPanVerificationLoading] = useState(false)
  const [msmeVerificationLoading, setMsmeVerificationLoading] = useState(false)
  const [gstin, setGstin] = useState('')

  const toggleUinPopover = () => setUinPopoverOpen((prev) => !prev)
  const toggleBussinessScalePopover = () => setBussinessScalePopoverOpen((prev) => !prev)
  const toggleLogoPopover = () => setLogoPopoverOpen((prev) => !prev)
  const toggleAwardsPopover = () => setAwardsPopoverOpen((prev) => !prev)

  const handleCountryChange = (countryId) => {
    setValue('stateId', '')
    setValue('cityId', '')
    if (countryId !== '' && !states[countryId]) {
      dispatch(fetchStateList(countryId))
    }
  }

  const handleStateChange = (countryId, stateId) => {
    setValue('cityId', '')
    if (countryId !== '' && stateId !== '' && !cities[`${countryId}-${stateId}`]) {
      dispatch(fetchCityList(countryId, stateId))
    }
  }

  const verifyPANHandler = async (data) => {
    setPanVerificationLoading(true)
    dispatch(verifyPAN(data)).then((res) => {
      setPanVerificationLoading(false)
      if (res) {
        setValue('isPanVerified', true)
      }
    })
  }

  const sendOtpHandler = (data, index) => {
    console.log(data)
    setOtpSendingLoading((prevState) => {
      const updatedStatus = [...prevState]
      updatedStatus[index] = true
      return updatedStatus
    })
    dispatch(
      sendOtpToContactPerson({
        contactEmail: data.contactDetails[index].contactPersonEmail,
        contactWhatsappNumber: data.contactDetails[index].contactPersonWhatsappNumber
      })
    ).then((success) => {
      setOtpSendingLoading((prevState) => {
        const updatedStatus = [...prevState]
        updatedStatus[index] = false
        return updatedStatus
      })

      setContactIndex(index)
      /* if (success) */ toggle()
    })
  }

  const verifyOtpHandler = () => {
    const data = getValues(`contactDetails[${contactIndex}]`)

    dispatch(
      verifyOtpOfContactPerson({
        contactEmail: data.contactPersonEmail,
        contactWhatsappNumber: data.contactPersonWhatsappNumber,
        contactEmailOtp: emailOtp.join(''),
        contactWhatsappNumberOtp: whatsappNumberOtp.join('')
      })
    ).then((res) => {
      if (res) {
        setValue(`contactDetails[${contactIndex}].contactVerificationToken`, res.verificationToken)
        contactSetValue(`contactDetails[${contactIndex}].contactVerificationToken`, res.verificationToken)

        setValue(`contactDetails[${contactIndex}].isContactPersonVerified`, true)
        contactSetValue(`contactDetails[${contactIndex}].isContactPersonVerified`, true)

        toggle()
      }
    })
  }

  const toggle = () => {
    setEmailOtp(new Array(6).fill(''))
    setWhatsappNumberOtp(new Array(6).fill(''))
    setModal(!modal)
  }

  const closeBtn = (
    <button
      className="otp-modal__close-btn"
      onClick={toggle}
      type="button">
      <IoMdClose />
    </button>
  )

  return (
    <div className="organizational-form__container">
      <Container
        fluid
        className="bg-transparent">
        <Form>
          <h2 className="dataForm_header">Organizational Data</h2>
          <Row>
            <Col
              md={watch('cityId') == -1 ? 3 : 4}
              xs={12}>
              <FormGroup className="organizational-form__input-container">
                <Label
                  for="country"
                  className="organizational-form__label mandatory-label">
                  Country
                </Label>
                <Controller
                  defaultValue=""
                  name="countryId"
                  control={control}
                  rules={{
                    required: 'Country is required'
                  }}
                  render={({ field, fieldState: { error } }) => (
                    <>
                      <Input
                        {...field}
                        type="select"
                        id="countryId"
                        invalid={error ? true : false}
                        className={error ? 'error-input' : ''}
                        onChange={(e) => {
                          field.onChange(e)
                          handleCountryChange(e.target.value)
                        }}>
                        <option value="">Select Country</option>
                        {(countries || []).map((item) => (
                          <option
                            key={item.id}
                            value={item.id}>
                            {item.countryName}
                          </option>
                        ))}
                      </Input>
                      {error && <span className="text-danger error-message">{error.message}</span>}
                    </>
                  )}
                />
              </FormGroup>
            </Col>
            {countryId !== '' && (
              <>
                <Col
                  md={watch('cityId') == -1 ? 3 : 4}
                  xs={12}>
                  <FormGroup className="organizational-form__input-container">
                    <Label
                      for="state"
                      className="organizational-form__label mandatory-label">
                      State
                    </Label>
                    <Controller
                      name="stateId"
                      defaultValue=""
                      control={control}
                      rules={{
                        required: 'State is required'
                      }}
                      render={({ field, fieldState: { error } }) => (
                        <>
                          <Input
                            {...field}
                            id="stateId"
                            type="select"
                            invalid={error ? true : false}
                            className={error ? 'error-input' : ''}
                            onChange={(e) => {
                              field.onChange(e)
                              handleStateChange(countryId, e.target.value)
                            }}>
                            <option value="">Select State</option>
                            {(states[countryId] || []).map((item) => (
                              <option
                                key={item.id}
                                value={item.id}>
                                {item.stateName}
                              </option>
                            ))}
                          </Input>
                          {error && <span className="text-danger error-message">{error.message}</span>}
                        </>
                      )}
                    />
                  </FormGroup>
                </Col>
                <Col
                  md={watch('cityId') == -1 ? 3 : 4}
                  xs={12}>
                  <FormGroup className="organizational-form__input-container">
                    <Label
                      for="city"
                      className="organizational-form__label mandatory-label">
                      City
                    </Label>
                    <Controller
                      name="cityId"
                      defaultValue=""
                      control={control}
                      rules={{
                        required: 'City is required'
                      }}
                      render={({ field, fieldState: { error } }) => (
                        <>
                          <Input
                            {...field}
                            id="cityId"
                            type="select"
                            invalid={error ? true : false}
                            className={error ? 'error-input' : ''}>
                            <option value="">Select City</option>
                            {(cities[`${countryId}-${stateId}`] || []).map((item) => (
                              <option
                                key={item.id}
                                value={item.id}>
                                {item.cityName}
                              </option>
                            ))}
                          </Input>
                          {error && <span className="text-danger error-message">{error.message}</span>}
                        </>
                      )}
                    />
                  </FormGroup>
                </Col>
                {watch('cityId') == -1 && (
                  <Col
                    md={watch('cityId') == -1 ? 3 : 4}
                    xs={12}>
                    <FormGroup className="organizational-form__input-container">
                      <Label
                        for="city"
                        className="organizational-form__label mandatory-label">
                        City Name
                      </Label>
                      <Controller
                        name="cityName"
                        defaultValue=""
                        control={control}
                        rules={{
                          required: 'City Name is required'
                        }}
                        render={({ field, fieldState: { error } }) => (
                          <>
                            <Input
                              {...field}
                              id="cityName"
                              type="text"
                              invalid={error ? true : false}
                              className={error ? 'error-input' : ''}
                            />
                            {error && <span className="text-danger error-message">{error.message}</span>}
                          </>
                        )}
                      />
                    </FormGroup>
                  </Col>
                )}
              </>
            )}
          </Row>
          <Row>
            <Col xs={12}>
              {countryId !== '' && (
                <>
                  {countryId == INDIA_CODE ? (
                    <Row>
                      <Col
                        md={4}
                        xs={12}>
                        <FormGroup className="organizational-form__input-container mb-0">
                          <Label
                            for="panNumber"
                            className="organizational-form__label mandatory-label">
                            PAN
                          </Label>
                          <Controller
                            defaultValue=""
                            name="panNumber"
                            control={control}
                            rules={{
                              required: 'PAN is required',
                              pattern: {
                                value: PAN_REGEX,
                                message: 'Invalid PAN'
                              }
                            }}
                            render={({ field, fieldState: { error } }) => (
                              <>
                                <Input
                                  {...field}
                                  type="text"
                                  id="panNumber"
                                  placeholder="Enter PAN"
                                  invalid={error ? true : false}
                                  className={error ? 'error-input' : ''}
                                />
                                {error && <span className="text-danger error-message">{error.message}</span>}
                              </>
                            )}
                          />
                        </FormGroup>
                      </Col>
                      <Col
                        md={4}
                        xs={12}>
                        <FormGroup className="organizational-form__input-container">
                          <Label
                            for="panHolderName"
                            className="organizational-form__label mandatory-label">
                            PAN Holder Name
                          </Label>
                          <Controller
                            defaultValue=""
                            control={control}
                            name="panHolderName"
                            rules={{
                              required: 'PAN Holder Name is required',
                              maxLength: { value: 100, message: "PAN Holder Name can't exceed 100 characters" }
                            }}
                            render={({ field, fieldState: { error } }) => (
                              <>
                                <Input
                                  {...field}
                                  type="text"
                                  id="panHolderName"
                                  onChange={(e) => {
                                    field.onChange(e)
                                    setValue('isPanVerified', false)
                                  }}
                                  disabled={panVerificationLoading}
                                  placeholder="Enter PAN Holder Name"
                                  invalid={error ? true : false}
                                  className={error ? 'error-input' : ''}
                                />
                                {error && <span className="text-danger error-message">{error.message}</span>}
                              </>
                            )}
                          />
                        </FormGroup>
                      </Col>
                      <Col
                        md={4}
                        xs={12}>
                        <FormGroup className="organizational-form__input-container">
                          <Label
                            for="dob"
                            className="organizational-form__label mandatory-label">
                            DOB/DOI
                          </Label>

                          <Controller
                            defaultValue=""
                            control={control}
                            name="panHolderDOB"
                            rules={{
                              required: 'PAN Holder DOB is required',
                              pattern: {
                                value: PAN_HOLDER_DOB_REGEX,
                                message: 'Invalid PAN Holder DOB'
                              }
                            }}
                            render={({ field, fieldState: { error } }) => (
                              <>
                                <Input
                                  {...field}
                                  type="date"
                                  id="panHolderDOB"
                                  disabled={panVerificationLoading}
                                  max={new Date().toISOString().split('T')[0]}
                                  onChange={(e) => {
                                    field.onChange(e)
                                    setValue('isPanVerified', false)
                                  }}
                                  invalid={error ? true : false}
                                  className={error ? 'error-input' : ''}
                                />
                                {error && <span className="text-danger error-message">{error.message}</span>}
                              </>
                            )}
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                  ) : (
                    <Row>
                      <Col
                        md={4}
                        xs={12}>
                        <FormGroup className="organizational-form__input-container">
                          <Label
                            for="uinNumber"
                            className="organizational-form__label mandatory-label">
                            UIN
                          </Label>
                          <span id="moreInfoData">
                            <IoMdInformationCircleOutline />
                          </span>
                          <Popover
                            target="moreInfoData"
                            isOpen={uinPopoverOpen}
                            toggle={toggleUinPopover}>
                            <PopoverHeader>UIN Guidelines</PopoverHeader>
                            <PopoverBody
                              style={{
                                backgroundColor: '#fff',
                                color: '#000'
                              }}>
                              UIN is the Unique Identification Number of a company (supplier) in the country for their registration.
                              <br />
                              Refer to following guideline for UIN.
                              <br />
                              <br />
                              Asia except India: TIN (Tax Identification Number)
                              <br />
                              <br />
                              Australia: ABN (Australian Business Number)
                              <br />
                              <br />
                              Europe: VAT (Value Added Tax Registration Number)
                              <br />
                              <br />
                              Middle East: VAT (Value Added Tax Registration Number)
                              <br />
                              <br />
                              Russia: TIN (Tax Identification Number)
                            </PopoverBody>
                          </Popover>
                          <Controller
                            defaultValue=""
                            control={control}
                            name="uinNumber"
                            rules={{
                              required: 'UIN is required'
                            }}
                            render={({ field, fieldState: { error } }) => (
                              <>
                                <Input
                                  {...field}
                                  type="text"
                                  id="uinNumber"
                                  placeholder="Enter UIN"
                                  invalid={error ? true : false}
                                  className={error ? 'error-input' : ''}
                                />
                                {error && (
                                  <span
                                    className="text-danger error-message"
                                    style={{ top: '70px' }}>
                                    {error.message}
                                  </span>
                                )}
                              </>
                            )}
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                  )}
                  <Row>
                    <Col xs={12}>
                      <h4 className="dataForm_subHeader">Company Details</h4>
                    </Col>
                    <Col
                      md={6}
                      xs={12}>
                      <FormGroup className="organizational-form__input-container">
                        <Label
                          for="companyName"
                          className="organizational-form__label mandatory-label">
                          Company Name
                        </Label>
                        <Controller
                          defaultValue=""
                          control={control}
                          name="companyName"
                          rules={{
                            required: 'Company Name is required'
                          }}
                          render={({ field, fieldState: { error } }) => (
                            <>
                              <Input
                                {...field}
                                type="text"
                                id="companyName"
                                invalid={error ? true : false}
                                placeholder="Enter Company Name"
                                className={error && 'error-input'}
                              />
                              {error && <span className="error-message text-danger">{error.message}</span>}
                            </>
                          )}
                        />
                      </FormGroup>
                    </Col>
                    <Col
                      md={6}
                      xs={12}>
                      <FormGroup className="organizational-form__input-container">
                        <Label
                          for="companyLogo"
                          className="organizational-form__label">
                          Upload Logo
                        </Label>
                        <span id="logoPopover">
                          <IoMdInformationCircleOutline />
                        </span>
                        <Popover
                          target="logoPopover"
                          isOpen={logoPopoverOpen}
                          toggle={toggleLogoPopover}>
                          <PopoverHeader>Logo File Guidelines</PopoverHeader>
                          <PopoverBody
                            style={{
                              backgroundColor: '#fff',
                              color: '#000'
                            }}>
                            Only JPEG and PNG images are allowed.
                            <br />
                            Maximum file size allowed is 5MB.
                          </PopoverBody>
                        </Popover>
                        <Input
                          type="file"
                          id="companyLogo"
                          name="companyLogo"
                          accept=".jpg,.png,.jpeg"
                          color="brand-color"
                          onChange={changeOrgLogoHandler}
                        />
                      </FormGroup>
                    </Col>
                  </Row>
                  {countryId == INDIA_CODE && (
                    <Row>
                      <Col
                        md={3}
                        xs={12}>
                        <Label className="organizational-form__label">Do you have a GSTIN?</Label>
                        <Controller
                          name="hasGstin"
                          defaultValue="Y"
                          control={control}
                          render={({ field }) => (
                            <Form>
                              <FormGroup
                                check
                                inline>
                                <Input
                                  {...field}
                                  value="Y"
                                  type="radio"
                                  name="gstinRadio"
                                  checked={field.value === 'Y'}
                                />
                                <Label check>Yes</Label>
                              </FormGroup>
                              <FormGroup
                                check
                                inline>
                                <Input
                                  {...field}
                                  value="N"
                                  type="radio"
                                  name="gstinRadio"
                                  checked={field.value === 'N'}
                                />
                                <Label check>No</Label>
                              </FormGroup>
                            </Form>
                          )}
                        />
                      </Col>
                      <Col
                        md={9}
                        xs={12}>
                        {hasGstin == 'Y' && (
                          <Form className="organizational-form__input-container">
                            <Label className="organizational-form__label mandatory-label">GSTIN</Label>
                            <Row className="gstInArea d-flex">
                              <Col md="10">
                                <Input
                                  type="text"
                                  placeHolder="Enter GSTIN"
                                  value={gstin}
                                  onChange={(e) => {
                                    setGstin(e.target.value)
                                  }}
                                />
                              </Col>
                              <Col md="2">
                                <Button
                                  block
                                  color="brand-color"
                                  type="button"
                                  disabled={gstin === '' ? true : false}
                                  onClick={() => {
                                    if (gstin.trim()) {
                                      const result = GSTIN_NUMBER_REGEX.test(gstin.trim())
                                      if (!result) {
                                        toast.error('Invalid GSTIN')
                                      } else {
                                        if (gstin.trim() && !watch('gstinInformation').some((opt) => opt.gstinNumber === gstin.trim())) {
                                          addGstin({ gstinNumber: gstin })
                                          setGstin('')
                                        } else {
                                          toast.error('Already Added')
                                          setGstin('')
                                        }
                                      }
                                    }
                                  }}>
                                  Add
                                </Button>
                              </Col>
                            </Row>
                            <div className="d-flex flex-wrap justify-content-start align-items-center row-gap-1 column-gap-2">
                              {gstinFields.map((item, index) => (
                                <div className="d-flex justify-content-start align-items-center ">
                                  <span>{item.gstinNumber}</span>
                                  <MdCancel
                                    onClick={() => removeGstin(index)}
                                    style={{ cursor: 'pointer', color: 'rgb(255 72 72)', marginLeft: '3px' }}
                                  />
                                </div>
                              ))}
                            </div>
                          </Form>
                        )}
                      </Col>
                      <Col
                        md={3}
                        xs={12}>
                        <Label className="organizational-form__label">Are you an MSME supplier?</Label>
                        <Controller
                          name="isMsme"
                          control={control}
                          defaultValue="N"
                          render={({ field }) => (
                            <Form>
                              <FormGroup
                                check
                                inline>
                                <Input
                                  {...field}
                                  value="Y"
                                  type="radio"
                                  name="msmeRadio"
                                  checked={field.value === 'Y'}
                                />
                                <Label check>Yes</Label>
                              </FormGroup>
                              <FormGroup
                                check
                                inline>
                                <Input
                                  {...field}
                                  value="N"
                                  type="radio"
                                  name="msmeRadio"
                                  checked={field.value === 'N'}
                                />
                                <Label check>No</Label>
                              </FormGroup>
                            </Form>
                          )}
                        />
                      </Col>
                      <Col
                        md={9}
                        xs={12}>
                        {isMsme === 'Y' && (
                          <FormGroup className="organizational-form__input-container">
                            <Label className="organizational-form__label mandatory-label">MSME Number</Label>
                            <Row>
                              <Col
                                md={12}
                                className="flex-grow-1">
                                <Controller
                                  defaultValue=""
                                  name="msmeNumber"
                                  control={control}
                                  rules={{
                                    required: 'MSME Number is required',
                                    pattern: {
                                      value: MSME_NUMBER_REGEX,
                                      message: 'Invalid MSME Number'
                                    }
                                  }}
                                  render={({ field, fieldState: { error } }) => (
                                    <>
                                      <Input
                                        {...field}
                                        type="text"
                                        id="msmeNumber"
                                        disabled={msmeVerificationLoading}
                                        placeholder="Enter MSME Number"
                                        invalid={error ? true : false}
                                        className={error ? 'error-input' : ''}
                                        onChange={(e) => {
                                          field.onChange(e)
                                          setValue('isMsmeVerified', false)
                                        }}
                                      />
                                      {error && <p className="error-message text-danger">{error.message}</p>}
                                    </>
                                  )}
                                />
                              </Col>
                            </Row>
                          </FormGroup>
                        )}
                      </Col>
                    </Row>
                  )}
                  <Row>
                    <Col xs={12}>
                      <FormGroup className="organizational-form__input-container">
                        <Label
                          for="overview"
                          className="organizational-form__label">
                          Company Overview
                        </Label>
                        <Controller
                          defaultValue=""
                          control={control}
                          name="companyOverview"
                          rules={{
                            maxLength: { value: 3000, message: "Company Overview can't exceed 5000 characters" }
                          }}
                          render={({ field, fieldState: { error } }) => (
                            <>
                              <Input
                                {...field}
                                type="textarea"
                                id="companyOverview"
                                invalid={error ? true : false}
                                className={error ? 'error-input' : ''}
                                placeholder="Write a brief about your company"
                              />
                              {error && <p className="error-message text-danger">{error.message}</p>}
                            </>
                          )}
                        />
                      </FormGroup>
                    </Col>
                  </Row>
                  <Row>
                    <Col
                      md={4}
                      xs={12}>
                      <FormGroup className="organizational-form__input-container">
                        <Label
                          for="yearEstablishment"
                          className="organizational-form__label mandatory-label">
                          Year of Establishment
                        </Label>
                        <Controller
                          defaultValue=""
                          control={control}
                          name="establishmentYear"
                          rules={{
                            required: 'Establishment year is required'
                          }}
                          render={({ field, fieldState: { error } }) => (
                            <>
                              <Input
                                {...field}
                                type="select"
                                id="establishmentYear"
                                invalid={error ? true : false}
                                className={error ? 'error-input' : ''}
                                placeholder="Select Year">
                                <option value="">Select Year</option>
                                {years.map((year) => (
                                  <option
                                    key={year}
                                    value={year}>
                                    {year}
                                  </option>
                                ))}
                              </Input>
                              {error && <p className="error-message text-danger">{error.message}</p>}
                            </>
                          )}
                        />
                      </FormGroup>
                    </Col>
                    <Col
                      md={4}
                      xs={12}>
                      <FormGroup className="organizational-form__input-container">
                        <Label
                          for="scaleBusiness"
                          className="organizational-form__label">
                          Scale of Business
                        </Label>
                        <span id="bussinessScale">
                          <IoMdInformationCircleOutline />
                        </span>
                        <Popover
                          target="bussinessScale"
                          isOpen={bussinessScalePopoverOpen}
                          toggle={toggleBussinessScalePopover}>
                          <PopoverHeader>Scale of Bussiness Guidelines</PopoverHeader>
                          <PopoverBody
                            style={{
                              backgroundColor: '#fff',
                              color: '#000'
                            }}>
                            {(bussinessSclaes || []).map((item) => (
                              <React.Fragment key={item.id}>
                                {item.name} : {item.description}
                                <br />
                                <br />
                              </React.Fragment>
                            ))}
                          </PopoverBody>
                        </Popover>
                        <Controller
                          defaultValue=""
                          control={control}
                          name="bussinessScaleId"
                          render={({ field }) => (
                            <Input
                              {...field}
                              type="select"
                              id="bussinessScaleId">
                              <option value="">Select Bussiness Scale</option>
                              {(bussinessSclaes || []).map((item) => (
                                <option
                                  key={item.id}
                                  value={item.id}>
                                  {item.name}
                                </option>
                              ))}
                            </Input>
                          )}
                        />
                      </FormGroup>
                    </Col>
                    {/* <Col
                  md={4}
                  xs={12}>
                  <FormGroup className="organizational-form__input-container">
                    <Label for="scaleBusiness">Key Partnership</Label>
                    <Controller
                      control={control}
                      name="keyPartnership"
                      render={({ field }) => (
                        <EditableDropdown
                          {...field}
                          regex={/^[A-Za-z0-9&.,'’\-() ]{2,100}$/}
                          placeHolder="Key Partnership"
                          verification={false}
                        />
                      )}
                    />
                  </FormGroup>
                </Col> */}
                    <Col
                      md={4}
                      xs={12}>
                      <FormGroup className="organizational-form__input-container">
                        <Label
                          for="annualRevenue"
                          className="organizational-form__label">
                          Annual Revenue
                        </Label>
                        <Controller
                          defaultValue=""
                          control={control}
                          name="annualRevenue"
                          render={({ field }) => (
                            <>
                              <Input
                                {...field}
                                type="number"
                                id="annualRevenue"
                                placeholder={'Enter amount in ' + countries.find((item) => item.id == countryId).currency}
                              />
                            </>
                          )}
                        />
                      </FormGroup>
                    </Col>
                  </Row>
                  <Row>
                    <Col xs={12}>
                      <h4 className="dataForm_subHeader">Social Media Information</h4>
                    </Col>
                    <Col
                      md={4}
                      xs={12}>
                      <FormGroup className="organizational-form__input-container">
                        <Label
                          for="twitterID"
                          className="organizational-form__label">
                          Twitter ID
                        </Label>
                        <input
                          type="text"
                          id="twitterId"
                          className="form-control"
                          placeholder="Twitter ID"
                          {...register('twitterId')}
                        />
                      </FormGroup>
                    </Col>
                    <Col
                      md={4}
                      xs={12}>
                      <FormGroup className="organizational-form__input-container">
                        <Label
                          for="linkedinID"
                          className="organizational-form__label">
                          LinkedIn ID
                        </Label>
                        <input
                          type="text"
                          id="linkedinId"
                          className="form-control"
                          placeholder="LinkedIn ID"
                          {...register('linkedInId')}
                        />
                      </FormGroup>
                    </Col>
                    <Col
                      md={4}
                      xs={12}>
                      <FormGroup className="organizational-form__input-container">
                        <Label
                          for="facebookID"
                          className="organizational-form__label">
                          Facebook ID
                        </Label>
                        <input
                          type="text"
                          id="facebookId"
                          className="form-control"
                          placeholder="Facebook ID"
                          {...register('facebookId')}
                        />
                      </FormGroup>
                    </Col>
                  </Row>
                  <Row className="contact-information__container">
                    <Col xs={12}>
                      <Row className="d-flex justify-content-between align-items-center mt-2">
                        <Col>
                          <h4 className="dataForm_subHeader mb-0">Contact Information</h4>
                        </Col>
                        <Col>
                          <Button
                            type="button"
                            className="addMore_Data"
                            onClick={() => {
                              addContactPerson({
                                contactPersonName: '',
                                contactPersonEmail: '',
                                contactPersonWhatsappNumber: '',
                                contactPersonDesignation: '',
                                isContactPersonVerified: false,
                                contactVerificationToken: null,
                                contactPersonType: 'additional'
                              })
                              addContactVerify({
                                contactPersonName: '',
                                contactPersonEmail: '',
                                contactPersonWhatsappNumber: ''
                              })
                            }}>
                            <IoIosAdd style={{ color: 'white', fontSize: '1.5rem' }} />
                          </Button>
                        </Col>
                      </Row>
                    </Col>
                    {contactPersonFields.map((field, index) => (
                      <Col
                        xs={12}
                        key={field.id}>
                        <Row className="organizational-form__contact-container">
                          <Col xs={12}>
                            <Row>
                              <Col>
                                <Label className="fw-bold text-dark mb-0">
                                  {index === 0 ? 'Primary Contact' : 'Correspondence Contact ' + index}
                                </Label>
                              </Col>

                              {index !== 0 && (
                                <Col className="d-flex justify-content-end">
                                  <MdDelete
                                    style={{ color: 'rgb(255 72 72)', fontSize: '1.2rem', cursor: 'pointer' }}
                                    onClick={() => {
                                      removeContactPerson(index)
                                      removeContactVerify(index)
                                    }}
                                  />
                                </Col>
                              )}

                              {/* {index !== 0 && (
                                <Col>
                                  <Button
                                    type="button"
                                    className="addMore_Data"
                                    style={{ backgroundColor: 'red', border: 'none' }}>
                                    <MdDelete
                                      style={{ color: 'white', fontSize: '1.2rem' }}
                                      onClick={() => {
                                        removeContactPerson(index)
                                        removeContactVerify(index)
                                      }}
                                    />
                                  </Button>
                                </Col>
                              )} */}
                            </Row>
                          </Col>

                          <Row>
                            <Col
                              md={3}
                              xs={12}>
                              <FormGroup className="organizational-form__input-container">
                                <Label className="organizational-form__label mandatory-label">Name</Label>
                                <Controller
                                  defaultValue=""
                                  control={control}
                                  disabled={otpSendingLoading[index]}
                                  name={`contactDetails[${index}].contactPersonName`}
                                  rules={{
                                    required: 'Name is required',
                                    maxLength: { value: 50, message: "Name can't exceed 50 characters" }
                                  }}
                                  render={({ field, fieldState: { error } }) => (
                                    <>
                                      <Input
                                        {...field}
                                        type="text"
                                        placeholder="Enter Name"
                                        invalid={error || contactErrors?.contactDetails?.[index]?.contactPersonName ? true : false}
                                        className={error || contactErrors?.contactDetails?.[index]?.contactPersonName ? 'error-input' : ''}
                                        onChange={(e) => {
                                          field.onChange(e)
                                          setValue(`contactDetails[${index}].isContactPersonVerified`, false)
                                          contactSetValue(`contactDetails[${index}].isContactPersonVerified`, false)
                                          contactSetValue(`contactDetails[${index}].contactPersonName`, e.target.value)
                                        }}
                                        id={`contactDetails[${index}].contactPersonName`}
                                      />
                                      {error && <span className="text-danger error-message">{error.message}</span>}
                                    </>
                                  )}
                                />
                              </FormGroup>
                            </Col>
                            <Col
                              md={3}
                              xs={12}>
                              <FormGroup className="organizational-form__input-container">
                                <Label className="organizational-form__label">Designation</Label>
                                <Controller
                                  defaultValue=""
                                  control={control}
                                  name={`contactDetails[${index}].contactPersonDesignation`}
                                  render={({ field }) => (
                                    <Input
                                      {...field}
                                      type="text"
                                      placeholder="Enter Designation"
                                      id={`contactDetails[${index}].contactPersonDesignation`}
                                    />
                                  )}
                                />
                              </FormGroup>
                            </Col>
                            <Col
                              md={3}
                              xs={12}>
                              <FormGroup className="organizational-form__input-container">
                                <Label className="organizational-form__label mandatory-label">Email ID</Label>
                                <Controller
                                  name={`contactDetails[${index}].contactPersonEmail`}
                                  control={control}
                                  defaultValue=""
                                  rules={{
                                    required: 'Email ID is required',
                                    pattern: {
                                      value: EMAIL_REGEX,
                                      message: 'Invalid Email ID'
                                    }
                                  }}
                                  render={({ field, fieldState: { error } }) => (
                                    <>
                                      <Input
                                        {...field}
                                        type="text"
                                        placeholder="Enter Email ID"
                                        disabled={otpSendingLoading[index]}
                                        invalid={error || contactErrors?.contactDetails?.[index]?.contactPersonEmail ? true : false}
                                        className={error || contactErrors?.contactDetails?.[index]?.contactPersonEmail ? 'error-input' : ''}
                                        onChange={(e) => {
                                          field.onChange(e)
                                          setValue(`contactDetails[${index}].isContactPersonVerified`, false)
                                          contactSetValue(`contactDetails[${index}].isContactPersonVerified`, false)
                                          contactSetValue(`contactDetails[${index}].contactPersonEmail`, e.target.value)
                                        }}
                                        id={`contactDetails[${index}].contactPersonEmail`}
                                      />
                                      {error ? (
                                        <span className="text-danger error-message">{error.message}</span>
                                      ) : (
                                        contactErrors.contactDetails?.[index]?.contactPersonEmail && (
                                          <span className="text-danger">{contactErrors.contactDetails[index].contactPersonEmail.message}</span>
                                        )
                                      )}
                                    </>
                                  )}
                                />
                              </FormGroup>
                            </Col>
                            <Col
                              md={3}
                              xs={12}>
                              <FormGroup className="organizational-form__input-container">
                                <Label className="organizational-form__label mandatory-label">WhatsApp Number</Label>
                                <Row>
                                  <Col
                                    md={'9'}
                                    className="flex-grow-1">
                                    <Controller
                                      defaultValue=""
                                      control={control}
                                      name={`contactDetails[${index}].contactPersonWhatsappNumber`}
                                      rules={{
                                        required: 'Number is required',
                                        pattern: {
                                          value: WHATSAPP_NUMBER_REGEX,
                                          message: 'Invalid Number'
                                        }
                                      }}
                                      render={({ field, fieldState: { error } }) => (
                                        <>
                                          <Input
                                            {...field}
                                            type="text"
                                            placeholder="Enter Number"
                                            disabled={otpSendingLoading[index]}
                                            invalid={error || contactErrors?.contactDetails?.[index]?.contactPersonWhatsappNumber ? true : false}
                                            className={
                                              error || contactErrors?.contactDetails?.[index]?.contactPersonWhatsappNumber ? 'error-input' : ''
                                            }
                                            onChange={(e) => {
                                              field.onChange(e)
                                              setValue(`contactDetails[${index}].isContactPersonVerified`, false)
                                              contactSetValue(`contactDetails[${index}].isContactPersonVerified`, false)
                                              contactSetValue(`contactDetails[${index}].contactPersonWhatsappNumber`, e.target.value)
                                            }}
                                            id={`contactDetails[${index}].contactPersonWhatsappNumber`}
                                          />
                                          {error ? (
                                            <span className="text-danger error-message">{error.message}</span>
                                          ) : (
                                            contactErrors?.contactDetails?.[index]?.contactPersonWhatsappNumber && (
                                              <span className="text-danger">
                                                {contactErrors.contactDetails[index].contactPersonWhatsappNumber.message}
                                              </span>
                                            )
                                          )}
                                        </>
                                      )}
                                    />
                                  </Col>
                                  <Col
                                    md={'3'}
                                    className="ps-0">
                                    {otpSendingLoading[index] ? (
                                      <Button
                                        color="brand-color"
                                        disabled>
                                        <Spinner size="sm"></Spinner>
                                      </Button>
                                    ) : watch(`contactDetails[${index}].isContactPersonVerified`) ? (
                                      <Button
                                        color="brand-color"
                                        disabled>
                                        Verified
                                      </Button>
                                    ) : (
                                      <Button
                                        color="brand-color"
                                        onClick={contactHandleSubmit((data) => sendOtpHandler(data, index))}>
                                        Verify
                                      </Button>
                                    )}
                                  </Col>
                                </Row>
                              </FormGroup>
                            </Col>
                          </Row>
                        </Row>
                      </Col>
                    ))}

                    {contactVerifyFields.map((field, index) => (
                      <>
                        <Controller
                          defaultValue=""
                          control={contactControl}
                          name={`contactDetails[${index}].contactPersonEmail`}
                          rules={{
                            required: 'Email ID is required',
                            pattern: {
                              value: EMAIL_REGEX,
                              message: 'Invalid Email ID'
                            }
                          }}
                          render={({ field }) => (
                            <Input
                              {...field}
                              type="hidden"
                              id={`contactDetails[${index}].contactPersonEmail`}
                            />
                          )}
                        />
                        <Controller
                          name={`contactDetails[${index}].contactPersonWhatsappNumber`}
                          control={contactControl}
                          defaultValue=""
                          rules={{
                            required: 'Number is required',
                            pattern: {
                              value: WHATSAPP_NUMBER_REGEX,
                              message: 'Invalid Number'
                            }
                          }}
                          render={({ field }) => (
                            <Input
                              {...field}
                              type="hidden"
                              id={`contactDetails[${index}].contactPersonWhatsappNumber`}
                            />
                          )}
                        />
                      </>
                    ))}
                  </Row>
                  {/* File Uploads */}
                  <Row>
                    <Col xs={12}>
                      <FormGroup>
                        <div className="d-flex justify-content-start align-items-center">
                          <h4 className="dataForm_subHeader">Awards & Recognitions</h4>
                          <span id="awardsPopover">
                            <IoMdInformationCircleOutline />
                          </span>
                        </div>
                        <Popover
                          target="awardsPopover"
                          isOpen={awardsPopoverOpen}
                          toggle={toggleAwardsPopover}>
                          <PopoverHeader>Awards File Upload Guidelines</PopoverHeader>
                          <PopoverBody
                            style={{
                              backgroundColor: '#fff',
                              color: '#000'
                            }}>
                            Only PDF and DOCX files are allowed.
                            <br />
                            Maximum file size allowed is 2MB.
                            <br />
                            You can upload up to 10 files.
                          </PopoverBody>
                        </Popover>
                        <AwardUploadSection
                          files={orgAwards}
                          setFiles={setOrgAwards}
                        />
                      </FormGroup>
                    </Col>
                  </Row>
                </>
              )}
            </Col>
          </Row>
        </Form>
        <Modal
          isOpen={modal}
          toggle={toggle}
          size="lg">
          <ModalHeader
            className="custom-modal-header"
            toggle={toggle}
            close={closeBtn}>
            OTP Verification
          </ModalHeader>
          <ModalBody className="text-center">
            <Row>
              <Col xs={12}>
                <p>An OTP has been sent to your Mobile Number and Email ID. Please enter the OTPs below to verify your contact details.</p>
              </Col>
              <Col
                xs={12}
                className="mb-4">
                <Label className="modal-form-label">Please enter the OTP sent to your mobile number.</Label>
                <OTPInputMobile
                  otp={whatsappNumberOtp}
                  setOtp={setWhatsappNumberOtp}
                />
              </Col>
              <Col
                xs={12}
                className="mb-4">
                <Label className="modal-form-label">Please enter the OTP sent to your email ID.</Label>
                <OTPInputEmail
                  otp={emailOtp}
                  setOtp={setEmailOtp}
                />
              </Col>
              <Col
                xs={12}
                className="mb-2">
                <Button
                  className="mjPrimary-btn btn-lg"
                  onClick={verifyOtpHandler}>
                  Validate
                </Button>
              </Col>
              <Col xs={12}>
                <Button className="mjPrimary-btn-outlined btn-lg">Resend OTP</Button>
              </Col>
            </Row>
          </ModalBody>
        </Modal>
      </Container>
    </div>
  )
}

export default OrganizationForm
