import './BuyPlanComponentStyles.scss'
import React, { useState } from 'react'
import ContactForm from './ContactForm'
import PaymentOption from './PaymentOption'

const PaymentContact = () => {
  const [isOtpVerified, setIsOtpVerified] = useState(false)
  const [otpVerificationToken, setOtpVerificationToken] = useState(null)

  return (
    <div
      className="GlossBg p-3"
      style={{ border: '4px solid #fff' }}>
      <ContactForm
        isOtpVerified={isOtpVerified}
        setIsOtpVerified={setIsOtpVerified}
        setOtpVerificationToken={setOtpVerificationToken}
      />
      {isOtpVerified && (
        <PaymentOption
          otpVerificationToken={otpVerificationToken}
          isOtpVerified={isOtpVerified}
          setIsOtpVerified={setIsOtpVerified}
        />
      )}
    </div>
  )
}

export default PaymentContact
