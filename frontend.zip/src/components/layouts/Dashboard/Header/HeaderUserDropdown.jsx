import React, { useState } from "react";
import { MdLogout } from "react-icons/md";
import { FaUserAlt } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { logout } from "../../../../services/controller/authAPI";
import {
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
} from "reactstrap";

const HeaderUserDropdown = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const currentUser = useSelector((state) => state.user);

  const [modal, setModal] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const toggleModal = () => setModal((prev) => !prev);
  const toggleDropdown = () => setDropdownOpen(!dropdownOpen);

  const logoutHandler = () => {
    dispatch(logout()).then((success) => {
      if (success) {
        toggleModal();
        navigate("/");
      }
    });
  };

  return (
    <div className="user-dropdown">
      <Dropdown isOpen={dropdownOpen} toggle={toggleDropdown} direction="down">
        <DropdownToggle
          caret
          tag="div"
          className="d-flex align-items-center custom_UserDrop"
          style={{
            cursor: "pointer",
            background: "linear-gradient(90deg, #E8D6FF 0%, #147ACC 100%)",
            padding: "8px 12px",
            color: "#fff",
            fontWeight: "500",
          }}
        >
          <div className="userBadge">
            <FaUserAlt />
          </div>
          <p className="mb-0 mx-4">
            <span>Welcome,</span>
            <br />
            <span className="fw-bold text-light">
              {currentUser?.mjPROUserInfo?.userFullName}
            </span>
          </p>
        </DropdownToggle>
        <DropdownMenu style={{ width: "100%", marginTop: "10px" }}>
          <DropdownItem
            className="d-flex align-items-center justify-content-start gap-2 text-danger"
            onClick={toggleModal}
          >
            <MdLogout />
            <span className="text-danger fw-bold"> Logout</span>
          </DropdownItem>
        </DropdownMenu>
      </Dropdown>

      <Modal
        isOpen={modal}
        toggle={toggleModal}
        centered
        className="custom-modal"
      >
        <ModalHeader toggle={toggleModal} className="modal-header-custom">
          Confirm Logout
        </ModalHeader>
        <ModalBody className="modal-body-custom">
          <p>
            Are you sure you want to log out? You will need to log in again to
            access your account.
          </p>
        </ModalBody>
        <ModalFooter className="modal-footer-custom">
          <Button className="btn-cancel" onClick={toggleModal}>
            Cancel
          </Button>
          <Button className="btn-logout" onClick={logoutHandler}>
            Logout
          </Button>
        </ModalFooter>
      </Modal>
    </div>
  );
};

export default HeaderUserDropdown;
