import React from 'react'
import './MainLayout.scss'
import { Outlet } from 'react-router-dom'
import Header from '../../../components/common/header/Header'
import Footer from '../../../components/common/footer/Footer'

const MainLayout = () => {
  return (
    <>
      <Header />
      <div className="main-layout__container">
        <Outlet />
      </div>
      <Footer />
    </>
  )
}

export default MainLayout
