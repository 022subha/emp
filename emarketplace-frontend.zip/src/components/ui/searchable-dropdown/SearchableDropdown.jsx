import React, { useState } from 'react'
import './SearchableDropdownStyles.scss'
import { Dropdown, DropdownToggle, DropdownMenu, DropdownItem, Input } from 'reactstrap'

const SearchableDropdown = ({ options, placeHolder, onSelect }) => {
  const [dropdownOpen, setDropdownOpen] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [filteredOptions, setFilteredOptions] = useState(options)

  const toggleDropdown = () => setDropdownOpen(!dropdownOpen)

  const handleSearchChange = (e) => {
    const term = e.target.value.toLowerCase()
    setSearchTerm(term)
    setFilteredOptions(options.filter((option) => option.toLowerCase().includes(term)))
  }

  const handleSelect = (option) => {
    onSelect(option)
    setSearchTerm(option)
    setDropdownOpen(false)
  }

  return (
    <Dropdown
      isOpen={dropdownOpen}
      toggle={toggleDropdown}
      className="w-100">
      <DropdownToggle
        caret
        className="w-100 text-start">
        {placeHolder}
      </DropdownToggle>
      <DropdownMenu className="w-100">
        <div className="px-3 py-2">
          <Input
            type="text"
            placeholder="Search..."
            value={searchTerm}
            onChange={handleSearchChange}
          />
        </div>
        <div style={{ maxHeight: '200px', overflowY: 'auto' }}>
          {filteredOptions.length > 0 ? (
            filteredOptions.map((option, index) => (
              <DropdownItem
                key={index}
                onClick={() => handleSelect(option)}>
                {option}
              </DropdownItem>
            ))
          ) : (
            <DropdownItem disabled>No results found</DropdownItem>
          )}
        </div>
      </DropdownMenu>
    </Dropdown>
  )
}

export default SearchableDropdown
