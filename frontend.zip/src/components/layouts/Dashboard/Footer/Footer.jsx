import React from "react";
import "./FooterStyles.scss";
import "bootstrap/dist/css/bootstrap.min.css";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="suppFooter d-flex justify-content-between align-items-center">
      <div className="footer-left">
        Copyright © {currentYear} All Rights Reserved
      </div>
      <div className="footer-center">www.mjunction.in</div>
      <div className="footer-right">
        <span> To know more visit -</span>
        <a
          href="https://www.mjpro.in"
          target="_blank"
          rel="noopener noreferrer"
        >
          www.mjpro.in
        </a>
        <span className="separator">|</span>
        <a href="/privacy-policy" target="_blank">
          Privacy Policy
        </a>
        <span className="separator">|</span>
        <a href="/terms-and-conditions" target="_blank">
          Terms & Conditions
        </a>
      </div>
    </footer>
  );
};

export default Footer;
