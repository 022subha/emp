import React, { useState } from 'react'
import { Form, Input, Tooltip } from 'reactstrap'
import { MdDelete } from 'react-icons/md'
import './AdManagementComponentsStyle.scss'
import { Controller } from 'react-hook-form'
import { toast } from 'react-toastify'

const PhotoUpload = ({ control, errors, imgFiles, setImgFiles, images, setImages, type }) => {
  const handleFileChange = (e, index) => {
    const files = e.target.files

    if (files && files.length > 0) {
      const newImages = [...images]
      const newFiles = [...imgFiles]

      for (let i = 0; i < files.length; i++) {
        const file = files[i]

        if (file.size > 5 * 1024 * 1024) {
          toast.error('File size exceeds 5MB. Please upload a smaller file.')
          continue
        }

        const reader = new FileReader()

        reader.onload = () => {
          let newIndex = index
          while (newIndex < newImages.length && newImages[newIndex] !== null) {
            newIndex++
          }

          if (newIndex < newImages.length) {
            newImages[newIndex] = reader.result
            newFiles[newIndex] = file
            setImages([...newImages])
            setImgFiles([...newFiles])
          }
        }

        reader.readAsDataURL(file)
      }
    }
  }

  const handleFileDelete = (index) => {
    const newImages = [...images]
    const newFiles = [...imgFiles]
    newImages[index] = null
    newFiles[index] = null
    setImages(newImages)
    setImgFiles(newFiles)
  }

  const validateAtLeastOneImage = (value) => {
    return images.some((image) => image !== null) || 'At least one image is required'
  }

  return (
    <Form className="d-flex flex-wrap gap-2">
      <Controller
        name="photos"
        control={control}
        rules={{
          validate: validateAtLeastOneImage
        }}
        render={() => (
          <>
            {images.map((image, index) => (
              <div
                key={index}
                className="border-primary-brand rounded d-flex justify-content-center align-items-center position-relative"
                style={{
                  width: '100px',
                  height: '100px',
                  overflow: 'hidden',
                  backgroundColor: '#f8f9fa'
                }}>
                {image ? (
                  <div className="deleteimage-container">
                    <img
                      className="deleteimage"
                      src={image}
                      alt={`Uploaded preview ${index + 1}`}
                      style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: 'inherit' }}
                    />
                    <div
                      className="delete-icon"
                      onClick={() => handleFileDelete(index)}>
                      <MdDelete />
                    </div>
                  </div>
                ) : (
                  <>
                    <label
                      htmlFor={`file-input-${type}-${index}`}
                      className="d-flex flex-column align-items-center cursor-pointer"
                      style={{ cursor: 'pointer' }}>
                      <i
                        className="bi bi-camera"
                        style={{ fontSize: '24px' }}></i>
                      <span>Add Photo</span>
                    </label>

                    <Input
                      type="file"
                      id={`file-input-${type}-${index}`}
                      accept=".jpg,.png,.jpeg"
                      onChange={(e) => handleFileChange(e, index)}
                      style={{ display: 'none' }}
                      multiple
                    />
                  </>
                )}
              </div>
            ))}
          </>
        )}
      />
      {errors.photos && (
        <p
          style={{ position: 'absolute', top: '125px' }}
          className="text-danger error-message">
          {errors.photos.message}
        </p>
      )}
    </Form>
  )
}

export default PhotoUpload
