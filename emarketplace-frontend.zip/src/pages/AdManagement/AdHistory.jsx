import React from 'react'
import { Card } from 'reactstrap'
import AdHistoryTable from './AdHistoryTable'

export default function AdHistory({ adHistory, setAdHistory, fetchAdsData, toggle }) {
  return (
    <div style={{ height: 'calc(100vh - 175px)', overflowY: 'auto', overflowX: 'hidden' }}>
      <Card
        body
        className="bg-transparent border-0 shadow-none mb-0 p-2 py-0">
        <AdHistoryTable
          toggle={toggle}
          adHistory={adHistory}
          setAdHistory={setAdHistory}
          fetchAdsData={fetchAdsData}
        />
      </Card>
    </div>
  )
}
