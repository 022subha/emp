import {
  Row,
  Col,
  Card,
  Badge,
  Modal,
  Input,
  Button,
  CardImg,
  Tooltip,
  Carousel,
  CardBody,
  CardText,
  ModalBody,
  CardTitle,
  ListGroup,
  ButtonGroup,
  ModalHeader,
  CarouselItem,
  CardSubtitle,
  ListGroupItem,
  CarouselControl,
  CarouselIndicators,
  ModalFooter
} from 'reactstrap'
import React, { useState } from 'react'
import { MdDelete } from 'react-icons/md'
import { useDispatch } from 'react-redux'
import { FaEye, FaEdit, FaList } from 'react-icons/fa'
import ImgPng from '../../assets/images/icons/image.webp'
import { deleteAd, fetchAdDetail } from '../../services/controller/adAPI'

export default function LiveAds({ liveAds, fetchAdsData }) {
  const dispatch = useDispatch()
  const [ad, setAd] = useState(null)
  const [rSelected, setRSelected] = useState(1)
  const [searchTerm, setSearchTerm] = useState('')

  const filteredLiveAds = (liveAds || []).filter(({ title }) => title?.toLowerCase().includes(searchTerm.toLowerCase()))

  const [tooltipOpen, setTooltipOpen] = useState({})

  const toggleTooltip = (id) => setTooltipOpen((prev) => ({ ...prev, [id]: !prev[id] }))

  const [modal, setModal] = useState(false)
  const toggleLiveAdPreview = () => {
    setModal((prev) => !prev)
  }

  const handleLiveAdPreview = (id) => {
    dispatch(fetchAdDetail(id)).then((adDetail) => {
      if (adDetail) {
        setAd(adDetail)
        toggleLiveAdPreview()
      }
    })
  }

  const [carouselIndex, setCarouselIndex] = useState(0)
  const [carouselAnimating, setCarouselAnimating] = useState(false)

  const handleCarouselNext = () => !carouselAnimating && setCarouselIndex((i) => (i + 1) % (ad?.banners?.length || 1))
  const handleCarouselPrev = () => !carouselAnimating && setCarouselIndex((i) => (i === 0 ? (ad?.banners?.length || 1) - 1 : i - 1))

  const [adId, setAdId] = useState(0)
  const [deleteModal, setDeleteModal] = useState(false)
  const toggleDeleteModal = () => setDeleteModal((prev) => !prev)
  const deleteAdHandler = () => {
    dispatch(deleteAd(adId)).then((success) => {
      if (success) {
        fetchAdsData()
        toggleDeleteModal()
      }
    })
  }

  return (
    <div style={{ height: 'calc(100vh - 175px)', overflowY: 'auto', overflowX: 'hidden' }}>
      <Row className="p-2 liveCard_wrapper">
        {filteredLiveAds.map((ad, index) => (
          <Col
            xs="12"
            md="6"
            xl="3"
            className="liveCard_container"
            key={index}>
            <Card
              className="liveAdCard mb-2"
              style={{ background: '#eff1fc', boxShadow: 'none' }}>
              {ad?.banners?.[0]?.fileUrl ? (
                <CardImg
                  alt="Card image cap"
                  src={'https://e-marketplace.s3.ap-south-1.amazonaws.com/' + ad?.banners?.[0]?.fileUrl}
                  top
                  width="100%"
                  height={'250px'}
                  onClick={() => handleLiveAdPreview(ad.id)}
                  style={{ cursor: 'pointer', objectFit: 'contain' }}
                />
              ) : (
                <CardImg
                  alt="Card image cap"
                  src={ImgPng}
                  top
                  width="100%"
                  height={'250px'}
                  onClick={() => handleLiveAdPreview(ad.id)}
                  style={{ cursor: 'pointer', objectFit: 'contain' }}
                />
              )}

              <CardBody>
                <CardTitle
                  tag="h5"
                  className="row">
                  <Col className="flex-grow-1 cardTitle_text">
                    <span
                      id={`tooltip-title-${index}`}
                      className="text-truncate">
                      {ad.title}
                    </span>
                  </Col>
                  <Tooltip
                    placement="top"
                    isOpen={tooltipOpen[`title-${index}`]}
                    target={`tooltip-title-${index}`}
                    toggle={() => toggleTooltip(`title-${index}`)}>
                    {ad.title}
                  </Tooltip>
                  {ad?.viewsCount ? (
                    <Col xs={'auto'}>
                      <Badge
                        pill
                        className="float-end"
                        color="primary">
                        <span className="text-decoration-none text-light d-flex align-items-center">
                          <FaEye /> <span className="ms-2">{ad?.viewsCount || 0}</span>
                        </span>
                      </Badge>
                    </Col>
                  ) : (
                    <></>
                  )}
                </CardTitle>
                <CardSubtitle className="mb-2 cardCategory_text">
                  <span className="fw-bold">Category:</span>{' '}
                  <span id={`tooltip-category-${index}`}>{ad?.category?.hsnDescription || 'Not Available'}</span>
                  <Tooltip
                    placement="top"
                    isOpen={tooltipOpen[`category-${index}`]}
                    target={`tooltip-category-${index}`}
                    toggle={() => toggleTooltip(`category-${index}`)}>
                    {ad?.category?.hsnDescription}
                  </Tooltip>
                </CardSubtitle>
                <CardSubtitle className="mb-2">
                  <span className="fw-bold">Offer Start/End {/* Date */}: </span>
                  <span>{ad?.offerStartDate?.split('T')[0]?.split('-')?.reverse()?.join('/') || 'Not Available'}</span> -{' '}
                  <span>{ad?.offerEndDate?.split('T')[0]?.split('-')?.reverse()?.join('/') || 'Not Available'}</span>
                  <br />
                </CardSubtitle>
                {/* <CardText>{ad.description}</CardText> */}
                <Row>
                  <Col
                    xs="auto"
                    className="flex-grow-1 d-flex align-items-center">
                    <div>
                      <small className="text-muted">{new Date(ad.createdAt).toLocaleDateString('en-GB')}</small>
                      <span> | </span>
                      <small className="text-muted">{new Date(ad.createdAt).toLocaleTimeString('en-GB').slice(0, -3)}</small>
                    </div>
                  </Col>
                  <Col xs="auto">
                    <Button className="bg-transparent text-secondary border-0 p-0 ms-2 fs-4">
                      <FaEdit
                        className="mb-2"
                        style={{ color: '#00B1f1' }}
                      />
                    </Button>
                    <Button
                      className="bg-transparent text-danger border-0 p-0 ms-2 fs-4"
                      onClick={() => {
                        setAdId(ad.id)
                        toggleDeleteModal()
                      }}>
                      <MdDelete className="mb-2" />
                    </Button>
                  </Col>
                </Row>
              </CardBody>
            </Card>
          </Col>
        ))}
      </Row>

      <Modal
        isOpen={modal}
        toggle={toggleLiveAdPreview}
        size="xl">
        <ModalHeader
          className="post__ad-modal-header"
          toggle={toggleLiveAdPreview}>
          AD Details
        </ModalHeader>
        <ModalBody className="post__ad-modal-body">
          <Card className="post__ad-modal-wrapper">
            <Carousel
              dark={true}
              activeIndex={carouselIndex}
              next={handleCarouselNext}
              previous={handleCarouselPrev}>
              <CarouselIndicators
                items={ad?.banners || []}
                activeIndex={carouselIndex}
                onClickHandler={(newIndex) => !carouselAnimating && setCarouselIndex(newIndex)}
              />
              {(ad?.banners?.length ? ad.banners : [{}]).map((item, i) => (
                <CarouselItem
                  key={i}
                  onExiting={() => setCarouselAnimating(true)}
                  onExited={() => setCarouselAnimating(false)}>
                  <img
                    src={item?.fileUrl ? `https://e-marketplace.s3.ap-south-1.amazonaws.com/${item.fileUrl}` : ImgPng}
                    alt="Ad Image"
                  />
                </CarouselItem>
              ))}
              <CarouselControl
                direction="prev"
                directionText="Previous"
                onClickHandler={handleCarouselPrev}
              />
              <CarouselControl
                direction="next"
                directionText="Next"
                onClickHandler={handleCarouselNext}
              />
            </Carousel>

            <CardBody>
              <CardTitle
                className="row"
                tag="h5">
                <Col className="flex-grow-1 post__ad-modal-title">
                  <span id="tooltip1">{ad?.title || 'Not Available'}</span>
                </Col>
                {ad?.title && (
                  <Tooltip
                    placement="top"
                    isOpen={tooltipOpen.tooltip1}
                    autohide={false}
                    target="tooltip1"
                    toggle={() => toggle('tooltip1')}>
                    {ad?.title}
                  </Tooltip>
                )}
                {ad?.viewsCount ? (
                  <Col xs={'auto'}>
                    <Badge
                      pill
                      className="float-end"
                      color="primary">
                      <span className="text-decoration-none text-light d-flex align-items-center">
                        <FaEye /> <span className="ms-2">{ad?.viewsCount || 0}</span>
                      </span>
                    </Badge>
                  </Col>
                ) : (
                  <></>
                )}
              </CardTitle>
            </CardBody>
            <ListGroup
              className="PostAdList"
              flush>
              <ListGroupItem>
                <CardText>
                  <span className="fw-bold">Category:</span> <span>{ad?.category?.hsnDescription || 'Not Available'}</span>
                </CardText>
              </ListGroupItem>
              <ListGroupItem>
                <CardText>
                  <span className="fw-bold">Offer Start & End Date:</span>{' '}
                  <span>
                    {ad?.offerStartDate.split('T')[0].split('-').reverse().join('/') || 'Not Available'} -{' '}
                    {ad?.offerEndDate.split('T')[0].split('-').reverse().join('/') || 'Not Available'}
                  </span>
                </CardText>
              </ListGroupItem>
              <ListGroupItem>
                <CardText>
                  <span className="fw-bold">Description:</span> <span>{ad?.description || 'Not Available'}</span>
                </CardText>
              </ListGroupItem>
              <ListGroupItem>
                <CardText>
                  <span className="fw-bold">Deal Terms:</span> <span>{ad?.dealTerms || 'Not Available'}</span>
                </CardText>
              </ListGroupItem>
            </ListGroup>

            {/* <CardBody className="text-end">
              <Button
                className="ms-2"
                color="danger"
                outline>
                Delete
              </Button>
              <Button className="primary-btn ms-2">Preview</Button>
            </CardBody> */}
          </Card>
        </ModalBody>
      </Modal>

      <Modal
        centered={true}
        isOpen={deleteModal}
        toggle={toggleDeleteModal}
        className="flex justify-center items-center">
        <ModalHeader toggle={toggleDeleteModal}>Discard Ad</ModalHeader>
        <ModalBody>Are you sure you want to delete this ad? This action cannot be undone.</ModalBody>
        <ModalFooter>
          <Button
            color="danger"
            onClick={() => {
              deleteAdHandler()
            }}>
            Confirm
          </Button>
          <Button
            color="secondary"
            onClick={toggleDeleteModal}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>
    </div>
  )
}
