import './HeaderStyle.scss'
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { MdEmail, MdLocalPhone, MdMenu, MdClose } from 'react-icons/md'
import { ReactComponent as MjProLogo } from '../../../assets/images/logos/mjPRo_Logo.svg'
import { Collapse, Navbar, NavbarToggler, NavbarBrand, Nav, NavItem, NavLink } from 'reactstrap'
import { HELPDESK_EMAIL, HELPDESK_MOBILE } from '../../../../dotenv'

const Header = () => {
  const navigate = useNavigate()

  const [isOpen, setIsOpen] = useState(false)

  const toggle = () => setIsOpen(!isOpen)

  const handleLogoClick = (e) => {
    e.preventDefault()
    navigate('/')
  }

  return (
    <div>
      <Navbar
        color="brand-color"
        dark
        expand="sm"
        className="nav__container">
        <NavbarBrand
          href="/"
          className="nav__logo"
          onClick={handleLogoClick}>
          <MjProLogo />
        </NavbarBrand>
        <NavbarToggler
          className="nav__collapse-toggler"
          onClick={toggle}>
          {isOpen ? <MdClose /> : <MdMenu />}
        </NavbarToggler>
        <Collapse
          isOpen={isOpen}
          navbar
          className="nav__collapse">
          <Nav
            className="ml-auto"
            navbar>
            <NavItem>
              <NavLink
                href={`mailto:${HELPDESK_EMAIL}`}
                className="text-dark-white">
                <MdEmail className="me-2" />
                {HELPDESK_EMAIL}
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                href={`tel:${HELPDESK_MOBILE}`}
                className="text-dark-white">
                <MdLocalPhone className="me-2" />
                {HELPDESK_MOBILE}
              </NavLink>
            </NavItem>
          </Nav>
        </Collapse>
      </Navbar>
    </div>
  )
}

export default Header
