import React from 'react'
import { Table } from 'reactstrap'

export default function ManufacturingLocationTable({ mfgLocation }) {
  return (
    <div style={{ maxHeight: '500px', overflow: 'auto' }}>
      <Table
        bordered
        responsive
        rounded>
        <thead>
          <tr>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Address</th>
            <th>PIN</th>
          </tr>
        </thead>
        <tbody>
          {mfgLocation &&
            mfgLocation.map((element) => {
              return (
                <tr key={element.id}>
                  <td>{element?.mfgCountry?.countryName || 'Not available'}</td>
                  <td>{element?.mfgState?.stateName || 'Not available'}</td>
                  <td>{element?.mfgCity?.cityName || 'Not available'}</td>
                  <td style={{ minWidth: '300px' }}>{element?.address || 'Not available'}</td>
                  <td>{element?.pinCode || 'Not available'}</td>
                </tr>
              )
            })}
        </tbody>
      </Table>
    </div>
  )
}
