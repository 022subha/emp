import React, { useState } from 'react'
import './MultiSelectDropdownStyles.scss'
import { Dropdown, DropdownToggle, DropdownMenu, DropdownItem, Input, Label } from 'reactstrap'

const MultiSelectDropdown = ({ options, value, placeHolder, onChange }) => {
  const selectedCount = value.length
  const displayPlaceholder = selectedCount > 0 ? `${selectedCount} selected` : placeHolder

  const [dropdownOpen, setDropdownOpen] = useState(false)

  const toggleDropdown = () => setDropdownOpen((prevState) => !prevState)

  const handleCheckboxChange = (optionValue) => {
    if (value.includes(optionValue)) {
      onChange(value.filter((v) => v !== optionValue))
    } else {
      onChange([...value, optionValue])
    }
  }

  const sortedOptions = [...options.filter((option) => value.includes(option.value)), ...options.filter((option) => !value.includes(option.value))]

  return (
    <Dropdown
      isOpen={dropdownOpen}
      toggle={toggleDropdown}
      className=""
      style={{ width: '100%' }}>
      <DropdownToggle
        caret
        style={{ width: '100%' }}
        className="dropdown-toggle-btn form-control">
        {displayPlaceholder}
      </DropdownToggle>
      <DropdownMenu className="dropdown-menu">
        {sortedOptions.map((option, index) => (
          <DropdownItem
            key={index}
            toggle={false}
            tag="div">
            <Label check>
              <Input
                type="checkbox"
                checked={value.includes(option.value)}
                onChange={() => handleCheckboxChange(option.value)}
              />
              {option.label}
            </Label>
          </DropdownItem>
        ))}
      </DropdownMenu>
    </Dropdown>
  )
}

export default MultiSelectDropdown
