import { toast } from 'react-toastify'
import { hideLoading, showLoading } from '../../store/slices/uiSlice'
import { verificationEndPoints } from '../api'
import { apiConnector } from '../apiConnector'

const { pan, msme, gstin } = verificationEndPoints

export const verifyPAN = (data) => {
  return async (dispatch) => {
    try {
      const response = await apiConnector('POST', pan, data)
      toast.success(response.data.message)
      return true
    } catch (error) {
      console.log(error)
      if (error.response) {
        toast.error(error.response.data.message)
      }
    }

    return false
  }
}

export const verifyMSME = (data) => {
  return async (dispatch) => {
    try {
      const response = await apiConnector('POST', msme, data)
      toast.success(response.data.message)
      return true
    } catch (error) {
      dispatch(hideLoading())
      console.log(error)
      if (error.response) {
        toast.error(error.response.data.message)
      }
    }

    return false
  }
}

export const verifyGSTIN = (data) => {
  return async (dispatch) => {
    try {
      const response = await apiConnector('POST', gstin, data)
      toast.success(response.data.message)
      dispatch(hideLoading())
      return []
    } catch (error) {
      dispatch(hideLoading())
      console.log(error)
      if (error.response) {
        toast.error(error.response.data.message)
        return error?.response?.data?.data?.failedGstins || []
      }
    }

    return []
  }
}
