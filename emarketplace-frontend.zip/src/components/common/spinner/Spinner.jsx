import React from "react";
import "./SpinnerStyle.scss";

const Spinner = () => {
  return (
    <>
      <div className="spinner-overlay"></div>
      <div className="spinner">
        <div className="spinner__atom">
          <div className="spinner__atom__inner">
            <div className="spinner__atom__inner__item">
              <div className="spinner__line"></div>
              <div className="spinner__line"></div>
              <div className="spinner__line"></div>
            </div>
          </div>
        </div>
        <p className="spinner__text">Please Wait</p>
      </div>
    </>
  );
};

export default React.memo(Spinner);
