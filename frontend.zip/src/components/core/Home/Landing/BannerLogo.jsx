import React from 'react'

import JslLogo from '../../../../assets/images/logos/jsl-logo.svg'
import HpclLogo from '../../../../assets/images/logos/hpcl-logo.svg'
import HmelLogo from '../../../../assets/images/logos/hmel-logo.svg'
import VoltasLogo from '../../../../assets/images/logos/voltas-logo.svg'
import AdventzLogo from '../../../../assets/images/logos/adventz-logo.svg'
import TataPigmentLogo from '../../../../assets/images/logos/tata-pigment-logo.svg'
import TataMetaliksLogo from '../../../../assets/images/logos/tata-metaliks-logo.svg'
import GardenVareliLogo from '../../../../assets/images/logos/garden-vareli-logo.svg'

const BannerLogo = () => {
  //const logos = [JslLogo, VoltasLogo, TataPigmentLogo, HpclLogo, HmelLogo, TataMetaliksLogo, GardenVareliLogo, AdventzLogo]
  const logos = [VoltasLogo, TataPigmentLogo, HpclLogo, HmelLogo, TataMetaliksLogo, GardenVareliLogo]

  return (
    <div className="landing-banner-logo__container">
      <div className="landing-banner-logo__scroll">
        {logos
          .concat(logos)
          .concat(logos)
          .concat(logos)
          .map((logo, index) => (
            <div
              key={`original-${index}`}
              className="landing-banner-logo__item">
              <img
                src={logo}
                alt={`Brand logo ${index}`}
              />
            </div>
          ))}
      </div>
    </div>
  )
}

export default BannerLogo
