import {
  Nav,
  Modal,
  Navbar,
  Button,
  NavItem,
  ModalBody,
  ModalHeader,
  NavbarBrand,
  ModalFooter,
  DropdownMenu,
  DropdownItem,
  DropdownToggle,
  UncontrolledDropdown,
} from "reactstrap";
import Logo from "./Logo";
import "./HeaderComponentsStyle.scss";
import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { MdLogout } from "react-icons/md";
import { useNavigate } from "react-router-dom";
import HeaderUserDropdown from "./HeaderUserDropdown";
import user1 from "../../../../assets/images/users/user4.jpg";
import { logout } from "../../../../services/controller/authAPI";
import { ToggleMobileSidebar } from "../../../../store/slices/CustomizerSlice";

const Header = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const [modal, setModal] = useState(false);

  const toggleModal = () => setModal((prev) => !prev);

  const logoutHandler = () => {
    dispatch(logout()).then((success) => {
      if (success) {
        toggleModal();
        navigate("/");
      }
    });
  };
  return (
    <>
      <Navbar expand="lg" className="topbar">
        <div
          className="d-flex align-items-center"
          style={{ backgroundColor: "#fff", height: "64px" }}
        >
          <Button
            className="d-sm-block border-0 mx-1 hov-dd"
            style={{ fontSize: "20px", background: "#00b1f1", color: "#fff" }}
            onClick={() => dispatch(ToggleMobileSidebar())}
          >
            <i className="bi bi-list" />
          </Button>
          <NavbarBrand href="/" className="d-sm-block">
            <Logo />
          </NavbarBrand>
        </div>

        <Nav className="me-auto d-flex flex-row align-items-center" navbar>
          <NavItem className="d-md-block d-none">
            <HeaderUserDropdown />
          </NavItem>
        </Nav>

        <div className="d-flex align-items-center">
          <UncontrolledDropdown className="d-sm-block d-md-none">
            <DropdownToggle color="transparent" className="hov-dd">
              <img
                src={user1}
                alt="profile"
                className="rounded-circle"
                width="30"
              />
            </DropdownToggle>
            <DropdownMenu className="w-100" style={{ marginTop: "10px" }}>
              <DropdownItem
                className="d-flex align-items-center justify-content-start gap-2 text-danger"
                onClick={toggleModal}
              >
                <MdLogout />
                <span className="text-danger fw-bold"> Logout</span>
              </DropdownItem>
            </DropdownMenu>
          </UncontrolledDropdown>

          <Modal
            isOpen={modal}
            toggle={toggleModal}
            centered
            className="custom-modal"
          >
            <ModalHeader toggle={toggleModal} className="modal-header-custom">
              Confirm Logout
            </ModalHeader>
            <ModalBody className="modal-body-custom">
              <p>
                Are you sure you want to log out? You will need to log in again
                to access your account.
              </p>
            </ModalBody>
            <ModalFooter className="modal-footer-custom">
              <Button className="btn-cancel" onClick={toggleModal}>
                Cancel
              </Button>
              <Button className="btn-logout" onClick={logoutHandler}>
                Logout
              </Button>
            </ModalFooter>
          </Modal>
        </div>
      </Navbar>
    </>
  );
};

export default Header;
