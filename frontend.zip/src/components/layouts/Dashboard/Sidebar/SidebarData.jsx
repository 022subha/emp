import * as Icon from 'react-feather'

const SidebarData = [
  {
    title: 'My Profile',
    href: '/dashboard/profile',
    icon: <Icon.User />,
    id: 2.1,
    collapisble: false
  },
  {
    title: 'Create AD',
    href: '/dashboard/ad',
    icon: <Icon.Grid />,
    id: 2.2,
    collapisble: false
  },
  {
    title: 'My Plan',
    href: '/dashboard/my-plan',
    icon: <Icon.CreditCard />,
    id: 2.3,
    collapisble: false
  }
]

export default SidebarData
