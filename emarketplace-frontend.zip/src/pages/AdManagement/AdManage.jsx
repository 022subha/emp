import React from 'react'
import './AdManageStyles.scss'
import UseSlots from './UseSlots'
import { Row, Col } from 'reactstrap'
import { useSelector } from 'react-redux'
import AvailableSlots from './AvailableSlots'

const AdManage = ({ adList, toggle }) => {
  const adSlotsRemaining = useSelector((state) => state.supplier.adSlotsRemaining)

  return (
    <div style={{ height: 'calc(100vh - 175px)', overflowY: 'auto', overflowX: 'hidden' }}>
      <Row className="p-2 py-0">
        <Col
          xs={12}
          className="mb-2">
          <h4 className="mb-1">Available Slots ({adSlotsRemaining || 0})</h4>
          <AvailableSlots toggle={toggle} />
        </Col>
        <Col xs={12}>
          <h4>Used Slots ({adList.length || 0})</h4>
          <UseSlots
            adList={adList}
            toggle={toggle}
          />
        </Col>
      </Row>
    </div>
  )
}

export default AdManage
