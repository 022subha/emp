import React from 'react'
import PropTypes from 'prop-types'
import { useSelector } from 'react-redux'

const DarkTheme = React.lazy(() => import('./DarkTheme'))
const LightTheme = React.lazy(() => import('./LightTheme'))

const ThemeSelector = ({ children }) => {
  const isDarkMode = useSelector((state) => state.customizer.isDark)
  return (
    <>
      <>{isDarkMode ? <DarkTheme /> : <LightTheme />}</>
      {children}
    </>
  )
}

ThemeSelector.propTypes = {
  children: PropTypes.node
}

export default ThemeSelector
