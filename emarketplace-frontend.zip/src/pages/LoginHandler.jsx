import React, { useEffect } from "react";
import { useDispatch } from "react-redux";
import { login } from "../services/controller/authAPI";
import { useLocation, useNavigate } from "react-router-dom";
import { SUPPLIER_STATUS, USER_TYPE } from "../data/enum";

const LoginHandler = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { state } = useLocation();

  useEffect(() => {
    if (!state?.data?.mjPROToken) {
      navigate("/");
      return;
    }

    dispatch(login(state.data.mjPROToken)).then((res) => {
      if (!res) {
        navigate("/");
        return;
      }

      const { role, supplier } = res;

      if (role === USER_TYPE.SUPPLIER) {
        handleSupplierNavigation(supplier);
      } else if (role === USER_TYPE.BUYER) {
        navigate("/buyer/ads");
      } else {
        navigate("/");
      }
    });
  }, [state]);

  const handleSupplierNavigation = (supplier) => {
    if (!supplier) {
      navigate("/");
      return;
    }

    const {
      isOtpVerified,
      subscriptionPlanId,
      subscriptionPlanExpiry,
      profileStatus,
    } = supplier;

    if (
      !isOtpVerified ||
      !subscriptionPlanId ||
      new Date(subscriptionPlanExpiry) < new Date()
    ) {
      navigate("/");
      return;
    }

    if (profileStatus === SUPPLIER_STATUS.PUBLISHED) {
      navigate("/dashboard/profile");
    } else if (profileStatus === SUPPLIER_STATUS.DRAFT) {
      navigate("/profiling");
    } else {
      navigate("/");
    }
  };

  return <div></div>;
};

export default LoginHandler;
