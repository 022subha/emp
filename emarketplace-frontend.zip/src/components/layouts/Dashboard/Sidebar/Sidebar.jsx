import React from "react";
import { Nav } from "reactstrap";
import { useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import SimpleBar from "simplebar-react";
import SidebarData from "./SidebarData";
import NavItemContainer from "./NavItemContainer";
import NavSubMenu from "./NavSubMenu";

const Sidebar = () => {
  const location = useLocation();
  const currentURL = location.pathname.split("/").slice(0, -1).join("/");

  const activeBg = useSelector((state) => state.customizer.sidebarBg);

  return (
    <div
      className={`sidebarBox fixedSidebar`}
      style={{
        background:
          "linear-gradient(180deg, #F5FAFF 0%, #E9E6FF 22%, #E4E7FF 49%, #E4F8FF 100%)",
      }}
    >
      <SimpleBar className="h-100">
        <div className="p-0">
          <Nav vertical className={activeBg === "white" ? "" : "lightText"}>
            {SidebarData.map((navi) => {
              if (navi.caption) {
                return (
                  <div
                    key={navi.caption}
                    className="navCaption text-uppercase mt-4"
                  >
                    {navi.caption}
                  </div>
                );
              }

              if (navi.children) {
                return (
                  <NavSubMenu
                    key={navi.id}
                    icon={navi.icon}
                    title={navi.title}
                    items={navi.children}
                    suffix={navi.suffix}
                    suffixColor={navi.suffixColor}
                    isUrl={currentURL === navi.href}
                  />
                );
              }

              return (
                <NavItemContainer
                  key={navi.id}
                  to={navi.href}
                  icon={navi.icon}
                  title={navi.title}
                  suffix={navi.suffix}
                  suffixColor={navi.suffixColor}
                  className={
                    location.pathname === navi.href ? "activeLink" : ""
                  }
                />
              );
            })}
          </Nav>
        </div>
      </SimpleBar>
    </div>
  );
};

export default Sidebar;
