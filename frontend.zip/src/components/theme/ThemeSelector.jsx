import React from 'react'
import { useSelector } from 'react-redux'

const DarkTheme = React.lazy(() => import('./DarkTheme'))
const LightTheme = React.lazy(() => import('./LightTheme'))

const ThemeSelector = ({ children }) => {
  const isDarkMode = useSelector((state) => state.customizer.isDark)
  return (
    <>
      <>{/* isDarkMode ? <DarkTheme /> : */ <LightTheme />}</>
      {children}
    </>
  )
}

export default ThemeSelector
