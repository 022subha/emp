import PatentUpload from './PatentUpload'
import { IoIosAdd } from 'react-icons/io'
import BrochureUpload from './BrochureUpload'
import TrademarkUpload from './TrademarkUpload'
import { MdClose, MdDelete } from 'react-icons/md'
import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Controller, useFieldArray } from 'react-hook-form'
import { IoMdInformationCircleOutline } from 'react-icons/io'
import { fetchCityList, fetchStateList } from '../../../services/controller/masterAPI'
import MultiSelectDropdown from '../../../components/ui/multi-select/MultiSelectDropDown'
import { Container, Row, Col, Form, FormGroup, Label, Input, Button, Tooltip } from 'reactstrap'

export default function OperationForm({
  register,
  watch,
  control,
  errors,
  setValue,
  opBrochures,
  setOpBrochures,
  opTradeMarks,
  setOpTradeMarks,
  opPatents,
  setOpPatents,
  keyPartnership
}) {
  return (
    <div>
      <Container
        fluid
        className="bg-transparent">
        <Form>
          <h2 className="dataForm_header mb-2">Operational Data</h2>

          <ManufacturingLocation
            register={register}
            control={control}
            watch={watch}
            errors={errors}
            setValue={setValue}
          />

          <ProductionCapacity
            register={register}
            control={control}
            watch={watch}
            errors={errors}
          />

          <BussinessOperation
            register={register}
            control={control}
            watch={watch}
            errors={errors}
            keyPartnership={keyPartnership}
          />

          <FinancialBussinessDetails
            register={register}
            control={control}
            watch={watch}
            errors={errors}
          />

          <ItemCategory
            register={register}
            control={control}
            watch={watch}
            errors={errors}
            keyPartnership={keyPartnership}
          />

          <AttachmentsAndCertifications
            register={register}
            control={control}
            watch={watch}
            errors={errors}
            opBrochures={opBrochures}
            setOpBrochures={setOpBrochures}
            opTradeMarks={opTradeMarks}
            setOpTradeMarks={setOpTradeMarks}
            opPatents={opPatents}
            setOpPatents={setOpPatents}
          />
        </Form>
      </Container>
    </div>
  )
}

const ManufacturingLocation = ({ register, control, watch, errors, setValue }) => {
  const dispatch = useDispatch()

  const initialValue = {
    country: '',
    state: '',
    city: '',
    address: '',
    pinCode: ''
  }

  const cities = useSelector((state) => state.master.cityList)
  const states = useSelector((state) => state.master.stateList)
  const countries = useSelector((state) => state.master.countryList)

  const { fields: locationFields, append: addLocation, remove: removeLocation } = useFieldArray({ control, name: 'manufacturingLocations' })

  const handleCountryChange = (countryId, index) => {
    setValue(`manufacturingLocations[${index}].state`, '')
    setValue(`manufacturingLocations[${index}].city`, '')
    if (!states[countryId]) {
      dispatch(fetchStateList(countryId))
    }
  }

  const handleStateChange = (countryId, stateId, index) => {
    setValue(`manufacturingLocations[${index}].city`, '')
    if (!cities[`${countryId}-${stateId}`]) {
      dispatch(fetchCityList(countryId, stateId))
    }
  }

  return (
    <Row className="mb-2">
      <Col xs={12}>
        <Row className="d-flex align-items-center justify-content-between">
          <Col>
            <h4 className="dataForm_subHeader mb-0">Manufacturing Location</h4>
          </Col>

          <Col>
            <Button
              type="button"
              className="addMore_Data"
              onClick={() => addLocation(initialValue)}>
              <IoIosAdd style={{ color: 'white', fontSize: '1.5rem' }} />
            </Button>
          </Col>
        </Row>
      </Col>
      {locationFields.map((field, index) => (
        <Col
          xs={12}
          key={field.id}>
          <Row className="operational-form__location-container">
            <Col xs={12}>
              <Row>
                <Col>
                  {locationFields.length > 1 && (
                    <h4
                      style={{
                        color: '#000',
                        fontWeight: '500',
                        fontSize: '16px'
                      }}>
                      Location #{index + 1}
                    </h4>
                  )}
                </Col>

                {index !== 0 && (
                  <Col className="d-flex justify-content-end">
                    <MdDelete
                      style={{ color: 'rgb(255 72 72)', fontSize: '1.2rem', cursor: 'pointer' }}
                      onClick={() => removeLocation(index)}
                    />
                  </Col>
                )}

                {/* {index !== 0 && (
                  <Col>
                    <Button
                      type="button"
                      className="addMore_Data"
                      style={{ backgroundColor: 'red', border: 'none' }}>
                      <MdDelete
                        style={{ color: 'white', fontSize: '1.2rem' }}
                        onClick={() => removeLocation(index)}
                      />
                    </Button>
                  </Col>
                )} */}
              </Row>
            </Col>
            <Col
              md={4}
              xs={12}>
              <FormGroup className="operational-form__location-input-container">
                <Label
                  for="country"
                  className="operational-form__label">
                  Country
                </Label>
                <Controller
                  name={`manufacturingLocations[${index}].country`}
                  control={control}
                  defaultValue=""
                  rules={{
                    required: 'Country is required'
                  }}
                  render={({ field, fieldState: { error } }) => (
                    <>
                      <Input
                        {...field}
                        type="select"
                        invalid={error ? true : false}
                        className={error ? 'error-input' : ''}
                        id={`manufacturingLocations[${index}].country`}
                        onChange={(e) => {
                          field.onChange(e)
                          handleCountryChange(e.target.value, index)
                        }}>
                        <option value="">Select Country</option>
                        {(countries || []).map((item) => (
                          <option
                            value={item.id}
                            key={item.id}>
                            {item.countryName}
                          </option>
                        ))}
                      </Input>
                      {error && <span className="text-danger error-message">{error.message}</span>}
                    </>
                  )}
                />
              </FormGroup>
            </Col>
            <Col
              md={4}
              xs={12}>
              <FormGroup className="operational-form__location-input-container">
                <Label
                  for="state"
                  className="operational-form__label">
                  State
                </Label>
                <Controller
                  name={`manufacturingLocations[${index}].state`}
                  control={control}
                  defaultValue=""
                  rules={{
                    required: 'State is required'
                  }}
                  render={({ field, fieldState: { error } }) => (
                    <>
                      <Input
                        {...field}
                        type="select"
                        invalid={error ? true : false}
                        className={error ? 'error-input' : ''}
                        id={`manufacturingLocations[${index}].state`}
                        onChange={(e) => {
                          field.onChange(e)
                          const country = watch(`manufacturingLocations[${index}].country`)
                          handleStateChange(country, e.target.value, index)
                        }}>
                        <option value="">Select State</option>
                        {(states[watch(`manufacturingLocations[${index}].country`)] || []).map((item) => (
                          <option
                            value={item.id}
                            key={item.id}>
                            {item.stateName}
                          </option>
                        ))}
                      </Input>
                      {error && <span className="text-danger error-message">{error.message}</span>}
                    </>
                  )}
                />
              </FormGroup>
            </Col>
            <Col
              md={4}
              xs={12}>
              <FormGroup className="operational-form__location-input-container">
                <Label
                  for="city"
                  className="operational-form__label">
                  City
                </Label>
                <Controller
                  name={`manufacturingLocations[${index}].city`}
                  control={control}
                  defaultValue=""
                  rules={{
                    required: 'City is required'
                  }}
                  render={({ field, fieldState: { error } }) => (
                    <>
                      <Input
                        {...field}
                        type="select"
                        invalid={error ? true : false}
                        className={error ? 'error-input' : ''}
                        id={`manufacturingLocations[${index}].city`}>
                        <option value="">Select City</option>
                        {(
                          cities[`${watch(`manufacturingLocations[${index}].country`)}-${watch(`manufacturingLocations[${index}].state`)}`] || []
                        ).map((item) => (
                          <option
                            value={item.id}
                            key={item.id}>
                            {item.cityName}
                          </option>
                        ))}
                      </Input>
                      {error && <span className="text-danger error-message">{error.message}</span>}
                    </>
                  )}
                />
              </FormGroup>
            </Col>
            <Col
              md={8}
              xs={12}>
              <FormGroup className="operational-form__location-input-container">
                <Label
                  for="manufactureAddress"
                  className="operational-form__label ">
                  Address
                </Label>
                <Controller
                  name={`manufacturingLocations[${index}].address`}
                  control={control}
                  defaultValue=""
                  rules={{
                    maxLength: {
                      value: 300,
                      message: 'Address cannot exceed 300 characters'
                    }
                  }}
                  render={({ field, fieldState: { error } }) => (
                    <>
                      <Input
                        {...field}
                        type="text"
                        invalid={error ? true : false}
                        placeholder="Enter Manufacturing Address"
                        id={`manufacturingLocations[${index}].address`}
                      />
                      {error && <span className="text-danger error-message">{error.message}</span>}
                    </>
                  )}
                />
              </FormGroup>
            </Col>
            <Col
              md={4}
              xs={12}>
              <FormGroup className="operational-form__location-input-container">
                <Label
                  for="pinCode"
                  className="operational-form__label ">
                  Pin Code
                </Label>
                <Controller
                  name={`manufacturingLocations[${index}].pinCode`}
                  control={control}
                  defaultValue=""
                  rules={{
                    pattern: {
                      value: /^[1-9][0-9]{5}$/,
                      message: 'Invalid pin code'
                    }
                  }}
                  render={({ field, fieldState: { error } }) => (
                    <>
                      <Input
                        {...field}
                        type="number"
                        invalid={error ? true : false}
                        placeholder="Enter Pin Code"
                        id={`manufacturingLocations[${index}].pinCode`}
                      />
                      {error && <span className="text-danger error-message">{error.message}</span>}
                    </>
                  )}
                />
              </FormGroup>
            </Col>
          </Row>
        </Col>
      ))}
    </Row>
  )
}

const ProductionCapacity = ({ control }) => {
  const initialValue = {
    materialName: '',
    capacity: '',
    uom: ''
  }

  const uomList = useSelector((state) => state.master.uomList)

  const { fields: capacityFields, append: addCapacity, remove: removeCapacity } = useFieldArray({ control, name: 'productionCapacities' })

  return (
    <Row className="mb-2">
      <Col xs={12}>
        <Row>
          <Col>
            <h4 className="dataForm_subHeader mb-0">Production Capacity</h4>
          </Col>
          <Col>
            <Button
              type="button"
              className="addMore_Data"
              onClick={() => addCapacity(initialValue)}>
              <IoIosAdd style={{ color: 'white', fontSize: '1.5rem' }} />
            </Button>
          </Col>
        </Row>
      </Col>
      {capacityFields.map((field, index) => (
        <Col
          xs={12}
          key={field.id}>
          <Row className="operational-form__capacity-container">
            <Col xs={12}>
              <Row>
                <Col>
                  {capacityFields.length > 1 && (
                    <h4
                      style={{
                        color: '#000',
                        fontWeight: '500',
                        fontSize: '16px'
                      }}>
                      Material #{index + 1}
                    </h4>
                  )}
                </Col>
                {index !== 0 && (
                  <Col className="d-flex justify-content-end">
                    <MdDelete
                      style={{ color: 'rgb(255 72 72)', fontSize: '1.2rem', cursor: 'pointer' }}
                      onClick={(e) => removeCapacity(index)}
                    />
                  </Col>
                )}
                {/* {index !== 0 && (
                  <Col>
                    <Button
                      type="button"
                      className="addMore_Data"
                      style={{ backgroundColor: 'red', border: 'none' }}>
                      <MdDelete
                        style={{ color: 'white', fontSize: '1.2rem' }}
                        onClick={(e) => removeCapacity(index)}
                      />
                    </Button>
                  </Col>
                )} */}
              </Row>
            </Col>
            <Col
              md={8}
              xs={12}>
              <FormGroup className="operational-form__capacity-input-container">
                <Label
                  for="materialName"
                  className="operational-form__label  mandatory-label">
                  Material Name
                </Label>
                <Controller
                  name={`productionCapacities[${index}].materialName`}
                  control={control}
                  defaultValue=""
                  rules={{
                    required: 'Material Name is required'
                  }}
                  render={({ field, fieldState: { error } }) => (
                    <>
                      <Input
                        {...field}
                        type="text"
                        invalid={error ? true : false}
                        placeholder="Enter Material Name"
                        className={error ? 'error-input' : ''}
                        id={`productionCapacities[${index}].materialName`}
                      />
                      {error && <span className="text-danger error-message">{error.message}</span>}
                    </>
                  )}
                />
              </FormGroup>
            </Col>
            <Col
              md={2}
              xs={12}>
              <FormGroup className="operational-form__capacity-input-container">
                <Label
                  for="productionName"
                  className="operational-form__label  mandatory-label">
                  {/* Production */} Capacity
                </Label>
                <div className="">
                  <Controller
                    name={`productionCapacities[${index}].capacity`}
                    control={control}
                    defaultValue=""
                    rules={{
                      required: 'Production Capacity is required'
                    }}
                    render={({ field, fieldState: { error } }) => (
                      <>
                        <Input
                          {...field}
                          type="number"
                          invalid={error ? true : false}
                          placeholder="Enter Production Capacity"
                          className={error ? 'error-input' : ''}
                          id={`productionCapacities[${index}].capacity`}
                        />
                        {error && <span className="text-danger error-message">{error.message}</span>}
                      </>
                    )}
                  />
                  {/* <Controller
                    name={`productionCapacities[${index}].uom`}
                    control={control}
                    defaultValue=""
                    rules={{
                      required: 'UOM is required'
                    }}
                    render={({ field, fieldState: { error } }) => (
                      <>
                        <Input
                          {...field}
                          type="select"
                          invalid={error ? true : false}
                          className={error ? 'error-input' : ''}
                          id={`productionCapacities[${index}].uom`}>
                          <option value="">Select UOM</option>
                          {uomList.map((item) => (
                            <option
                              value={item.id}
                              key={item.id}>
                              {item.name} ({item.shortName})
                            </option>
                          ))}
                        </Input>
                        {error && <span className="text-danger error-message">{error.message}</span>}
                      </>
                    )}
                  /> */}
                </div>
              </FormGroup>
            </Col>
            <Col
              md={2}
              xs={12}>
              <FormGroup className="operational-form__capacity-input-container">
                <Label
                  for="uom"
                  className="operational-form__label  mandatory-label">
                  UOM
                </Label>
                <Controller
                  name={`productionCapacities[${index}].uom`}
                  control={control}
                  defaultValue=""
                  rules={{
                    required: 'UOM is required'
                  }}
                  render={({ field, fieldState: { error } }) => (
                    <>
                      <Input
                        {...field}
                        type="select"
                        invalid={error ? true : false}
                        className={error ? 'error-input' : ''}
                        id={`productionCapacities[${index}].uom`}>
                        <option value="">Select UOM</option>
                        {uomList.map((item) => (
                          <option
                            value={item.id}
                            key={item.id}>
                            {item.name} ({item.shortName})
                          </option>
                        ))}
                      </Input>
                      {error && <span className="text-danger error-message">{error.message}</span>}
                    </>
                  )}
                />
              </FormGroup>
            </Col>
          </Row>
        </Col>
      ))}
    </Row>
  )
}

const BussinessOperation = ({ register, control, watch, errors, keyPartnership }) => {
  const countries = useSelector((state) => state.master.countryList)
  const natureOfBussiness = useSelector((state) => state.master.natureOfBussiness)
  const [top10Customers, setTop10Customers] = useState('')
  const { fields: top10CustomersFields, append: addtop10Customers, remove: removetop10Customers } = useFieldArray({ control, name: 'top10Customers' })

  return (
    <Row>
      <Col xs={12}>
        <h4 className="dataForm_subHeader mb-0">Bussiness Operation</h4>
      </Col>
      <Col>
        <Row className="mb-2 operational-form__bussiness-container">
          <Col
            md={3}
            xs={12}>
            <FormGroup className="operational-form__bussiness-input-container">
              <Label
                for="country"
                className="operational-form__label ">
                Nature of Business
              </Label>
              <Controller
                name={`natureOfBussiness`}
                control={control}
                defaultValue=""
                render={({ field, fieldState: { error } }) => (
                  <>
                    <Input
                      {...field}
                      type="select"
                      id="natureOfBussiness">
                      <option value="">Select Nature of Bussiness</option>
                      {natureOfBussiness.map((item) => (
                        <option value={item.id}>{item.name}</option>
                      ))}
                    </Input>
                  </>
                )}
              />
            </FormGroup>
          </Col>
          <Col
            md={3}
            xs={12}>
            <FormGroup className="operational-form__bussiness-input-container">
              <Label
                for="state"
                className="operational-form__label ">
                Countries Doing Business in
              </Label>
              <Controller
                name={'countriesDoingBussinessIn'}
                control={control}
                render={({ field }) => (
                  <MultiSelectDropdown
                    placeHolder="Select Countries"
                    options={countries.map((item) => ({ value: item.id, label: item.countryName }))}
                    value={field.value}
                    onChange={field.onChange}
                  />
                )}
              />
            </FormGroup>
          </Col>
          <Col
            md={3}
            xs={12}>
            <FormGroup className="operational-form__bussiness-input-container">
              <Label
                for="employeesNumber"
                className="operational-form__label">
                Total Number of Employees
              </Label>
              <input
                type="number"
                id="employeesNumber"
                className="form-control"
                placeholder="Employees Number"
                {...register('employeesNumber')}
              />
            </FormGroup>
          </Col>
          <Row className="opeartional-form__bussiness-input-container">
            <Col
              md={12}
              xs={12}>
              <FormGroup className="opeartional-form__bussiness-input-container">
                <Label
                  for="city"
                  className="operational-form__label ">
                  Top 10 Customers
                </Label>
                <Row className="d-flex align-items-center justify-content-between mb-1">
                  {/* <MultiSelectDropdown
                        placeHolder="Select Top 10 Buyers"
                        options={(keyPartnership || []).map((item) => ({ value: item.label, label: item.label }))}
                        value={field.value}
                        onChange={field.onChange}
                      /> */}

                  <Col className="flex-grow-1">
                    <Input
                      type="text"
                      id="top10Customers"
                      placeholder="Enter a customer name"
                      value={top10Customers}
                      onChange={(e) => {
                        setTop10Customers(e.target.value)
                      }}
                    />
                  </Col>
                  <Col xs={'auto'}>
                    <Button
                      type="button"
                      className="addMore_Data"
                      onClick={() => {
                        if (top10Customers.trim()) {
                          addtop10Customers({ name: top10Customers })
                          setTop10Customers('')
                        }
                      }}>
                      <IoIosAdd style={{ color: 'white', fontSize: '1.5rem' }} />
                    </Button>
                  </Col>
                </Row>
                <Row>
                  {top10CustomersFields.map((field, index) => (
                    <Col
                      xs="auto"
                      key={field.id}
                      className="mb-2"
                      style={{ paddingRight: 0 }}>
                      <div className="operational-form__financial-chip-container">
                        <span className="me-2 operational-form__financial-chip-name">{field.name}</span>
                        <button
                          type="button"
                          className="operational-form__financial-chip-button"
                          onClick={() => removetop10Customers(index)}>
                          <MdClose />
                        </button>
                      </div>
                    </Col>
                  ))}
                </Row>
              </FormGroup>
            </Col>
          </Row>
          <Col
            md={12}
            xs={12}>
            <FormGroup className="opeartional-form__bussiness-input-container">
              <Label
                for="whyUs"
                className="operational-form__label mandatory-label">
                Why Us?
              </Label>
              <Controller
                name={`whyUs`}
                control={control}
                defaultValue=""
                rules={{ maxLength: { value: 300, message: "Why Us can't exceed 300 characters" } }}
                render={({ field, fieldState: { error } }) => (
                  <>
                    <Input
                      {...field}
                      type="textarea"
                      id="whyUS"
                      placeholder="Write Something about yourself...."
                      invalid={error ? true : false}
                    />
                    {error && <p className="error-message text-danger">{error.message}</p>}
                  </>
                )}
              />
            </FormGroup>
          </Col>
        </Row>
      </Col>
    </Row>
  )
}

const FinancialBussinessDetails = ({ register, control, watch, errors }) => {
  const [subsidary, setSubsidary] = useState('')
  const [tooltipOpen, setTooltipOpen] = useState(false)
  const [financialYear, setFinancialYear] = useState('')

  const { fields: subsidiaryFields, append: addSubsidiary, remove: removeSubsidiary } = useFieldArray({ control, name: 'subsidiaries' })

  const toggle = () => setTooltipOpen(!tooltipOpen)

  const calculateFinancialYear = () => {
    const currentDate = new Date()
    const currentMonth = currentDate.getMonth()
    const currentYear = currentDate.getFullYear()

    let startYear
    if (currentMonth < 3) {
      startYear = currentYear - 1
    } else {
      startYear = currentYear
    }

    return `${startYear}`
  }

  useEffect(() => {
    setFinancialYear(calculateFinancialYear())
  }, [])

  return (
    <Row className="mb-2">
      <Col xs={12}>
        <h4 className="dataForm_subHeader">Financial and Business Details</h4>
      </Col>
      <Col
        md={4}
        xs={12}>
        <FormGroup>
          <Label
            for="yearTurnover"
            className="operational-form__label">
            Last 3 Years Yearly Turnover (in INR)
          </Label>
          <Row>
            <Col
              sm={12}
              md={4}>
              <input
                type="number"
                id="year1Turnover"
                className="form-control"
                placeholder={financialYear}
                {...register('year1Turnover')}
              />
            </Col>
            <Col
              sm={12}
              md={4}>
              <input
                type="number"
                id="year2Turnover"
                className="form-control"
                placeholder={`${parseInt(financialYear) - 1}`}
                {...register('year2Turnover')}
              />
            </Col>
            <Col
              sm={12}
              md={4}>
              <input
                type="number"
                id="year3Turnover"
                className="form-control"
                placeholder={`${parseInt(financialYear) - 2}`}
                {...register('year3Turnover')}
              />
            </Col>
          </Row>
        </FormGroup>
      </Col>
      <Col
        md={4}
        xs={12}>
        <FormGroup>
          <Label
            for="creditRating"
            className="operational-form__label">
            Credit Rating
            {/* <span id="moreInfoData">
              <IoMdInformationCircleOutline />
            </span>
            <Tooltip
              placement="top"
              isOpen={tooltipOpen}
              autohide={false}
              target="moreInfoData"
              toggle={toggle}>
              Try to select this text!
            </Tooltip> */}
          </Label>
          <Controller
            name="creditRating"
            control={control}
            defaultValue=""
            rules={{
              maxLength: { value: 10, message: "Credit Rating can't exceed 10 characters" }
            }}
            render={({ field, fieldState: { error } }) => (
              <>
                <Input
                  {...field}
                  type="text"
                  invalid={error ? true : false}
                  className={error ? 'error-input' : ''}
                  id="creditRating"
                />
                {error && <span className="text-danger error-message">{error.message}</span>}
              </>
            )}
          />
        </FormGroup>
      </Col>
      <Col
        md={4}
        xs={12}>
        <Label className="operational-form__label">OEM Service</Label>
        <Controller
          name="oemService"
          control={control}
          defaultValue={''}
          render={({ field, fieldState: { error } }) => (
            <Form>
              <FormGroup
                check
                inline>
                <Input
                  {...field}
                  type="radio"
                  value="Y"
                  checked={field.value === 'Y'}
                />
                <Label check>Yes</Label>
              </FormGroup>
              <FormGroup
                check
                inline>
                <Input
                  {...field}
                  type="radio"
                  value="N"
                  checked={field.value === 'N'}
                />
                <Label check>No</Label>
              </FormGroup>
              {error && <span className="text-danger">{error.message}</span>}
            </Form>
          )}
        />
      </Col>
      <Col xs={12}>
        <FormGroup>
          <Label
            for="creditRating"
            className="operational-form__label">
            Subsidiaries
          </Label>
          <Row className="d-flex align-items-center justify-content-between mb-1">
            <Col className="flex-grow-1">
              <Input
                type="text"
                id="subsidiaries"
                placeholder="Enter a subsidiary name"
                value={subsidary}
                onChange={(e) => {
                  setSubsidary(e.target.value)
                }}
              />
            </Col>
            <Col xs={'auto'}>
              <Button
                type="button"
                className="addMore_Data"
                onClick={() => {
                  if (subsidary.trim()) {
                    addSubsidiary({ name: subsidary })
                    setSubsidary('')
                  }
                }}>
                <IoIosAdd style={{ color: 'white', fontSize: '1.5rem' }} />
              </Button>
            </Col>
          </Row>
          <Row>
            {subsidiaryFields.map((field, index) => (
              <Col
                xs="auto"
                key={field.id}
                className="mb-2"
                style={{ paddingRight: 0 }}>
                <div className="operational-form__financial-chip-container">
                  <span className="me-2 operational-form__financial-chip-name">{field.name}</span>
                  <button
                    type="button"
                    className="operational-form__financial-chip-button"
                    onClick={() => removeSubsidiary(index)}>
                    <MdClose />
                  </button>
                </div>
              </Col>
            ))}
          </Row>
        </FormGroup>
      </Col>
    </Row>
  )
}

const ItemCategory = ({ register, control, watch, errors, setValue, keyPartnership }) => {
  const initialValue = {
    category: '',
    value: '',
    currency: '',
    capacity: '',
    uom: '',
    topBuyers: []
  }
  const uomList = useSelector((state) => state.master.uomList)
  const countryList = useSelector((state) => state.master.countryList)
  const hsnCategories = useSelector((state) => state.master.hsnCategories)

  const { fields: categoryFields, append: addCategory, remove: removeCategory } = useFieldArray({ control, name: 'itemCategories' })

  return (
    <Row className="mb-2">
      <Col xs={12}>
        <Row>
          <Col>
            <h4 className="dataForm_subHeader">Item category</h4>
          </Col>
          <Col>
            <Button
              type="button"
              className="addMore_Data"
              onClick={() => addCategory(initialValue)}>
              <IoIosAdd style={{ color: 'white', fontSize: '1.5rem' }} />
            </Button>
          </Col>
        </Row>
      </Col>
      {categoryFields.map((field, index) => (
        <Col
          xs={12}
          key={field.id}>
          <Row className="operational-form__item-category-container">
            <Col xs={12}>
              <Row>
                <Col>
                  {categoryFields.length > 1 && (
                    <h4
                      style={{
                        color: '#000',
                        fontWeight: '500',
                        fontSize: '16px'
                      }}>
                      Category #{index + 1}
                    </h4>
                  )}
                </Col>

                {index !== 0 && (
                  <Col className="d-flex justify-content-end">
                    <MdDelete
                      style={{ color: 'rgb(255 72 72)', fontSize: '1.2rem', cursor: 'pointer' }}
                      onClick={() => removeCategory(index)}
                    />
                  </Col>
                )}
                {/* {index !== 0 && (
                  <Col>
                    <Button
                      type="button"
                      className="addMore_Data"
                      style={{ backgroundColor: 'red', border: 'none' }}>
                      <MdDelete
                        style={{ color: 'white', fontSize: '1.2rem' }}
                        onClick={() => removeCategory(index)}
                      />
                    </Button>
                  </Col>
                )} */}
              </Row>
            </Col>
            <Col
              md={6}
              xs={12}>
              <FormGroup className="operational-form__item-category-input-container">
                <Label
                  for="yearEstablishment"
                  className="operational-form__label mandatory-label">
                  Category
                </Label>
                <Controller
                  name={`itemCategories[${index}].category`}
                  control={control}
                  defaultValue=""
                  rules={{
                    required: 'Category is required'
                  }}
                  render={({ field, fieldState: { error } }) => (
                    <>
                      <Input
                        {...field}
                        type="select"
                        invalid={error ? true : false}
                        className={error ? 'error-input' : ''}
                        id={`itemCategories[${index}].country`}>
                        <option value="">Select Category</option>
                        {(hsnCategories || []).map((item) => (
                          <option
                            key={item.id}
                            value={item.id}>
                            {item.hsnDescription} ({item.hsnCode.toString().padStart(4, '0')})
                          </option>
                        ))}
                      </Input>
                      {error && <span className="text-danger error-message">{error.message}</span>}
                    </>
                  )}
                />
              </FormGroup>
            </Col>
            <Col
              md={3}
              xs={12}>
              <FormGroup>
                <Label
                  for="orderSupply"
                  className="operational-form__label">
                  Value of Order Supplied
                </Label>
                <input
                  type="number"
                  className="form-control"
                  id={`itemCategories[${index}].value`}
                  {...register(`itemCategories[${index}].value`)}
                />
              </FormGroup>
            </Col>
            <Col
              md={3}
              xs={12}>
              <FormGroup>
                <Label
                  for="currencyIc"
                  className={watch(`itemCategories[${index}].value`) === 'operational-form__label' ? '' : 'operational-form__label mandatory-label'}>
                  Currency
                </Label>
                <Controller
                  name={`itemCategories[${index}].currency`}
                  control={control}
                  defaultValue=""
                  rules={{
                    validate: (value) => {
                      const categoryValue = watch(`itemCategories[${index}].value`)
                      if (categoryValue !== '') {
                        return value !== '' || 'Currency is required'
                      }
                      return true
                    }
                  }}
                  render={({ field, fieldState: { error } }) => (
                    <>
                      <Input
                        {...field}
                        type="select"
                        invalid={watch(`itemCategories[${index}].value`) !== '' && error ? true : false}
                        className={error ? 'error-input' : ''}
                        disabled={watch(`itemCategories[${index}].value`) === ''}
                        id={`itemCategories[${index}].currency`}>
                        <option value="">Select Currency</option>
                        {countryList &&
                          [...new Map(countryList.map((item) => [item.currency, item])).values()]
                            .sort((a, b) => a.currency.localeCompare(b.currency))
                            .map((item) => (
                              <option
                                key={item.id}
                                value={item.currency}>
                                {item.currency} ({item.currencyName})
                              </option>
                            ))}
                      </Input>
                      {error && <span className="text-danger error-message">{error.message}</span>}
                    </>
                  )}
                />
              </FormGroup>
            </Col>
            <Col
              md={6}
              xs={12}>
              <FormGroup>
                <Label
                  for="topBuyer"
                  className="operational-form__label">
                  Top Customers
                </Label>
                <Controller
                  name={`itemCategories[${index}].topBuyers`}
                  control={control}
                  render={({ field }) => (
                    <MultiSelectDropdown
                      placeHolder="Select Top Buyers"
                      options={(keyPartnership || []).map((item) => ({ value: item.label, label: item.label }))}
                      value={field.value}
                      onChange={field.onChange}
                    />
                  )}
                />
              </FormGroup>
            </Col>
            <Col
              md={3}
              xs={12}>
              <FormGroup>
                <Label
                  for="uomIc"
                  className={
                    watch(`itemCategories[${index}].capacity`) === '' ? 'operational-form__label' : 'operational-form__label mandatory-label'
                  }>
                  UOM
                </Label>
                <Controller
                  defaultValue=""
                  control={control}
                  name={`itemCategories[${index}].uom`}
                  rules={{
                    validate: (value) => {
                      const categoryValue = watch(`itemCategories[${index}].capacity`)
                      if (categoryValue !== '') {
                        return value !== '' || 'UOM is required'
                      }
                      return true
                    }
                  }}
                  render={({ field, fieldState: { error } }) => (
                    <>
                      <Input
                        {...field}
                        type="select"
                        id={`itemCategories[${index}].uom`}
                        className={error ? 'error-input' : ''}
                        disabled={watch(`itemCategories[${index}].capacity`) === ''}
                        invalid={watch(`itemCategories[${index}].capacity`) !== '' && error}>
                        <option value="">Select UOM</option>
                        {uomList.map((item) => (
                          <option
                            value={item.id}
                            key={item.id}>
                            {item.name} ({item.shortName})
                          </option>
                        ))}
                      </Input>
                      {error && <span className="text-danger error-message">{error.message}</span>}
                    </>
                  )}
                />
              </FormGroup>
            </Col>
            <Col
              md={3}
              xs={12}>
              <FormGroup>
                <Label
                  for="capacity"
                  className="operational-form__label">
                  Capacity
                </Label>
                <input
                  type="number"
                  className="form-control"
                  placeholder="Capacity"
                  id={`itemCategories[${index}].capacity`}
                  {...register(`itemCategories[${index}].capacity`)}
                />
              </FormGroup>
            </Col>
          </Row>
        </Col>
      ))}
    </Row>
  )
}

const AttachmentsAndCertifications = ({
  register,
  control,
  watch,
  errors,
  opBrochures,
  setOpBrochures,
  opTradeMarks,
  setOpTradeMarks,
  opPatents,
  setOpPatents
}) => {
  return (
    <Row className="mb-2">
      <Col xs={12}>
        <h4 className="dataForm_subHeader">Attachments and Certifications</h4>
      </Col>
      <Col xs={12}>
        <BrochureUpload
          register={register}
          files={opBrochures}
          setFiles={setOpBrochures}
        />
      </Col>
      <Col xs={12}>
        <TrademarkUpload
          files={opTradeMarks}
          setFiles={setOpTradeMarks}
        />
      </Col>
      <Col xs={12}>
        <PatentUpload
          files={opPatents}
          setFiles={setOpPatents}
        />
      </Col>
    </Row>
  )
}
