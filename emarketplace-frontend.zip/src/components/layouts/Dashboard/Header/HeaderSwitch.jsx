import { Button } from 'reactstrap'
import React, { useEffect, useState } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css'
import { useSelector } from 'react-redux'

const HeaderSwitch = () => {
  const currentUser = useSelector((state) => state.user)
  const [activeTab, setActiveTab] = useState('Supplier')
  useEffect(() => {
    setActiveTab(currentUser?.role === 'supplier' ? 'Supplier' : 'Buyer')
  }, [currentUser])
  return (
    <div
      style={{
        display: 'inline-block',
        backgroundColor: '#e9f3fc',
        borderRadius: '25px',
        padding: '4px',
        position: 'relative',
        width: '180px',
        height: '40px'
      }}>
      {/* Capsule-like background */}
      <div
        style={{
          position: 'absolute',
          top: '4px',
          left: activeTab === 'Supplier' ? '4px' : 'calc(50% + 2px)',
          width: '85px',
          height: '32px',
          background: 'linear-gradient(93.59deg, #1F6BFF -26.11%, #37D9E3 122.69%)',
          borderRadius: '25px',
          transition: 'left 0.3s ease',
          zIndex: 1
        }}></div>

      {/* Buttons */}
      <Button
        onClick={() => setActiveTab('Supplier')}
        style={{
          position: 'absolute',
          zIndex: 2,
          left: '0',
          top: '0',
          width: '50%',
          height: '100%',
          background: 'transparent',
          border: 'none',
          borderRadius: '25px',
          color: activeTab === 'Supplier' ? '#fff' : '#6c757d',
          fontWeight: 'bold',
          cursor: 'pointer'
        }}>
        Supplier
      </Button>
      <Button
        onClick={() => setActiveTab('Buyer')}
        style={{
          position: 'absolute',
          zIndex: 2,
          right: '0',
          top: '0',
          width: '50%',
          height: '100%',
          background: 'transparent',
          border: 'none',
          borderRadius: '25px',
          color: activeTab === 'Buyer' ? '#fff' : '#6c757d',
          fontWeight: 'bold',
          cursor: 'pointer'
        }}>
        Buyer
      </Button>
    </div>
  )
}

export default HeaderSwitch
