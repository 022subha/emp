import React from 'react'
import { Container, Row, Col, Card, CardHeader, CardBody, CardFooter, CardText, Progress } from 'reactstrap'
import { BsPatchCheck } from 'react-icons/bs'
import './BuyPlanComponentStyles.scss'

const PaymentConfirm = () => {
  return (
    <div className="payment-confirmation__container">
      <Container
        className="d-flex flex-column justify-content-center"
        style={{ height: 'calc(100vh - 167px)' }}>
        <Row>
          <Col sm={12}>
            <Container>
              <Card className="bg-transparent GlossBg p-4">
                <CardHeader className="bg-transparent text-center">
                  <BsPatchCheck className="display-2 fw-bold text-success mb-2" />
                </CardHeader>
                <CardBody>
                  <CardText className="text-light text-center fs-2">
                    Your payment has been successfully Processed.
                    <br />
                    The invoice has been sent to your registered email id.
                  </CardText>
                </CardBody>
                <CardFooter>
                  <Row>
                    <Col
                      sm={12}
                      className="text-center text-light fs-4 mb-2">
                      Redirecting to mjPRO home
                    </Col>
                    <Col sm={12}>
                      <Progress
                        value={50}
                        color="success"
                        className="w-100"
                      />
                    </Col>
                  </Row>
                </CardFooter>
              </Card>
            </Container>
          </Col>
        </Row>
      </Container>
    </div>
  )
}

export default PaymentConfirm
