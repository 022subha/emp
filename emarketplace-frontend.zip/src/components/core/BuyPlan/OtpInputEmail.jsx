import React, { useRef } from 'react'

const OTPInputEmail = ({ otp, setOtp }) => {
  const inputRefs = useRef([])

  const handleChange = (element, index) => {
    const value = element.value.replace(/[^0-9]/g, '')
    const otpCopy = [...otp]
    otpCopy[index] = value

    if (value && index < 5) {
      inputRefs.current[index + 1].focus()
    }

    setOtp(otpCopy)
  }

  const handleBackspace = (e, index) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      inputRefs.current[index - 1].focus()
    }
  }

  const handlePaste = (e) => {
    const data = e.clipboardData.getData('Text').slice(0, 6).split('')
    const otpCopy = [...otp]
    data.forEach((value, i) => {
      if (!/^\d$/.test(value)) return
      otpCopy[i] = value
      if (i < 5) inputRefs.current[i + 1]?.focus()
    })
    setOtp(otpCopy)
    e.preventDefault()
  }

  return (
    <div
      onPaste={handlePaste}
      style={{ display: 'flex', gap: '5px', justifyContent: 'center' }}>
      {otp.map((value, index) => (
        <input
          key={index}
          ref={(el) => (inputRefs.current[index] = el)}
          type="text"
          value={value}
          onChange={(e) => handleChange(e.target, index)}
          onKeyDown={(e) => handleBackspace(e, index)}
          maxLength={1}
          style={{
            width: '34px',
            height: '34px',
            textAlign: 'center',
            fontSize: '0.875rem'
          }}
        />
      ))}
    </div>
  )
}

export default OTPInputEmail
