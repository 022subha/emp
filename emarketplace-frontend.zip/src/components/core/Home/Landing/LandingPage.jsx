import WhyMj from './WhyMj'
import HeroText from './HeroText'
import BannerLogo from './BannerLogo'
import LandingKpi from './LandingKpi'
import './LandingComponentStyles.scss'
import { Row, Col, Container } from 'reactstrap'

export default function LandingPage({ showPlanSelectionPage }) {
  return (
    <Container
      fluid
      className="h-100">
      <Row>
        <Col
          xs={12}
          className="mb-2">
          <HeroText />
        </Col>
        <Col
          xs={12}
          className="mb-2 p-2 pt-0 pb-0">
          <BannerLogo />
        </Col>
      </Row>
      <Row>
        <Col
          xs={12}
          lg={3}
          xl={4}
          className="p-0">
          <LandingKpi />
        </Col>
        <Col
          xs={12}
          lg={9}
          xl={8}
          className="p-0">
          <WhyMj showPlanSelectionPage={showPlanSelectionPage} />
        </Col>
      </Row>
    </Container>
  )
}
