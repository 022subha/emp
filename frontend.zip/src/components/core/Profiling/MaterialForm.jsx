import { useDispatch, useSelector } from 'react-redux'
import { Controller, useFieldArray } from 'react-hook-form'
import AwardUploadSection from './AwardsUpload'
import React, { useEffect, useState } from 'react'
import { IoIosAdd, IoMdClose } from 'react-icons/io'
import { Container, Row, Col, Form, FormGroup, Label, Input, Button } from 'reactstrap'
import { MdDelete } from 'react-icons/md'

const MaterialForm = ({ control, watch, register, errors, itemCertifications, setItemCertifications }) => {
  const uomList = useSelector((state) => state.master.uomList)
  const hsnCategories = useSelector((state) => state.master.hsnCategories)

  const { fields, append, remove } = useFieldArray({
    control,
    name: 'materials'
  })

  return (
    <div className="material-form__container">
      <Container
        fluid
        className="bg-transparent">
        <Form>
          {/* <h2 className="dataForm_header">Material/Service Data</h2> */}
          <h2 className="dataForm_header">
            Material/Service Information
            {/* <Col> */}
            <Button
              type="button"
              className="addMore_Data"
              onClick={() =>
                append({
                  materialName: '',
                  hsnCategoryId: '',
                  orderQuantity: '',
                  uom: '',
                  materialDescription: ''
                })
              }>
              <IoIosAdd style={{ color: 'white', fontSize: '1.5rem' }} />
            </Button>
            {/* </Col> */}
          </h2>
          <Row className="mb-2">
            <Col xs={12}>
              <Row>
                {/* <Col>
                  <h4 className="dataForm_subHeader">Material Information</h4>
                </Col> */}
              </Row>
            </Col>
            {fields.map((field, index) => (
              <Col
                xs={12}
                key={field.id}>
                <Row className="operational-form__location-container">
                  <Col xs={12}>
                    <Row>
                      <Col>
                        {fields.length > 1 && (
                          <h4
                            style={{
                              color: '#000',
                              fontWeight: '500',
                              fontSize: '16px'
                            }}>
                            Material #{index + 1}
                          </h4>
                        )}
                      </Col>

                      {index !== 0 && (
                        <Col className="d-flex justify-content-end">
                          <MdDelete
                            style={{ color: 'rgba(255 72 72)', fontSize: '1.2rem' }}
                            onClick={() => remove(index)}
                          />
                        </Col>
                      )}

                      {/* {index !== 0 && (
                        <Col>
                          <Button
                            type="button"
                            className="addMore_Data"
                            style={{ backgroundColor: 'red', border: 'none' }}>
                            <MdDelete
                              style={{ color: 'white', fontSize: '1.2rem' }}
                              onClick={() => remove(index)}
                            />
                          </Button>
                        </Col>
                      )} */}
                    </Row>
                  </Col>
                  <Col
                    md={4}
                    xs={12}>
                    <FormGroup className="material-form__input-container">
                      {/* <Label
                        for={`materials[${index}].materialName`}
                        className="mandatory-label">
                        Material Name
                      </Label> */}
                      <Label
                        for={`materials[${index}].materialName`}
                        className="mandatory-label">
                        Short Description
                      </Label>
                      <Controller
                        name={`materials[${index}].materialName`}
                        control={control}
                        defaultValue=""
                        rules={{
                          required: 'Material Name is required',
                          maxLength: { value: 100, message: 'Material Name cannot exceed 100 character' }
                        }}
                        render={({ field, fieldState: { error } }) => (
                          <>
                            <Input
                              {...field}
                              type="text"
                              invalid={error ? true : false}
                              placeholder="Enter Material Name"
                              className={error ? 'error-input' : ''}
                              id={`materials[${index}].materialName`}
                            />
                            {error && <span className="text-danger error-message">{error.message}</span>}
                          </>
                        )}
                      />
                    </FormGroup>
                  </Col>

                  <Col
                    md={4}
                    xs={12}>
                    <FormGroup className="material-form__input-container">
                      <Label
                        for={`materials[${index}].hsnCategoryId`}
                        className="mandatory-label">
                        HSN Code
                      </Label>
                      <Controller
                        name={`materials[${index}].hsnCategoryId`}
                        control={control}
                        defaultValue=""
                        rules={{
                          required: 'HSN Code is required'
                        }}
                        render={({ field, fieldState: { error } }) => (
                          <>
                            <Input
                              {...field}
                              type="select"
                              className={error ? 'error-input' : ''}
                              invalid={error ? true : false}
                              id={`materials[${index}].hsnCategoryId`}>
                              <option value="">Select HSN Code</option>
                              {(hsnCategories || []).map((item) => (
                                <option
                                  key={item.id}
                                  value={item.id}>
                                  {/* {item.hsnDescription} ({item.hsnCode.toString().padStart(4, '0')}) */}
                                  {item.hsnCode.toString().padStart(4, '0')} - {item.hsnDescription}
                                </option>
                              ))}
                            </Input>
                            {error && <span className="text-danger error-message">{error.message}</span>}
                          </>
                        )}
                      />
                    </FormGroup>
                  </Col>

                  <Col
                    md={4}
                    xs={12}>
                    <FormGroup className="material-form__input-container">
                      <Label for="OrderQuantity">Minimum Order Quantity</Label>
                      <input
                        type="number"
                        className="form-control"
                        id={`materials[${index}].orderQuantity`}
                        {...register(`materials[${index}].orderQuantity`)}
                        placeholder="Minimum Order Quantity"
                      />
                    </FormGroup>
                  </Col>

                  <Col
                    md={4}
                    xs={12}>
                    <FormGroup className="material-form__input-container">
                      <Label
                        for={`materials[${index}].uom`}
                        className={watch(`materials[${index}].orderQuantity`) === '' ? '' : 'mandatory-label'}>
                        UOM
                      </Label>
                      <Controller
                        name={`materials[${index}].uom`}
                        control={control}
                        defaultValue=""
                        rules={{
                          validate: (value) => {
                            const categoryValue = watch(`materials[${index}].orderQuantity`)
                            if (categoryValue !== '') {
                              return value !== '' || 'UOM is required'
                            }
                            return true
                          }
                        }}
                        render={({ field, fieldState: { error } }) => (
                          <>
                            <Input
                              {...field}
                              type="select"
                              id={`materials[${index}].uom`}
                              className={error ? 'error-input' : ''}
                              invalid={watch(`materials[${index}].orderQuantity`) !== '' && error ? true : false}
                              disabled={watch(`materials[${index}].orderQuantity`) === ''}>
                              <option value={-1}>Select UOM</option>
                              {(uomList || []).map((item) => (
                                <option
                                  key={item.id}
                                  value={item.id}>
                                  {item.name} ({item.shortName})
                                </option>
                              ))}
                            </Input>
                            {error && <span className="text-danger error-message">{error.message}</span>}
                          </>
                        )}
                      />
                    </FormGroup>
                  </Col>

                  <Col
                    md={8}
                    xs={12}>
                    <FormGroup className="material-form__input-container">
                      <Label for="materialDsc">Long Desription</Label>
                      <Controller
                        name={`materials[${index}].materialDescription`}
                        control={control}
                        defaultValue=""
                        rules={{
                          maxLength: { value: 500, message: 'Material Description cannot exceed 500 character' }
                        }}
                        render={({ field, fieldState: { error } }) => (
                          <>
                            <Input
                              {...field}
                              type="text"
                              invalid={error ? true : false}
                              placeholder="Enter Material Description"
                              className={error ? 'error-input' : ''}
                              id={`materials[${index}].materialDescription`}
                            />
                            {error && <span className="text-danger error-message">{error.message}</span>}
                          </>
                        )}
                      />
                    </FormGroup>
                  </Col>
                </Row>
              </Col>
            ))}
          </Row>

          {/* File Uploads */}
          <Row>
            <Col xs={12}>
              <FormGroup>
                <h4 className="dataForm_subHeader">Compliance Standard and Certification</h4>
                <AwardUploadSection
                  files={itemCertifications}
                  setFiles={setItemCertifications}
                />
              </FormGroup>
            </Col>
          </Row>
        </Form>
      </Container>
    </div>
  )
}

export default MaterialForm
