import { toast } from 'react-toastify'
import { ssoEndPoints } from '../api'
import { apiConnector } from '../apiConnector'
import { hideLoading, showLoading } from '../../store/slices/uiSlice'

const { getSSOData } = ssoEndPoints

export const fetchSSOData = (appCode) => {
  return async (dispatch) => {
    let result = null
    try {
      dispatch(showLoading())
      const response = await apiConnector('POST', getSSOData, { appCode })
      result = response.data.data
      dispatch(hideLoading())
    } catch (error) {
      dispatch(hideLoading())
      if (error.response) {
        toast.error(error?.response?.data?.message || 'Something Went Wrong')
      } else {
        console.log(error)
      }
    }

    return result
  }
}
