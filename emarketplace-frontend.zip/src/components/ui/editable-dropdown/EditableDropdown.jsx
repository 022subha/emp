import React, { useState } from 'react'
import { FaTrash, FaCheckCircle, FaExclamationCircle } from 'react-icons/fa'
import { Dropdown, DropdownToggle, DropdownMenu, DropdownItem, Input, Button, Row, Col } from 'reactstrap'
import { toast } from 'react-toastify'

const EditableDropdown = ({ className, placeHolder, regex, value, onChange, error, verification = true, disabled = false }) => {
  const addedCount = value.length
  const [newOption, setNewOption] = useState('')
  const [dropdownOpen, setDropdownOpen] = useState(false)

  const displayPlaceholder = addedCount === 0 ? `Enter ${placeHolder}` : `${value.length} ${placeHolder} Added`

  const toggleDropdown = () => setDropdownOpen(!dropdownOpen)

  const addOption = () => {
    const result = regex.test(newOption.trim())
    if (!result) {
      toast.error(`Invalid ${placeHolder}`)
    } else {
      if (newOption.trim() && !value.some((opt) => opt.label === newOption.trim())) {
        if (verification) {
          onChange([...value, { label: newOption.trim(), isVerified: false }])
        } else {
          onChange([...value, { label: newOption.trim() }])
        }
        setNewOption('')
      } else {
        toast.error('Already Added')
        setNewOption('')
      }
    }
  }

  const deleteOption = (index) => {
    onChange(value.filter((_, i) => i !== index))
  }

  return (
    <Dropdown
      className={className}
      isOpen={dropdownOpen}
      toggle={toggleDropdown}>
      <DropdownToggle
        caret
        id="editableDropdown"
        className={error ? 'error-input' : ''}>
        {displayPlaceholder}
      </DropdownToggle>
      <DropdownMenu>
        <Row className="p-2 mx-auto w-100">
          <Col xs={8}>
            <Input
              type="text"
              value={newOption}
              disabled={disabled}
              placeholder={`Enter a ${placeHolder}`}
              onChange={(e) => setNewOption(e.target.value)}
            />
          </Col>
          <Col xs={4}>
            <Button
              color="primary"
              className="w-100"
              disabled={disabled}
              onClick={addOption}>
              Add
            </Button>
          </Col>
        </Row>
        {value.length > 0 && <DropdownItem divider />}
        {value.length > 0 && (
          <div className="p-2">
            {value.map((option, index) => (
              <Row
                key={index}
                className="align-items-center my-1 w-100 mx-auto">
                <Col
                  xs={10}
                  className="d-flex align-items-center text-black"
                  style={{ fontSize: '18px', wordBreak: 'break-all' }}>
                  {verification && (
                    <span style={{ marginRight: '10px', color: option.isVerified ? 'green' : 'orange' }}>
                      {option.isVerified ? <FaCheckCircle title="Verified" /> : <FaExclamationCircle title="UnVerified" />}
                    </span>
                  )}
                  {option.label}
                </Col>
                <Col xs={2}>
                  <Button
                    size="sm"
                    color="danger"
                    disabled={disabled}
                    onClick={() => deleteOption(index)}>
                    <FaTrash />
                  </Button>
                </Col>
              </Row>
            ))}
          </div>
        )}
      </DropdownMenu>
    </Dropdown>
  )
}

export default EditableDropdown
