import { createSlice } from '@reduxjs/toolkit'
const initialState = {
  supplierProfile: {},
  adSlotsRemaining: 0
}

export const supplierSlice = createSlice({
  name: 'supplier',
  initialState,
  reducers: {
    setsupplierProfile: (state, action) => {
      state.supplierProfile = action.payload
    },

    setAdSlotsRemaining(state, action) {
      state.adSlotsRemaining = action.payload
    }
  }
})

export const { setsupplierProfile, setAdSlotsRemaining } = supplierSlice.actions
export default supplierSlice.reducer
