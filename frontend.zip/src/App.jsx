import { lazy } from 'react'
import React, { Suspense, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import Loader from './components/common/loader/Loader'
import Spinner from './components/common/spinner/Spinner'
import Loadable from './components/common/loader/Loadable'
import { getUserInfo } from './services/controller/authAPI'
import ThemeSelector from './components/theme/ThemeSelector'
import { fetchAllMasterLists } from './services/controller/masterAPI'
import { Routes, Route, useLocation, useNavigate } from 'react-router-dom'

const CreateAD = Loadable(lazy(() => import('./pages/AdManagement/CreateAd')))
const Profile = Loadable(lazy(() => import('./pages/Dashboard/Profile/Profile')))
const Home = Loadable(lazy(() => import('./pages/Home/Home')))
const Profiling = Loadable(lazy(() => import('./pages/Profiling/Profiling')))
const MainLayout = Loadable(lazy(() => import('./components/layouts/MainLayout/MainLayout')))
const BuyPlan = Loadable(lazy(() => import('./pages/BuyPlan/BuyPlan')))
const AdContainer = Loadable(lazy(() => import('./pages/Buyer/Ad/AdContainer')))
const DashboardLayout = Loadable(lazy(() => import('./components/layouts/Dashboard/DashboardLayout')))
const AdList = Loadable(lazy(() => import('./pages/Buyer/Ad/AdList')))
const LoginHandler = Loadable(lazy(() => import('./pages/AppCodeHandler')))
const AppCodeHandler = Loadable(lazy(() => import('./pages/LoginHandler')))

function App() {
  useScrollReset()
  const dispatch = useDispatch()
  const location = useLocation()
  const navigate = useNavigate()

  const isLoading = useSelector((state) => state.ui.isLoading)

  useEffect(() => {
    dispatch(fetchAllMasterLists())

    if (!location.pathname.startsWith('/sso?appcode=') && location.pathname !== '/sso/login') {
      dispatch(getUserInfo()).then((success) => {
        // if (!success) navigate("/");
      })
    }
  }, [])

  return (
    <>
      {isLoading && <Spinner />}
      <Suspense fallback={<Loader />}>
        <ThemeSelector />
        <Routes>
          <Route
            path="/sso"
            element={<AppCodeHandler />}
          />
          <Route
            path="/sso/login"
            element={<LoginHandler />}
          />
          <Route
            path="/"
            element={<MainLayout />}>
            <Route
              index
              element={<Home />}
            />
            <Route
              path="buy-plan"
              element={<BuyPlan />}
            />
          </Route>

          <Route
            path="/profiling"
            element={<Profiling />}
          />
          <Route
            path="dashboard"
            element={<DashboardLayout />}>
            <Route
              path="ad"
              element={<CreateAD />}
            />
            <Route
              path="profile"
              element={<Profile />}
            />
          </Route>
          <Route
            path="buyer"
            element={<DashboardLayout />}>
            <Route
              path=""
              element={<AdContainer />}>
              <Route
                path="ads"
                element={<AdList />}
              />
            </Route>
          </Route>
        </Routes>
      </Suspense>
    </>
  )
}

export default App

