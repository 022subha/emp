import React from 'react'
import ShippingImage from '../../../../assets/images/background/shipping-img.png'
import { Row, Col, Card, CardText, CardBody, Container, Button } from 'reactstrap'

export default function WhyMj({ showPlanSelectionPage }) {
  return (
    <div className="h-100">
      <Container
        fluid
        className="h-100 p-2">
        <Card className="bg-transparent h-100">
          <CardBody className="whymj__container GlossBg h-100">
            <Row className="h-100">
              <Col
                xl="6"
                className="d-sm-block">
                <img
                  src={ShippingImage}
                  alt="Shipping"
                  width="100%"
                />
              </Col>
              <Col xl="6">
                <CardText>
                  <h3 className="display-6 mb-0 text-light">Why</h3>
                  <h1 className="display-4 fw-bold text-light">mjPROConnect?</h1>
                </CardText>
                <CardText className="text-light fs-3">
                  Discover a platform designed to bring businesses together. Whether you are looking to source products from reliable suppliers or
                  expand your market reach as a seller, mjPROConnect simplifies the entire process. With our comprehensive supplier listings and
                  easy-to-use advertisement tools, you can find the right partners, compare offers, and build strong business relationships—all in one
                  place.
                </CardText>
                <Button
                  className="regBtn"
                  onClick={showPlanSelectionPage}>
                  Register
                </Button>
              </Col>
            </Row>
          </CardBody>
        </Card>
      </Container>
    </div>
  )
}
