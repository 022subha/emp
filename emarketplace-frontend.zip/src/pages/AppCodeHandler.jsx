import React, { useEffect } from "react";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { fetchSSOData } from "../services/controller/ssoAPI";

const AppCodeHandler = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const params = new URLSearchParams(window.location.search);
  const appcode = params.get("appcode");

  const decryptAppCode = async () => {
    dispatch(fetchSSOData(appcode)).then((res) => {
      navigate("/sso/login", { state: { data: res } });
    });
  };

  useEffect(() => {
    if (appcode) {
      decryptAppCode();
    }
  }, [appcode]);

  return <div></div>;
};

export default React.memo(AppCodeHandler);
