import React from 'react'
import { Link } from 'react-router-dom'
import MjLogo from '../../../../assets/images/logos/mjPro_Logo.png'

const Logo = () => {
  return (
    <Link
      to="/"
      className="d-flex align-items-center gap-2 ms-2">
      <img
        src={MjLogo}
        className="SupplierHeaderLogo"
      />
    </Link>
  )
}

export default Logo
