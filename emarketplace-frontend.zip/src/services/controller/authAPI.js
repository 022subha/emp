import { toast } from 'react-toastify'
import { authEndPoints } from '../api'
import { apiConnector } from '../apiConnector'
import { clearUser, setUser } from '../../store/slices/userSlice'
import { hideLoading, showLoading } from '../../store/slices/uiSlice'
import { setAdSlotsRemaining } from '../../store/slices/supplierSlice'
const {
  login: loginAPI,
  sendOtp: sendOtpAPI,
  verifyOtp: verifyOtpAPI,
  me,
  adSlotsRemaining,
  changeLoginCode: changeLoginCodeAPI,
  logout: logoutAPI
} = authEndPoints

export const sendOtp = (data) => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('POST', sendOtpAPI, data)
      dispatch(hideLoading())
      toast.success(response.data.message)
      return true
    } catch (error) {
      dispatch(hideLoading())
      if (error.response) {
        toast.error(error?.response?.data?.message || 'Something Went Wrong')
      } else {
        console.log(error)
        toast.error('Something Went Wrong')
      }
    }

    return false
  }
}

export const verifyOtp = (data) => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('POST', verifyOtpAPI, data)
      dispatch(hideLoading())
      toast.success(response.data.message)
      return response.data.data.otpVerificationToken
    } catch (error) {
      dispatch(hideLoading())
      if (error.response) {
        toast.error(error?.response?.data?.message || 'Something Went Wrong')
      } else {
        console.log(error)
        toast.error('Something Went Wrong')
      }
    }

    return null
  }
}

export const login = (mjPROToken) => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('POST', loginAPI, { mjPROToken })
      dispatch(setUser(response.data.data))
      dispatch(hideLoading())
      return response.data.data
    } catch (error) {
      dispatch(hideLoading())
      if (error.response) {
        toast.error(error?.response?.data?.message || 'Something Went Wrong')
      } else {
        console.log(error)
      }
    }
    return null
  }
}

export const getUserInfo = () => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('GET', me)
      dispatch(setUser(response.data.data))
      dispatch(hideLoading())

      return true
    } catch (error) {
      dispatch(hideLoading())
      console.log(error)
    }

    return false
  }
}

export const getAdSlotsRemaining = () => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('GET', adSlotsRemaining)
      dispatch(setAdSlotsRemaining(response.data.data))
      dispatch(hideLoading())

      return true
    } catch (error) {
      dispatch(hideLoading())
      console.log(error)
    }

    return false
  }
}

export const changeLoginCode = (id, loginCodeChangeToken) => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('POST', changeLoginCodeAPI, { id, loginCodeChangeToken })
      dispatch(hideLoading())
      toast.success(response.data.message)

      return true
    } catch (error) {
      dispatch(hideLoading())
      console.log(error)
    }

    return false
  }
}

export const logout = () => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('DELETE', logoutAPI)
      dispatch(clearUser())
      dispatch(hideLoading())
      toast.success(response.data.message)
      return true
    } catch (error) {
      dispatch(hideLoading())
      if (error.response) {
        toast.error(error?.response?.data?.message || 'Something Went Wrong')
      } else {
        console.log(error)
      }
    }
    return false
  }
}
