import React, { useState } from "react";
import DatePicker from "react-datepicker";
import { MdSearch } from "react-icons/md";
import { Col, Input, Row } from "reactstrap";
import "react-datepicker/dist/react-datepicker.css";
import { useDispatch, useSelector } from "react-redux";
import Select from "react-select";
import {
  fetchCityList,
  fetchStateList,
} from "../../../services/controller/masterAPI";

const AdFilterBar = () => {
  const dispatch = useDispatch();

  const hsnCategories = useSelector((state) => state.master.hsnCategories);
  const countries = useSelector((state) => state.master.countryList);
  const states = useSelector((state) => state.master.stateList);
  const cities = useSelector((state) => state.master.cityList);

  const [dateRange, setDateRange] = useState([null, null]);
  const [startDate, endDate] = dateRange;
  const [countryId, setCountryId] = useState("");
  const [stateId, setStateId] = useState("");
  const [cityId, setCityId] = useState("");

  const handleCountryChange = (countryId) => {
    setCountryId(countryId);
    setStateId("");
    setCityId("");
    if (countryId !== "" && !states[countryId]) {
      dispatch(fetchStateList(countryId));
    }
  };

  const handleStateChange = (stateId) => {
    setStateId(stateId);
    setCityId("");
    if (
      countryId !== "" &&
      stateId !== "" &&
      !cities[`${countryId}-${stateId}`]
    ) {
      dispatch(fetchCityList(countryId, stateId));
    }
  };

  const handleCityChange = (cityId) => {
    setCityId(cityId);
  };

  return (
    <div className="buyer-filter">
      <div className="filter-content">
        <h5 className="filter-title">Apply Filters</h5>
        <Select
          className=""
          classNamePrefix="select"
          placeholder="Select Category"
          defaultValue=""
          isClearable={true}
          isSearchable={true}
          name="color"
          options={(hsnCategories || []).map((item) => ({
            value: item.id,
            label: `${item.hsnCode.toString().padStart(4, "0")}-${item.hsnDescription}`,
          }))}
        />

        <DatePicker
          selectsRange={true}
          startDate={startDate}
          endDate={endDate}
          minDate={new Date()}
          onChange={(update) => setDateRange(update)}
          withPortal={true}
          isClearable={true}
          dateFormat="dd/MM/YYYY"
          className="form-control filter-input-datepicker"
          placeholderText="Select Offer Date Range"
        />

        <h5 className="filter-subtitle">Location</h5>
        <Input
          type="select"
          id="countryId"
          className="filter-input"
          onChange={(e) => {
            handleCountryChange(e.target.value);
          }}
        >
          <option value="">Select Country</option>
          {(countries || []).map((item) => (
            <option key={item.id} value={item.id}>
              {item.countryName}
            </option>
          ))}
        </Input>

        <Input
          type="select"
          id="stateId"
          className="filter-input"
          onChange={(e) => {
            handleStateChange(e.target.value);
          }}
        >
          <option value="">Select State</option>
          {(states[countryId] || []).map((item) => (
            <option key={item.id} value={item.id}>
              {item.stateName}
            </option>
          ))}
        </Input>

        <Input
          type="select"
          id="cityId"
          className="filter-input"
          onChange={(e) => {
            handleCityChange(e.target.value);
          }}
        >
          <option value="">Select City</option>
          {(cities[`${countryId}-${stateId}`] || []).map((item) => (
            <option key={item.id} value={item.id}>
              {item.cityName}
            </option>
          ))}
        </Input>
        <Row>
          <Col sm={9} className="pe-0">
            <Input
              type="text"
              className="filter-input"
              placeholder="Supplier Name"
            />
          </Col>
          <Col sm={3}>
            <div
              className="p-2 w-100 d-flex justify-content-center align-items-center"
              style={{
                backgroundColor: "#00b1f1",
                color: "#fff",
                fontSize: "20px",
                borderRadius: "5px",
                aspectRatio: 1,
                cursor: "pointer",
              }}
            >
              <MdSearch />
            </div>
          </Col>
        </Row>
      </div>
    </div>
  );
};

export default AdFilterBar;
