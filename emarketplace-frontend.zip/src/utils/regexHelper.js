export const EMAIL_REGEX = /^[a-zA-Z0-9.]+@[a-zA-Z0-9]+\.[a-zA-Z]{2,}$/
export const WHATSAPP_NUMBER_REGEX = /^\+?[1-9]\d{1,14}$/
export const PAN_REGEX = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/
export const PAN_HOLDER_DOB_REGEX = /^\d{4}-\d{2}-\d{2}$/
export const MSME_NUMBER_REGEX = /^UDYAM-[A-Z]{2}-\d{2}-\d{7}$/
export const GSTIN_NUMBER_REGEX = /^([0-2][0-9]|3[0-7])[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/
