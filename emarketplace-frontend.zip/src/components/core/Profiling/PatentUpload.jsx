import React, { useState } from 'react'
import { ImAttachment } from 'react-icons/im'
import { FaTimes, FaRedo, FaCheck, FaUpload } from 'react-icons/fa'
import { Button, Progress, ListGroup, ListGroupItem, Row, Col, Card } from 'reactstrap'

const PatentUpload = ({ files, setFiles }) => {
  // Handle file selection
  const handleFileSelect = (event) => {
    const selectedFiles = Array.from(event.target.files).map((file) => ({
      file,
      name: file.name,
      size: file.size,
      status: 'uploading', // 'uploading', 'success', or 'failed'
      progress: 0
    }))
    setFiles((prevFiles) => [...prevFiles, ...selectedFiles])
    uploadFiles(selectedFiles)
  }

  // Simulate file upload process
  const uploadFiles = (fileList) => {
    fileList.forEach((fileObj) => {
      const interval = setInterval(() => {
        setFiles((prevFiles) =>
          prevFiles.map((f) => {
            if (f.name === fileObj.name) {
              const newProgress = f.progress + 10
              return {
                ...f,
                progress: newProgress,
                status: newProgress >= 100 ? 'success' : 'uploading'
              }
            }
            return f
          })
        )
        if (fileObj.progress >= 100) clearInterval(interval)
      }, 500)
    })
  }

  // Remove a single file
  const handleRemoveFile = (fileName) => {
    setFiles((prevFiles) => prevFiles.filter((file) => file.name !== fileName))
  }

  // Remove all files
  const handleRemoveAll = () => {
    setFiles([])
  }

  // Retry file upload
  const handleRetry = (fileName) => {
    setFiles((prevFiles) => prevFiles.map((file) => (file.name === fileName ? { ...file, progress: 0, status: 'uploading' } : file)))
    const fileToRetry = files.find((file) => file.name === fileName)
    uploadFiles([fileToRetry])
  }

  return (
    <div>
      <Card
        header
        className="awardCard_header">
        <Row className="">
          <Col>
            <Button
              color="brand-color"
              tag="label">
              <ImAttachment /> Patent
              <input
                type="file"
                multiple
                hidden
                accept="application/pdf, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                onChange={handleFileSelect}
              />
            </Button>
          </Col>
          <Col className="text-end">
            <Button
              color="danger"
              onClick={handleRemoveAll}>
              Remove All
            </Button>
          </Col>
        </Row>
      </Card>
      <Card
        body
        className="awardCard_body">
        <ListGroup>
          {files.map((file) => (
            <ListGroupItem
              key={file.name}
              className="d-flex align-items-center awardFile_list">
              <div className="me-auto">
                <FaUpload className="me-2" />
                {file.name}
                <div>
                  {file.status === 'success' && <small className="text-success">File(s) successfully uploaded</small>}
                  {file.status === 'failed' && <small className="text-danger">File(s) failed to upload</small>}
                  {file.status === 'uploading' && <small>{(file.size / 1024).toFixed(2)} KB</small>}
                </div>
              </div>
              {file.status === 'uploading' && (
                <>
                  <Progress
                    value={file.progress}
                    className="me-2"
                    style={{ width: '150px' }}
                  />
                  <Button
                    size="sm"
                    color="danger"
                    onClick={() => handleRemoveFile(file.name)}>
                    <FaTimes />
                  </Button>
                </>
              )}
              {file.status === 'failed' && (
                <Button
                  size="sm"
                  color="warning"
                  onClick={() => handleRetry(file.name)}>
                  <FaRedo />
                </Button>
              )}
              {file.status === 'success' && <FaCheck className="text-success" />}
            </ListGroupItem>
          ))}
        </ListGroup>
      </Card>
    </div>
  )
}

export default PatentUpload
