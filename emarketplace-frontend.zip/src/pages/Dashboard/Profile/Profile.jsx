import './Profile.scss'
import ItemTable from './ItemTable'
import { MdRemoveRedEye } from 'react-icons/md'
import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { formatIndianCurrency } from '../../../utils/currencyHelper'
import { supplierProfileInfo } from '../../../services/controller/supplierAPI'
import {
  Container,
  Card,
  Row,
  Col,
  Label,
  CardText,
  CardBody,
  ListGroup,
  ListGroupItem,
  FormGroup,
  Button,
  Modal,
  ModalHeader,
  ModalBody
} from 'reactstrap'
import { IoMdClose } from 'react-icons/io'
import { formatDistanceToNow } from 'date-fns'
import Spinner from '../../../components/common/spinner/Spinner'
import ManufacturingLocationTable from './ManufacturingLocationTable'
import ProductionCapacityTable from './ProductionCapacityTable'
import ItemCategoryTable from './ItemCategoryTable'

export default function Profile() {
  const dispatch = useDispatch()
  const isLoading = useSelector((state) => state.ui.isLoading)
  const supplier = useSelector((state) => state.supplier.supplierProfile)

  const [logoModal, setLogoModal] = useState(false)
  const [keyPartnershipModal, setKeyPartnershipModal] = useState(false)
  const [gstinModal, setGstinModal] = useState(false)
  const [contactDetailsModal, setContactDetailsModal] = useState(false)
  const [countriesDoingBussinessInModal, setcountriesDoingBussinessInModal] = useState(false)
  const [top10BuyersModal, setTop10BuyersModal] = useState(false)
  const [subsidiariesModal, setSubsidiariesModal] = useState(false)

  const toggleLogoModal = () => {
    setLogoModal((prev) => !prev)
  }

  const toggleKeyPartnershipModal = () => {
    setKeyPartnershipModal((prev) => !prev)
  }

  const toggleGstinModal = () => {
    setGstinModal((prev) => !prev)
  }

  const toggleContactDetailsModal = () => {
    setContactDetailsModal((prev) => !prev)
  }

  const toggleCountriesDoingBussinessInModal = () => {
    setcountriesDoingBussinessInModal((prev) => !prev)
  }

  const toggleTop10BuyersModal = () => {
    setTop10BuyersModal((prev) => !prev)
  }

  const toggleSubsidiariesModal = () => {
    setSubsidiariesModal((prev) => !prev)
  }

  const logoModalCloseButton = (
    <button
      className="profile__logo-modal-close-btn"
      onClick={toggleLogoModal}
      type="button">
      <IoMdClose />
    </button>
  )

  const keyPartnershipModalCloseButton = (
    <button
      className="profile__logo-modal-close-btn"
      onClick={toggleKeyPartnershipModal}
      type="button">
      <IoMdClose />
    </button>
  )

  const gstinModalCloseButton = (
    <button
      className="profile__logo-modal-close-btn"
      onClick={toggleGstinModal}
      type="button">
      <IoMdClose />
    </button>
  )

  const contactDetailsModalCloseButton = (
    <button
      className="profile__logo-modal-close-btn"
      onClick={toggleContactDetailsModal}
      type="button">
      <IoMdClose />
    </button>
  )

  const countriesDoingBussinessInModalCloseButton = (
    <button
      className="profile__logo-modal-close-btn"
      onClick={toggleCountriesDoingBussinessInModal}
      type="button">
      <IoMdClose />
    </button>
  )

  const top10BuyersModalCloseButton = (
    <button
      className="profile__logo-modal-close-btn"
      onClick={toggleTop10BuyersModal}
      type="button">
      <IoMdClose />
    </button>
  )

  const subsidiariesModalCloseButton = (
    <button
      className="profile__logo-modal-close-btn"
      onClick={toggleSubsidiariesModal}
      type="button">
      <IoMdClose />
    </button>
  )

  useEffect(() => {
    dispatch(supplierProfileInfo())
  }, [])

  return (
    <>
      {isLoading && <Spinner />}
      <div className="profile-main-section">
        <Container
          fluid
          className="h-100 p-0">
          <Card className="PageTop_Card_companyInfo mb-2">
            <CardBody>
              <Row>
                <Col
                  xs={6}
                  md={2}
                  className="px-2">
                  <div className="companyInfo">
                    <Label className="mb-0 fw-bold">Company Name</Label>
                    <CardText>{supplier?.organizationInfo?.companyName || 'Not available'}</CardText>
                  </div>
                </Col>
                <Col
                  xs={6}
                  md={1}
                  className="px-2">
                  <div className="companyInfo">
                    <Label className="mb-0 fw-bold">Country</Label>
                    <CardText>{supplier?.organizationInfo?.country?.countryName || 'Not Available'}</CardText>
                  </div>
                </Col>
                <Col
                  xs={6}
                  md={2}
                  className="px-2">
                  <div className="companyInfo">
                    <Label className="mb-0 fw-bold">Establishment Year</Label>
                    <CardText>{supplier?.organizationInfo?.yearOfEstablishment || 'Not Available'}</CardText>
                  </div>
                </Col>
                {supplier?.organizationInfo?.country?.countryName === 'India' ? (
                  <>
                    <Col
                      xs={6}
                      md={1}
                      className="px-2">
                      <div className="companyInfo">
                        <Label className="mb-0 fw-bold">PAN</Label>
                        <CardText>{supplier?.organizationInfo?.panNumber || 'Not Available'}</CardText>
                      </div>
                    </Col>
                    <Col
                      xs={6}
                      md={4}
                      className="px-2">
                      <div className="companyInfo">
                        <Label className="mb-0 fw-bold">Name on PAN</Label>
                        <CardText>{supplier?.organizationInfo?.panHolderName || 'Not Available'}</CardText>
                      </div>
                    </Col>
                    <Col
                      xs={6}
                      md={1}
                      className="px-2">
                      <div className="companyInfo">
                        <Label className="mb-0 fw-bold">DOB/DOI</Label>
                        <CardText>{supplier?.organizationInfo?.panHolderDOB || 'Not Available'}</CardText>
                      </div>
                    </Col>
                  </>
                ) : (
                  <>
                    <Col
                      xs={6}
                      md={2}
                      className="px-2">
                      <div className="companyInfo">
                        <Label className="mb-0 fw-bold">UIN</Label>
                        <CardText>{supplier?.organizationInfo?.uinNumber || 'Not Available'}</CardText>
                      </div>
                    </Col>
                  </>
                )}
              </Row>
            </CardBody>
          </Card>
          <Card className="UserProfile_info">
            <ListGroup>
              <ListGroupItem>
                <Row>
                  <Col xs={12}>
                    <h5 className="ProfileCard_innerHead">Organizational Data</h5>
                  </Col>
                  <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">State</Label>
                      <CardText>{supplier?.organizationInfo?.state?.stateName || 'Not Available'}</CardText>
                    </div>
                  </Col>
                  <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">City</Label>
                      <CardText>{supplier?.organizationInfo?.city?.cityName || 'Not Available'}</CardText>
                    </div>
                  </Col>
                  {supplier?.organizationInfo?.country?.countryName === 'India' ? (
                    <>
                      <Col
                        xs={6}
                        md={4}
                        xxl={2}
                        className="mb-2">
                        <div className="innerCard_info">
                          <Label className="mb-0 fw-bold">MSME Number</Label>
                          <CardText>{supplier?.organizationInfo?.msmeNumber || 'Not Available'}</CardText>
                        </div>
                      </Col>
                      <Col
                        xs={6}
                        md={4}
                        xxl={2}
                        className="mb-2">
                        <div className="innerCard_info">
                          <Label className="mb-0 fw-bold">GSTIN</Label>
                          {supplier?.gstinInformation?.length > 0 ? (
                            <Button
                              color="link"
                              onClick={toggleGstinModal}
                              className="text-decoration-none text-start d-block p-0">
                              <MdRemoveRedEye /> <span>View GSTIN</span>
                            </Button>
                          ) : (
                            <CardText>Not Available</CardText>
                          )}
                        </div>
                      </Col>
                    </>
                  ) : (
                    <></>
                  )}
                  <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">Scale of Business</Label>
                      <CardText>{supplier?.organizationInfo?.businessScale?.name || 'Not Available'}</CardText>
                    </div>
                  </Col>
                  <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">Annual Revenue</Label>
                      <CardText>{formatIndianCurrency(supplier?.organizationInfo?.annualRevenue) || 'Not Available'}</CardText>
                    </div>
                  </Col>
                  {/* <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">Key Partnership</Label>
                      {supplier?.organizationInfo?.keyPartnership?.length > 0 ? (
                        <Button
                          color="link"
                          onClick={toggleKeyPartnershipModal}
                          className="text-decoration-none text-start d-block p-0">
                          <MdRemoveRedEye /> <span>View Partners</span>
                        </Button>
                      ) : (
                        <CardText>Not Available</CardText>
                      )}
                    </div>
                  </Col> */}
                  <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">Contact Information</Label>
                      {supplier?.contactDetails?.length > 0 ? (
                        <Button
                          color="link"
                          onClick={toggleContactDetailsModal}
                          className="text-decoration-none text-start d-block p-0">
                          <MdRemoveRedEye /> <span>View Contacts</span>
                        </Button>
                      ) : (
                        <CardText>Not Available</CardText>
                      )}
                    </div>
                  </Col>
                  <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">Name</Label>
                      <CardText>{supplier?.contactDetails?.find((item) => item.contactType === 'primary')?.contactName || 'Not Available'}</CardText>
                    </div>
                  </Col>
                  <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">Email ID</Label>
                      <CardText>{supplier?.contactDetails?.find((item) => item.contactType === 'primary')?.contactEmail || 'Not Available'}</CardText>
                    </div>
                  </Col>
                  <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">WhatsApp Number</Label>
                      <CardText>
                        {supplier?.contactDetails?.find((item) => item.contactType === 'primary')?.contactWhatsappNumber || 'Not Available'}
                      </CardText>
                    </div>
                  </Col>
                  <Col
                    xs={12}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">Company Overview</Label>
                      <CardText>{formatIndianCurrency(supplier?.organizationInfo?.companyDescription) || 'Not Available'}</CardText>
                    </div>
                  </Col>
                  <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">LinkedIn</Label>
                      <CardText>{formatIndianCurrency(supplier?.organizationInfo?.linkedInId) || 'Not Available'}</CardText>
                    </div>
                  </Col>
                  <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">Twitter</Label>
                      <CardText>{formatIndianCurrency(supplier?.organizationInfo?.twitterId) || 'Not Available'}</CardText>
                    </div>
                  </Col>
                  <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">Facebook</Label>
                      <CardText>{formatIndianCurrency(supplier?.organizationInfo?.facebookId) || 'Not Available'}</CardText>
                    </div>
                  </Col>
                  <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">Awards & Recognitions</Label>
                      {supplier?.awards?.length > 0 ? (
                        <Button
                          color="link"
                          className="text-decoration-none text-start d-block p-0">
                          <MdRemoveRedEye /> <span>View Awards</span>
                        </Button>
                      ) : (
                        <CardText>Not Available</CardText>
                      )}
                    </div>
                  </Col>
                  <Col
                    xs={'auto'}
                    className="mb-2 flex-grow-1">
                    <div className="innerCard_info">
                      <FormGroup>
                        <Label className="mb-0 fw-bold">Logo</Label>
                        {supplier?.organizationInfo?.logoUrl ? (
                          <Button
                            color="link"
                            onClick={toggleLogoModal}
                            className="text-decoration-none text-start d-block p-0">
                            <MdRemoveRedEye /> <span>View Logo</span>
                          </Button>
                        ) : (
                          <CardText>Not Available</CardText>
                        )}
                      </FormGroup>
                    </div>
                  </Col>
                </Row>
              </ListGroupItem>
              <ListGroupItem>
                <Row>
                  <Col xs={12}>
                    <h5 className="ProfileCard_innerHead">Operational Data</h5>
                  </Col>
                  {/* <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">Annual Revenue</Label>
                      <CardText>{formatIndianCurrency(supplier?.organizationInfo?.annualRevenue) || 'Not Available'}</CardText>
                    </div>
                  </Col> */}
                  <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">Nature of Business</Label>
                      <CardText>{supplier?.operationalInfo?.opNatureOfBussiness?.name || 'Not Available'}</CardText>
                    </div>
                  </Col>
                  <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">Countries Doing Business in </Label>
                      <Button
                        color="link"
                        onClick={toggleCountriesDoingBussinessInModal}
                        className="text-decoration-none text-start d-block p-0">
                        <MdRemoveRedEye /> <span>View Details</span>
                      </Button>
                    </div>
                  </Col>
                  <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">Top 10 Buyers</Label>
                      <Button
                        color="link"
                        onClick={toggleTop10BuyersModal}
                        className="text-decoration-none text-start d-block p-0">
                        <MdRemoveRedEye /> <span>View Details</span>
                      </Button>
                    </div>
                  </Col>
                  <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">Total Number of Employess</Label>
                      <CardText>{supplier?.operationalInfo?.totalNumberOfEmployees || 'Not Available'}</CardText>
                    </div>
                  </Col>
                  <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">Credit Rating</Label>
                      <CardText>{supplier?.operationalInfo?.creditRating || 'Not Available'}</CardText>
                    </div>
                  </Col>
                  <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">Turnover of {supplier?.operationalInfo?.year1}</Label>
                      <CardText>{formatIndianCurrency(supplier?.operationalInfo?.year1Turnover) || 'Not Available'}</CardText>
                    </div>
                  </Col>
                  <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">Turnover of {supplier?.operationalInfo?.year2}</Label>
                      <CardText>{formatIndianCurrency(supplier?.operationalInfo?.year2Turnover) || 'Not Available'}</CardText>
                    </div>
                  </Col>
                  <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">Turnover of {supplier?.operationalInfo?.year3}</Label>
                      <CardText>{formatIndianCurrency(supplier?.operationalInfo?.year3Turnover) || 'Not Available'}</CardText>
                    </div>
                  </Col>

                  <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">OEM Service</Label>
                      <CardText>{supplier?.operationalInfo?.isOEMService ? 'Yes' : 'No'}</CardText>
                    </div>
                  </Col>
                  <Col
                    xs={6}
                    md={4}
                    xxl={2}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">Subsidiaries</Label>
                      <Button
                        color="link"
                        onClick={toggleSubsidiariesModal}
                        className="text-decoration-none text-start d-block p-0">
                        <MdRemoveRedEye /> <span>View Details</span>
                      </Button>
                    </div>
                  </Col>
                  <Col
                    xs={12}
                    className="mb-2">
                    <div className="innerCard_info">
                      <Label className="mb-0 fw-bold">Why Us?</Label>
                      <CardText>{supplier?.operationalInfo?.whyUs || 'Not Available'}</CardText>
                    </div>
                  </Col>
                  <Col xs={12}>
                    <Label className="mb-2 fw-bold">Manufacturing Location</Label>
                    <ManufacturingLocationTable mfgLocation={supplier?.mfgLocationsInfo} />
                  </Col>
                  <Col xs={12}>
                    <Label className="mb-2 fw-bold">Production Capacity</Label>
                    <ProductionCapacityTable productionCapacity={supplier?.productionCapacity} />
                  </Col>
                  {/* <Col xs={12}>
                    <Label className="mb-2 fw-bold">Bussiness Operation</Label>
                    <BusinessNatureTable
                      natureOfBussiness={supplier?.natureOfBussiness}
                      countriesDoingBussinessIn={supplier?.countriesDoingBussinessIn}
                      top10Buyers={supplier?.top10Buyers}
                      totalNumberOfEmployees={supplier?.operationalInfo?.totalNumberOfEmployees || 'Not Available'}
                      whyUs={supplier?.operationalInfo?.whyUs || 'Not Available'}
                    />
                  </Col> */}
                  <Col xs={12}>
                    <Label className="mb-2 fw-bold">Item Category</Label>
                    <ItemCategoryTable categoryInformation={supplier?.materialCategory} />
                  </Col>
                </Row>
              </ListGroupItem>
              <ListGroupItem>
                <Row>
                  <Col xs={12}>
                    <h5 className="ProfileCard_innerHead">Material Data</h5>
                  </Col>
                  <Col xs={12}>
                    <Label className="mb-2 fw-bold">Material Information</Label>
                    <ItemTable itemInformation={supplier?.materials} />
                  </Col>
                </Row>
              </ListGroupItem>
            </ListGroup>
            {/* <CardBody>
              <Row>
                <Col
                  xs={12}
                  className="text-end">
                  <Button color="primary">Edit</Button>
                  &nbsp;&nbsp;
                  <Button color="success">Save</Button>
                </Col>
              </Row>
            </CardBody> */}
          </Card>
        </Container>

        {/* GSTIN Modal */}
        <Modal
          isOpen={gstinModal}
          toggle={toggleGstinModal}
          size="lg"
          className="profile__gstin-modal">
          <ModalHeader
            className="profile__gstin-modal-header"
            toggle={toggleGstinModal}
            close={gstinModalCloseButton}>
            GSTIN Information
          </ModalHeader>
          <ModalBody className="text-center profile__gstin-modal-body">
            <table className="gstin-table table table-bordered">
              <thead>
                <tr>
                  <th>#</th>
                  <th>GSTIN Number</th>

                  {/* <th>Verification Time</th> */}
                </tr>
              </thead>
              <tbody>
                {(supplier.gstinInformation || []).map((gstin, index) => (
                  <tr key={gstin.id}>
                    <td>{index + 1}</td>
                    <td>{gstin.gstinNumber}</td>
                    {/* <td>
                      {gstin.isGstinVerified ? `${formatDistanceToNow(new Date(gstin.gstinVerificationTime), { addSuffix: true })}` : 'Not Available'}
                    </td> */}
                  </tr>
                ))}
              </tbody>
            </table>
          </ModalBody>
        </Modal>

        {/* Key Partnership Modal */}
        <Modal
          isOpen={keyPartnershipModal}
          toggle={toggleKeyPartnershipModal}
          size="lg"
          className="profile__key-partnership-modal">
          <ModalHeader
            className="profile__key-partnership-modal-header"
            toggle={toggleKeyPartnershipModal}
            close={keyPartnershipModalCloseButton}>
            Key Partnership
          </ModalHeader>
          <ModalBody className="text-center profile__key-partnership-modal-body">
            <table className="table table-bordered">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Key Partner</th>
                </tr>
              </thead>
              <tbody>
                {(supplier?.organizationInfo?.keyPartnership || []).map((partner, index) => (
                  <tr key={index}>
                    <td>{index + 1}</td>
                    <td>{partner}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </ModalBody>
        </Modal>

        {/* GSTIN Modal */}
        <Modal
          isOpen={contactDetailsModal}
          toggle={toggleContactDetailsModal}
          size="lg"
          className="profile__contact-details-modal">
          <ModalHeader
            className="profile__contact-details-modal-header"
            toggle={toggleContactDetailsModal}
            close={contactDetailsModalCloseButton}>
            Contact Details
          </ModalHeader>
          <ModalBody className="text-center profile__contact-details-modal-body">
            <table className="table table-bordered">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Whatsapp Number</th>
                  <th>Designation</th>
                  <th>Type</th>
                </tr>
              </thead>
              <tbody>
                {(supplier?.contactDetails || []).map((contact, index) => (
                  <tr key={index}>
                    <td>{index + 1}</td>
                    <td>{contact.contactName || 'Not Available'}</td>
                    <td>{contact.contactEmail || 'Not Available'}</td>
                    <td>{contact.contactWhatsappNumber || 'Not Available'}</td>
                    <td>{contact.contactPersonDesignation || 'Not Available'}</td>
                    <td>{contact.contactType === 'primary' ? 'Primary' : 'Additional'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </ModalBody>
        </Modal>

        {/* Logo Modal */}
        <Modal
          isOpen={logoModal}
          toggle={toggleLogoModal}
          size="lg"
          className="profile__logo-modal">
          <ModalHeader
            className="profile__logo-modal-header"
            toggle={toggleLogoModal}
            close={logoModalCloseButton}>
            Company Logo
          </ModalHeader>
          <ModalBody className="text-center profile__logo-modal-body">
            <img
              src="https://images.pexels.com/photos/1624496/pexels-photo-1624496.jpeg?auto=compress&cs=tinysrgb&w=600"
              alt="Company Logo"
            />
          </ModalBody>
        </Modal>

        {/* Countries Doing Bussiness In */}
        <Modal
          isOpen={countriesDoingBussinessInModal}
          toggle={toggleCountriesDoingBussinessInModal}
          size="lg"
          className="profile__key-partnership-modal">
          <ModalHeader
            className="profile__key-partnership-modal-header"
            toggle={toggleCountriesDoingBussinessInModal}
            close={countriesDoingBussinessInModalCloseButton}>
            Countries Doing Bussiness In
          </ModalHeader>
          <ModalBody className="text-center profile__key-partnership-modal-body">
            <table className="table table-bordered">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Country Name</th>
                </tr>
              </thead>
              <tbody>
                {(supplier?.operationalInfo?.countriesDoingBussinessIn || []).map((country, index) => (
                  <tr key={index}>
                    <td>{index + 1}</td>
                    <td>{country.countryName}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </ModalBody>
        </Modal>

        {/* Top 10 Buyers Modal */}
        <Modal
          isOpen={top10BuyersModal}
          toggle={toggleTop10BuyersModal}
          size="lg"
          className="profile__key-partnership-modal">
          <ModalHeader
            className="profile__key-partnership-modal-header"
            toggle={toggleTop10BuyersModal}
            close={top10BuyersModalCloseButton}>
            Top 10 Buyers
          </ModalHeader>
          <ModalBody className="text-center profile__key-partnership-modal-body">
            <table className="table table-bordered">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Buyer Name</th>
                </tr>
              </thead>
              <tbody>
                {(supplier?.operationalInfo?.top10Buyer || []).map((buyer, index) => (
                  <tr key={index}>
                    <td>{index + 1}</td>
                    <td>{buyer}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </ModalBody>
        </Modal>

        {/* Subsidiaries Modal */}
        <Modal
          isOpen={subsidiariesModal}
          toggle={toggleSubsidiariesModal}
          size="lg"
          className="profile__key-partnership-modal">
          <ModalHeader
            className="profile__key-partnership-modal-header"
            toggle={toggleSubsidiariesModal}
            close={subsidiariesModalCloseButton}>
            Subsidiaries
          </ModalHeader>
          <ModalBody className="text-center profile__key-partnership-modal-body">
            <table className="table table-bordered">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Subsidiary</th>
                </tr>
              </thead>
              <tbody>
                {(supplier?.subsidiaries || []).map((subsidiary, index) => (
                  <tr key={index}>
                    <td>{index + 1}</td>
                    <td>{subsidiary}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </ModalBody>
        </Modal>
      </div>
    </>
  )
}
