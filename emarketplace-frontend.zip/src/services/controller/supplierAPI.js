import { toast } from 'react-toastify'
import { supplierEndPoints } from '../api'
import { apiConnector } from '../apiConnector'
import { hideLoading, showLoading } from '../../store/slices/uiSlice'
import { setsupplierProfile } from '../../store/slices/supplierSlice'

const {
  publishProfile: publishProfileAPI,
  saveOpInfoAsDraft: saveOpInfoAsDraftAPI,
  saveOrgInfoAsDraft: saveOrgInfoAsDraftAPI,
  supplierProfileInfo: supplierProfileInfoAPI,
  saveItemInfoAsDraft: saveItemInfoAsDraftAPI,
  sendOtpToContactPerson: sendOtpToContactPersonAPI,
  verifyOtpOfContactPerson: verifyOtpOfContactPersonAPI,
  fetchOpInfoBeforePublishing: fetchOpInfoBeforePublishingAPI,
  fetchOrgInfoBeforePublishing: fetchOrgInfoBeforePublishingAPI,
  fetchItemInfoBeforePublishing: fetchItemInfoBeforePublishingAPI
} = supplierEndPoints

export const sendOtpToContactPerson = (data) => {
  return async (dispatch) => {
    try {
      const response = await apiConnector('POST', sendOtpToContactPersonAPI, data)
      toast.success(response.data.message)
      return true
    } catch (error) {
      if (error.response) {
        toast.error(error?.response?.data?.message || 'Something Went Wrong')
      } else {
        console.log(error)
      }
    }

    return false
  }
}

export const verifyOtpOfContactPerson = (data) => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('POST', verifyOtpOfContactPersonAPI, data)
      dispatch(hideLoading())
      toast.success(response.data.message)
      return response.data.data
    } catch (error) {
      dispatch(hideLoading())
      if (error.response) {
        toast.error(error?.response?.data?.message || 'Something Went Wrong')
      } else {
        console.log(error)
      }
    }

    return null
  }
}

export const fetchOrgInfoBeforePublishing = () => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('GET', fetchOrgInfoBeforePublishingAPI)
      dispatch(hideLoading())
      return response.data.data.supplierProfile
    } catch (error) {
      dispatch(hideLoading())

      console.log(error)
    }

    return null
  }
}

export const fetchOpInfoBeforePublishing = () => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('GET', fetchOpInfoBeforePublishingAPI)
      dispatch(hideLoading())
      return response.data.data.supplierProfile
    } catch (error) {
      dispatch(hideLoading())

      console.log(error)
    }

    return null
  }
}

export const fetchItemInfoBeforePublishing = () => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('GET', fetchItemInfoBeforePublishingAPI)
      dispatch(hideLoading())
      return response.data.data.supplierProfile
    } catch (error) {
      dispatch(hideLoading())

      console.log(error)
    }

    return null
  }
}

export const saveOrgInfoAsDraft = (data) => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('POST', saveOrgInfoAsDraftAPI, data)
      dispatch(hideLoading())
      toast.success(response.data.message)
      return true
    } catch (error) {
      dispatch(hideLoading())
      if (error.response) {
        toast.error(error?.response?.data?.message || 'Something Went Wrong')
      } else {
        console.log(error)
      }
    }

    return false
  }
}

export const saveOpInfoAsDraft = (data) => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('POST', saveOpInfoAsDraftAPI, data)
      dispatch(hideLoading())
      toast.success(response.data.message)
      return true
    } catch (error) {
      dispatch(hideLoading())
      if (error.response) {
        toast.error(error?.response?.data?.message || 'Something Went Wrong')
      } else {
        console.log(error)
      }
    }

    return false
  }
}

export const saveItemInfoAsDraft = (data) => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('POST', saveItemInfoAsDraftAPI, data)
      dispatch(hideLoading())
      toast.success(response.data.message)
      return true
    } catch (error) {
      dispatch(hideLoading())
      if (error.response) {
        toast.error(error?.response?.data?.message || 'Something Went Wrong')
      } else {
        console.log(error)
      }
    }

    return false
  }
}

export const publishProfile = (data) => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('POST', publishProfileAPI, data)
      dispatch(hideLoading())
      toast.success(response.data.message)
      return true
    } catch (error) {
      dispatch(hideLoading())
      if (error.response) {
        toast.error(error?.response?.data?.message || 'Something Went Wrong')
      } else {
        console.log(error)
      }
    }

    return false
  }
}

export const supplierProfileInfo = () => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('GET', supplierProfileInfoAPI)
      dispatch(setsupplierProfile(response.data.data.supplierProfile))
      dispatch(hideLoading())
      return true
    } catch (error) {
      dispatch(hideLoading())
      console.log(error)
    }

    return false
  }
}
