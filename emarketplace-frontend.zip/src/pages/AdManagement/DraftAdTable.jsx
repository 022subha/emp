import React, { useEffect, useState } from 'react'
import {
  Table,
  Input,
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Row,
  Col,
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  Card,
  CardBody,
  FormGroup,
  Label,
  ListGroup,
  ListGroupItem,
  ModalFooter
} from 'reactstrap'
import './DraftTable.scss'
import { IoMdClose } from 'react-icons/io'
import DraftPhotoUpload from './AdPhotoUpload'
import DatePicker from 'react-datepicker'
import 'react-datepicker/dist/react-datepicker.css'
import { Controller, useForm } from 'react-hook-form'
import { useDispatch, useSelector } from 'react-redux'
import { deleteAd, fetchAdDetail, postDraftAd } from '../../services/controller/adAPI'
import { modifyAdAsDraft } from '../../services/controller/adAPI'
import { FaSort } from 'react-icons/fa'

const DraftTable = ({ draftAdList, fetchAdsData, toggle: toggleTab }) => {
  const dispatch = useDispatch()
  const {
    control,
    handleSubmit,
    getValues,
    setValue,
    reset,
    formState: { errors }
  } = useForm()

  const [searchTerm, setSearchTerm] = useState('')
  const [dropdownOpen, setDropdownOpen] = useState(-1)
  const [draftfiles, setDraftFiles] = useState(Array(10).fill(null))
  const [draftimages, setDraftImages] = useState(Array(10).fill(null))
  const [adId, setAdId] = useState(0)

  const adCategories = useSelector((state) => state.master.adCategories)
  const toggleDropdown = (index) => {
    setDropdownOpen(dropdownOpen === index ? -1 : index)
  }

  const [modal, setModal] = useState(false)
  const [deleteModal, setDeleteModal] = useState(false)
  const toggle = () => setModal(!modal)
  const toggleDeleteModal = () => setDeleteModal((prev) => !prev)
  const deleteAdHandler = () => {
    dispatch(deleteAd(adId)).then((success) => {
      if (success) {
        fetchAdsData()
        toggleDeleteModal()
        toggleTab('3')
      }
    })
  }

  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' })

  const handleSort = (key) => {
    setSortConfig((prevState) => {
      const direction = prevState.key === key && prevState.direction === 'asc' ? 'desc' : 'asc'
      return { key, direction }
    })
  }

  const sortedDrafts = [...draftAdList].sort((a, b) => {
    if (sortConfig.key) {
      const aKey = a[sortConfig.key]?.toString()?.toLowerCase()
      const bKey = b[sortConfig.key]?.toString()?.toLowerCase()
      if (aKey < bKey) return sortConfig.direction === 'asc' ? -1 : 1
      if (aKey > bKey) return sortConfig.direction === 'asc' ? 1 : -1
    }
    return 0
  })

  const filteredDrafts = (sortedDrafts || []).filter(({ title }) => title?.toLowerCase().includes(searchTerm.toLowerCase()))

  const [modalOpen, setModalOpen] = useState(false)
  const [modalContent, setModalContent] = useState('')
  const toggleModal = () => setModalOpen((prev) => !prev)

  const truncateText = (text, maxLength) => {
    if (text && text.length > maxLength) {
      return (
        <>
          {text.slice(0, maxLength)} ...
          <span
            className="read-more"
            onClick={() => {
              setModalContent(text)
              toggleModal()
            }}>
            {' '}
            Read More
          </span>
        </>
      )
    }
    return text || 'Not Available'
  }

  const [startDate, setStartDate] = useState(null)
  const [endDate, setEndDate] = useState(null)
  const [adDetail, setAdDetail] = useState(null)

  const fetchAdInfo = (id) => {
    setAdId(id)
    dispatch(fetchAdDetail(id))
      .then((res) => {
        setAdDetail(res)
        setStartDate(res?.offerStartDate)
        setEndDate(res?.offerEndDate)
        setValue('categoryId', res?.category?.id || '')
        setValue('AdTitle', res?.title || '')
        setValue('startDate', new Date(res?.offerStartDate))
        setValue('endDate', new Date(res?.offerEndDate))
        setValue('AdDescription', res?.description || '')
        setValue('AdDealTerms', res?.dealTerms || '')
        if (res.banners && res.banners.length > 0) {
          const fileUrls = res.banners.map((item) => `https://e-marketplace.s3.ap-south-1.amazonaws.com/${item.fileUrl}`)
          const bannerLen = res.banners.length
          const restSlots = Array(10 - bannerLen).fill(null)
          setDraftImages([...fileUrls, ...restSlots])
        }
        toggle()
      })
      .catch((error) => {
        console.log(error)
      })
  }

  const modifyAsDraftAdHandler = () => {
    const data = getValues()

    const isNotEmpty = (value) => value && value !== ''
    const parseNumber = (value) => (isNotEmpty(value) ? parseInt(value) : null)

    const payload = {
      categoryId: parseNumber(data.categoryId),
      title: isNotEmpty(data.AdTitle) ? data.AdTitle : null,
      description: isNotEmpty(data.AdDescription) ? data.AdDescription : null,
      dealTerms: isNotEmpty(data.AdDealTerms) ? data.AdDealTerms : null,
      offerStartDate: data.startDate ? new Date(data.startDate.getTime() + 86400000).toISOString().split('T')[0] : null,
      offerEndDate: data.endDate ? new Date(data.endDate.getTime() + 86400000).toISOString().split('T')[0] : null,
      bannerUrls: []
    }

    const adFormData = new FormData()
    adFormData.append('data', JSON.stringify(payload))

    draftfiles.forEach((banners, index) => {
      if (banners) adFormData.append(`banners${index + 1}`, banners)
    })

    dispatch(modifyAdAsDraft(adId, adFormData))
  }

  const postDraftAdHandler = (data) => {
    data = getValues()
    console.log('data ', data)
    const isNotEmpty = (value) => value && value !== ''
    const parseNumber = (value) => (isNotEmpty(value) ? parseInt(value) : null)

    const payload = {
      categoryId: parseNumber(data.categoryId),
      title: isNotEmpty(data.AdTitle) ? data.AdTitle : null,
      description: isNotEmpty(data.AdDescription) ? data.AdDescription : null,
      dealTerms: isNotEmpty(data.AdDealTerms) ? data.AdDealTerms : null,
      offerStartDate: data.startDate ? new Date(data.startDate.getTime() + 86400000).toISOString().split('T')[0] : null,
      offerEndDate: data.endDate ? new Date(data.endDate.getTime() + 86400000).toISOString().split('T')[0] : null
    }

    const adFormData = new FormData()
    adFormData.append('data', JSON.stringify(payload))

    draftfiles.forEach((banners, index) => {
      if (banners) adFormData.append(`banners${index + 1}`, banners)
    })

    dispatch(postDraftAd(adId, adFormData)).then((res) => {
      if (res) {
        reset()
      }
    })
  }

  const toggleFirstAdFull = () => setModal(!modal)

  return (
    <div className="draft-table-container">
      <div className="header p-2">
        {/* <h5 className="table-title">Saved as Draft</h5> */}
        <Input
          type="text"
          placeholder="Search"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="search-bar"
        />
      </div>
      <Table
        borderless
        className="">
        <thead className="table-header table-dark-custom">
          <tr>
            <th>#</th>
            <th>Title</th>
            <th>Category</th>
            <th onClick={() => handleSort('updatedAt')}>
              Last Edited On
              <FaSort className="cursor-pointer" />
            </th>
            <th className="text-center">Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredDrafts?.length > 0 ? (
            filteredDrafts.map((draft, index) => (
              <tr
                key={filteredDrafts.id}
                className="border-top">
                <td>{index + 1}</td>
                <td style={{ maxWidth: '400px' }}>{truncateText(draft.title, 60)}</td>
                <td style={{ minWidth: '200px' }}>{truncateText(draft?.category?.hsnDescription, 40)}</td>
                <td style={{ minWidth: '150px' }}>{new Date(draft.updatedAt).toLocaleString('en-GB')}</td>
                <td className="text-center">
                  <ButtonDropdown
                    isOpen={dropdownOpen === index}
                    toggle={() => toggleDropdown(index)}>
                    <DropdownToggle className="action-button">⋮</DropdownToggle>
                    <DropdownMenu>
                      <DropdownItem
                        onClick={() => {
                          fetchAdInfo(draft.id)
                        }}>
                        View / Edit AD
                      </DropdownItem>
                      <DropdownItem
                        className="text-danger danger"
                        onClick={() => {
                          setAdId(draft.id)
                          toggleDeleteModal()
                        }}>
                        Discard AD
                      </DropdownItem>
                    </DropdownMenu>
                  </ButtonDropdown>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td
                style={{ fontSize: '20px' }}
                className="text-center p-2"
                colSpan={5}>
                No Data Available
              </td>
            </tr>
          )}
        </tbody>
      </Table>

      <Modal
        isOpen={modal}
        toggle={toggle}
        size="xl">
        <ModalHeader
          className="custom-modal-header"
          toggle={toggle}>
          AD Draft
        </ModalHeader>
        <ModalBody className="p-0">
          <Card className="postAdWrapper">
            <ListGroup
              className="PostAdList"
              flush>
              <ListGroupItem>
                <Row>
                  <Col
                    xs={12}
                    md={2}>
                    <FormGroup>
                      <Label for="Ad Category">Select AD Category *</Label>
                      <Controller
                        defaultValue=""
                        name="categoryId"
                        control={control}
                        rules={{
                          required: 'Category is required'
                        }}
                        render={({ field, fieldState: { error } }) => (
                          <>
                            <Input
                              {...field}
                              type="select"
                              id="categoryId"
                              invalid={error ? true : false}
                              className={error ? 'error-input' : ''}>
                              <option value="">Select Catgeory</option>
                              {(adCategories || []).map((item) => (
                                <option
                                  key={item.id}
                                  value={item.id}>
                                  {item.hsnDescription} ({item.hsnCode.toString().padStart(4, '0')})
                                </option>
                              ))}
                            </Input>
                            {error && <span className="text-danger error-message">{error.message}</span>}
                          </>
                        )}
                      />
                    </FormGroup>
                  </Col>
                  <Col
                    xs={12}
                    md={6}>
                    <FormGroup>
                      <Label for="Ad Title">AD Title *</Label>
                      <Controller
                        defaultValue=""
                        name="AdTitle"
                        control={control}
                        rules={{
                          required: 'Title is required',
                          maxLength: { value: 1000, message: 'Title cannot exceed 1000 characters' }
                        }}
                        render={({ field, fieldState: { error } }) => (
                          <>
                            <Input
                              {...field}
                              type="text"
                              id="AdTitle"
                              placeholder="Enter title"
                              invalid={error ? true : false}
                              className={error ? 'error-input' : ''}
                            />
                            {error && <span className="text-danger error-message">{error.message}</span>}
                          </>
                        )}
                      />
                      <Row className="justify-content-between mt-1">
                        <Col>
                          <span className="text-muted">Mention key features of your item</span>
                        </Col>
                        <Col>
                          <span className="text-muted float-end">0/1000</span>
                        </Col>
                      </Row>
                    </FormGroup>
                  </Col>
                  <Col
                    xs={12}
                    md={4}>
                    <Label for="Ad Title">Select Offer Start & End Date *</Label>
                    <div className="d-flex align-items-center justify-content-center border-primary-brand rounded bg-white">
                      <DatePicker
                        selected={startDate}
                        onChange={(date) => setStartDate(date)}
                        placeholderText="Start date"
                        className="form-control border-0"
                        dateFormat="MM/dd/yyyy"
                      />
                      <Controller
                        defaultValue=""
                        name="startDate"
                        control={control}
                        rules={{
                          required: 'Start date is required'
                        }}
                        render={({ field, fieldState: { error } }) => (
                          <>{error && <span className="text-danger error-message">{error.message}</span>}</>
                        )}
                      />
                      <span className="mx-2">&#8594;</span>
                      <DatePicker
                        selected={endDate}
                        onChange={(date) => setEndDate(date)}
                        placeholderText="End date"
                        className="form-control border-0"
                        dateFormat="MM/dd/yyyy"
                      />
                      <Controller
                        defaultValue=""
                        name="endDate"
                        control={control}
                        rules={{
                          required: 'End date is required'
                        }}
                        render={({ field, fieldState: { error } }) => (
                          <>{error && <span className="text-danger error-message">{error.message}</span>}</>
                        )}
                      />
                      <i
                        className="bi bi-calendar me-2"
                        style={{ fontSize: '20px' }}></i>
                    </div>
                  </Col>
                </Row>
              </ListGroupItem>
              <ListGroupItem>
                <Row>
                  <Col xs={12}>
                    <FormGroup>
                      <Label for="Description">Description *</Label>
                      <Controller
                        defaultValue=""
                        name="AdDescription"
                        control={control}
                        rules={{
                          required: 'Description is required',
                          maxLength: { value: 1000, message: 'Description cannot exceed 1000 characters' }
                        }}
                        render={({ field, fieldState: { error } }) => (
                          <>
                            <Input
                              {...field}
                              type="textarea"
                              id="AdDescription"
                              placeholder="Enter Description"
                              invalid={error ? true : false}
                              className={error ? 'error-input' : ''}
                            />
                            {error && <span className="text-danger error-message">{error.message}</span>}
                          </>
                        )}
                      />
                      <Row className="justify-content-between mt-1">
                        <Col>
                          <span className="text-muted">Mention key features of your item</span>
                        </Col>
                        <Col>
                          <span className="text-muted float-end">0/3000</span>
                        </Col>
                      </Row>
                    </FormGroup>
                  </Col>
                  <Col xs={12}>
                    <FormGroup>
                      <Label for="Description">Deal Terms *</Label>
                      <Controller
                        defaultValue=""
                        name="AdDealTerms"
                        control={control}
                        rules={{
                          required: 'Deal Terms is required',
                          maxLength: { value: 1000, message: 'Deal Terms cannot exceed 1000 characters' }
                        }}
                        render={({ field, fieldState: { error } }) => (
                          <>
                            <Input
                              {...field}
                              type="textarea"
                              id="AdDealTerms"
                              placeholder="Enter Deal Terms"
                              invalid={error ? true : false}
                              className={error ? 'error-input' : ''}
                            />
                            {error && <span className="text-danger error-message">{error.message}</span>}
                          </>
                        )}
                      />
                      <Row className="justify-content-between mt-1">
                        <Col>
                          <span className="text-muted">Mention key features of your item</span>
                        </Col>
                        <Col>
                          <span className="text-muted float-end">0/3000</span>
                        </Col>
                      </Row>
                    </FormGroup>
                  </Col>
                </Row>
              </ListGroupItem>
              <ListGroupItem>
                <Row>
                  <Col xs={12}>
                    <DraftPhotoUpload
                      control={control}
                      imgFiles={draftfiles}
                      setImgFiles={setDraftFiles}
                      images={draftimages}
                      errors={errors}
                      setImages={setDraftImages}
                      type="draftad"
                    />
                  </Col>
                </Row>
              </ListGroupItem>
            </ListGroup>
            <CardBody className="text-end">
              <Button
                className="primary-btn ms-2"
                onClick={modifyAsDraftAdHandler}>
                Save as Draft
              </Button>
              <Button
                color="success ms-2"
                onClick={postDraftAdHandler}>
                Post
              </Button>
            </CardBody>
          </Card>
        </ModalBody>
      </Modal>

      <Modal
        isOpen={modalOpen}
        toggle={toggleModal}>
        <ModalHeader toggle={toggleModal}>Ad Title</ModalHeader>
        <ModalBody>{modalContent}</ModalBody>
      </Modal>

      <Modal
        centered={true}
        isOpen={deleteModal}
        toggle={toggleDeleteModal}
        className="flex justify-center items-center">
        <ModalHeader toggle={toggleDeleteModal}>Discard Draft Ad</ModalHeader>
        <ModalBody>Are you sure you want to delete this draft ad? This action cannot be undone.</ModalBody>
        <ModalFooter>
          <Button
            color="danger"
            onClick={() => {
              // Add your delete logic here
              deleteAdHandler()
            }}>
            Confirm
          </Button>
          <Button
            color="secondary"
            onClick={toggleDeleteModal}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>
    </div>
  )
}

export default DraftTable
