import {
  setAdCategories,
  setBussinessScales,
  setCityList,
  setCountryList,
  setHsnCategories,
  setNatureOfBussiness,
  setStateList,
  setSubscriptionPlans,
  setUomList
} from '../../store/slices/masterSlice'
import { hideLoading, showLoading } from '../../store/slices/uiSlice'
import { masterEndPoints } from '../api'
import { apiConnector } from '../apiConnector'

const { country, state, city, uom, hsn, bussinessScales, natureOfBussiness, adCategories, subscriptionPlans } = masterEndPoints

export const fetchCountryList = () => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('GET', country)
      console.log(response)
      dispatch(setCountryList(response.data.data.countries))
      dispatch(hideLoading())
      return true
    } catch (error) {
      dispatch(hideLoading())
      console.log(error)
    }

    return false
  }
}

export const fetchStateList = (countryId) => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('GET', state + '/' + countryId)
      dispatch(setStateList({ country: countryId, states: response.data.data.states }))
      dispatch(hideLoading())
      return true
    } catch (error) {
      dispatch(hideLoading())
      console.log(error)
    }

    return false
  }
}

export const fetchCityList = (countryId, stateId) => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('GET', city + '/' + countryId + '/' + stateId)
      dispatch(setCityList({ state: `${countryId}-${stateId}`, cities: response.data.data.cities }))
      dispatch(hideLoading())
      return true
    } catch (error) {
      dispatch(hideLoading())
      console.log(error)
    }

    return false
  }
}

export const getCountryList = () => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('GET', country)
      dispatch(hideLoading())
      return response.data.data.countries
    } catch (error) {
      dispatch(hideLoading())
      console.log(error)
    }

    return []
  }
}

export const getStateList = (countryId) => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('GET', state + '/' + countryId)
      dispatch(hideLoading())
      return response.data.data.states
    } catch (error) {
      dispatch(hideLoading())
      console.log(error)
    }

    return []
  }
}

export const getCityList = (countryId, stateId) => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('GET', city + '/' + countryId + '/' + stateId)
      dispatch(hideLoading())
      return response.data.data.cities
    } catch (error) {
      dispatch(hideLoading())
      console.log(error)
    }

    return []
  }
}

export const fetchUOMList = () => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('GET', uom)
      dispatch(setUomList(response.data.data.uoms))
      dispatch(hideLoading())
      return true
    } catch (error) {
      dispatch(hideLoading())
      console.log(error)
    }
    return false
  }
}

export const fetchHSNCategories = () => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('GET', hsn)
      dispatch(setHsnCategories(response.data.data.hsnCategories))
      dispatch(hideLoading())
      return true
    } catch (error) {
      dispatch(hideLoading())
      console.log(error)
    }
    return false
  }
}

export const fetchAllMasterLists = () => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const [
        hsnResponse,
        uomResponse,
        countryResponse,
        adCategoriesResponse,
        bussinessScaleResponse,
        natureOfBussinessResponse,
        subscriptionPlansResponse
      ] = await Promise.all([
        apiConnector('GET', hsn),
        apiConnector('GET', uom),
        apiConnector('GET', country),
        apiConnector('GET', adCategories),
        apiConnector('GET', bussinessScales),
        apiConnector('GET', natureOfBussiness),
        apiConnector('GET', subscriptionPlans)
      ])

      dispatch(setUomList(uomResponse.data.data.uoms))
      dispatch(setCountryList(countryResponse.data.data.countries))
      dispatch(setHsnCategories(hsnResponse.data.data.hsnCategories))
      dispatch(setAdCategories(adCategoriesResponse.data.data.adCategories))
      dispatch(setBussinessScales(bussinessScaleResponse.data.data.bussinessScales))
      dispatch(setNatureOfBussiness(natureOfBussinessResponse.data.data.natureOfBussiness))
      dispatch(setSubscriptionPlans(subscriptionPlansResponse.data.data.subscriptionPlans))
      dispatch(hideLoading())
      return true
    } catch (error) {
      dispatch(hideLoading())
      console.log(error)
    }
    return false
  }
}
