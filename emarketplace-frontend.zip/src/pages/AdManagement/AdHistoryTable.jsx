import {
  Col,
  Row,
  Card,
  Badge,
  Label,
  Modal,
  Input,
  Table,
  Button,
  Tooltip,
  Carousel,
  CardBody,
  CardText,
  ModalBody,
  CardTitle,
  FormGroup,
  ListGroup,
  ModalHeader,
  ModalFooter,
  DropdownItem,
  DropdownMenu,
  CarouselItem,
  ListGroupItem,
  DropdownToggle,
  ButtonDropdown,
  CarouselControl,
  CarouselIndicators
} from 'reactstrap'
import './DraftTable.scss'
import PhotoUpload from './AdPhotoUpload'
import DatePicker from 'react-datepicker'
import { FaEye, FaSort } from 'react-icons/fa'
import React, { useEffect, useState } from 'react'
import { Controller, useForm } from 'react-hook-form'
import { useDispatch, useSelector } from 'react-redux'
import ImgPng from '../../assets/images/icons/image.webp'
import { deleteAd, fetchAdDetail, postAd, saveAdAsDraft } from '../../services/controller/adAPI'

const DraftTable = ({ adHistory, fetchAdsData, toggle }) => {
  const [ad, setAd] = useState(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [modalOpen, setModalOpen] = useState(false)
  const [activeIndex, setActiveIndex] = useState(0)
  const [animating, setAnimating] = useState(false)
  const [dropdownOpen, setDropdownOpen] = useState(-1)
  const [modalContent, setModalContent] = useState('')
  const [viewAdModal, setViewAdModal] = useState(false)
  const [duplicateAdModal, setDuplicateAdModal] = useState(false)
  const [placeHolder, setPlaceHolder] = useState('')
  const placeHolders = ['Title']

  useEffect(() => {
    const intervalId = setInterval(() => {
      setPlaceHolder((prev) => {
        const currentIndex = placeHolders.indexOf(prev)
        const nextIndex = (currentIndex + 1) % placeHolders.length
        return placeHolders[nextIndex]
      })
    }, 1000)
    return () => clearInterval(intervalId)
  })

  const [tooltipOpen, setTooltipOpen] = useState({
    tooltip1: false,
    tooltip2: false,
    tooltip3: false,
    tooltip4: false
  })

  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' })
  const dispatch = useDispatch()
  const toggleDropdown = (index) => {
    setDropdownOpen(dropdownOpen === index ? -1 : index)
  }

  const toggleModal = () => setModalOpen((prev) => !prev)
  const toggleViewAdModal = () => setViewAdModal((prev) => !prev)
  const toggleDuplicateAdModal = () => setDuplicateAdModal((prev) => !prev)

  const next = () => {
    if (animating) return
    const nextIndex = activeIndex === ad.banners.filter(Boolean).length - 1 ? 0 : activeIndex + 1
    setActiveIndex(nextIndex)
  }

  const previous = () => {
    if (animating) return
    const nextIndex = activeIndex === 0 ? ad.banners.filter(Boolean).length - 1 : activeIndex - 1
    setActiveIndex(nextIndex)
  }

  const goToIndex = (newIndex) => {
    if (animating) return
    setActiveIndex(newIndex)
  }

  const toggleTooltip = (tooltipId) => {
    setTooltipOpen((prevState) => ({
      ...prevState,
      [tooltipId]: !prevState[tooltipId]
    }))
  }

  const handleSort = (key) => {
    setSortConfig((prevState) => {
      const direction = prevState.key === key && prevState.direction === 'asc' ? 'desc' : 'asc'
      return { key, direction }
    })
  }

  const sortedDrafts = [...adHistory].sort((a, b) => {
    if (sortConfig.key) {
      const aKey = a[sortConfig.key]?.toString()?.toLowerCase()
      const bKey = b[sortConfig.key]?.toString()?.toLowerCase()
      if (aKey < bKey) return sortConfig.direction === 'asc' ? -1 : 1
      if (aKey > bKey) return sortConfig.direction === 'asc' ? 1 : -1
    }
    return 0
  })

  const filteredDrafts = sortedDrafts.filter((draft) => searchTerm === '' || draft?.title?.toLowerCase().includes(searchTerm.toLowerCase()))

  const getStatusPill = (status) => {
    const formattedStatus = status.charAt(0).toUpperCase() + status.slice(1).toLowerCase()
    const statusColors = {
      Live: 'primary',
      Draft: 'warning'
    }
    return <span className={`badge bg-${statusColors[formattedStatus]}`}>{formattedStatus}</span>
  }

  const truncateText = (text, maxLength) => {
    if (text && text.length > maxLength) {
      return (
        <>
          {text.slice(0, maxLength)} ...
          <span
            className="read-more"
            onClick={() => {
              setModalContent(text)
              toggleModal()
            }}>
            {' '}
            Read More
          </span>
        </>
      )
    }
    return text || 'Not Available'
  }

  const adCategories = useSelector((state) => state.master.adCategories)

  const [files, setFiles] = useState(Array(10).fill(null))
  const [images, setImages] = useState(Array(10).fill(null))

  const [deleteModal, setDeleteModal] = useState(false)
  const [adId, setAdId] = useState(0)
  const {
    watch,
    reset,
    control,
    setValue,
    getValues,
    handleSubmit,
    formState: { errors }
  } = useForm()

  const postAdHandler = (data) => {
    const isNotEmpty = (value) => value && value !== ''
    const parseNumber = (value) => (isNotEmpty(value) ? parseInt(value) : null)

    const payload = {
      categoryId: parseNumber(data.categoryId),
      title: isNotEmpty(data.title) ? data.title : null,
      description: isNotEmpty(data.description) ? data.description : null,
      dealTerms: isNotEmpty(data.dealTerms) ? data.dealTerms : null,
      offerStartDate: data.startDate ? new Date(data.startDate.getTime() + 86400000).toISOString().split('T')[0] : null,
      offerEndDate: data.endDate ? new Date(data.endDate.getTime() + 86400000).toISOString().split('T')[0] : null
    }

    const adFormData = new FormData()
    adFormData.append('data', JSON.stringify(payload))

    files.forEach((banner, index) => {
      if (banner) adFormData.append(`banners${index + 1}`, banner)
    })

    dispatch(postAd(adFormData)).then((res) => {
      if (res) {
        reset()
        setFiles(Array(10).fill(null))
        setImages(Array(10).fill(null))
        toggleViewAdModal()
        toggle('4')
      }
    })
  }

  const saveAsDraftAdHandler = () => {
    const data = getValues()

    const isNotEmpty = (value) => value && value !== ''
    const parseNumber = (value) => (isNotEmpty(value) ? parseInt(value) : null)

    const payload = {
      categoryId: parseNumber(data.categoryId),
      title: isNotEmpty(data.title) ? data.title : null,
      description: isNotEmpty(data.description) ? data.description : null,
      dealTerms: isNotEmpty(data.dealTerms) ? data.dealTerms : null,
      offerStartDate: data.startDate ? new Date(data.startDate.getTime() + 86400000).toISOString().split('T')[0] : null,
      offerEndDate: data.endDate ? new Date(data.endDate.getTime() + 86400000).toISOString().split('T')[0] : null
    }

    const adFormData = new FormData()
    adFormData.append('data', JSON.stringify(payload))

    files.forEach((banner, index) => {
      if (banner) adFormData.append(`banners${index + 1}`, banner)
    })

    dispatch(saveAdAsDraft(adFormData)).then((success) => {
      if (success) {
        reset()
        setFiles(Array(10).fill(null))
        setImages(Array(10).fill(null))
        toggleDuplicateAdModal()
        toggle('3')
      }
    })
  }

  const handleCloneAd = (adId) => {
    dispatch(fetchAdDetail(adId)).then((adDetail) => {
      if (adDetail) {
        setValue('categoryId', adDetail.category.id)
        setValue('title', adDetail.title)
        setValue('startDate', new Date(adDetail.offerStartDate))
        setValue('endDate', new Date(adDetail.offerEndDate))
        setValue('description', adDetail.description)
        setValue('dealTerms', adDetail.dealTerms)
        setImages(Array(10).fill(null))
        setFiles(Array(10).fill(null))
        // if (adDetail.banners && adDetail.banners.length > 0) {
        //   const fileUrls = adDetail.banners.map((item) => `https://e-marketplace.s3.ap-south-1.amazonaws.com/${item.fileUrl}`)
        //   const bannerLen = adDetail.banners.length
        //   const restSlots = Array(10 - bannerLen).fill(null)
        //   setImages([...fileUrls, ...restSlots])
        // }
        toggleDuplicateAdModal()
      }
    })
  }

  const toggleDeleteModal = () => setDeleteModal((prev) => !prev)
  const deleteAdHandler = () => {
    dispatch(deleteAd(adId)).then((success) => {
      if (success) {
        fetchAdsData()
        toggleDeleteModal()
      }
    })
  }

  return (
    <div className="draft-table-container">
      <div className="header p-2">
        <Input
          type="text"
          placeholder={`Search By "${placeHolder}"`}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="search-bar"
        />
      </div>
      <Table
        borderless
        className="custom-table">
        <thead className="table-header table-dark-custom">
          <tr>
            <th>#</th>
            <th>Title</th>
            <th onClick={() => handleSort('offerStartDate')}>
              Offer Start Date <FaSort className="cursor-pointer" />
            </th>
            <th onClick={() => handleSort('offerEndDate')}>
              Offer End Date <FaSort className="cursor-pointer" />
            </th>
            <th onClick={() => handleSort('status')}>
              Status <FaSort className="cursor-pointer" />
            </th>
            <th
              onClick={() => handleSort('viewCount')}
              style={{ textAlign: 'center' }}>
              View Count <FaSort className="cursor-pointer" />
            </th>
            <th style={{ textAlign: 'center' }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredDrafts.length > 0 ? (
            filteredDrafts.map((draft, index) => (
              <tr key={draft.id}>
                <td>{index + 1}</td>
                <td>{truncateText(draft?.title, 60)}</td>
                <td>{draft?.offerStartDate?.split('T')[0]?.split('-')?.reverse()?.join('/') || 'Not Available'}</td>
                <td>{draft?.offerEndDate?.split('T')[0]?.split('-')?.reverse()?.join('/') || 'Not Available'}</td>
                <td>{getStatusPill(draft?.status)}</td>
                <td style={{ textAlign: 'center' }}>{draft?.viewsCount}</td>
                <td className="d-flex justify-content-center">
                  <ButtonDropdown
                    isOpen={dropdownOpen === index}
                    toggle={() => toggleDropdown(index)}>
                    <DropdownToggle className="action-button">⋮</DropdownToggle>
                    <DropdownMenu>
                      <DropdownItem
                        onClick={() => {
                          dispatch(fetchAdDetail(draft.id)).then((adDetail) => {
                            if (adDetail) {
                              setAd(adDetail)
                              toggleViewAdModal()
                            }
                          })
                        }}>
                        View Ad
                      </DropdownItem>
                      {draft.status != 'draft' && (
                        <DropdownItem
                          onClick={() => {
                            handleCloneAd(draft.id)
                          }}>
                          Clone Ad
                        </DropdownItem>
                      )}
                      <DropdownItem
                        className="text-danger"
                        onClick={() => {
                          setAdId(draft.id)
                          toggleDeleteModal()
                        }}>
                        Discard Ad
                      </DropdownItem>
                    </DropdownMenu>
                  </ButtonDropdown>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td
                style={{ fontSize: '20px' }}
                className="text-center p-2"
                colSpan={7}>
                No Data Available
              </td>
            </tr>
          )}
        </tbody>
      </Table>

      <Modal
        isOpen={modalOpen}
        toggle={toggleModal}
        centered={true}>
        <ModalHeader toggle={toggleModal}>Ad Title</ModalHeader>
        <ModalBody>{modalContent}</ModalBody>
      </Modal>

      <Modal
        isOpen={viewAdModal}
        toggle={toggleViewAdModal}
        size="xl">
        <ModalHeader
          className="post__ad-modal-header"
          toggle={toggleViewAdModal}>
          AD Details
        </ModalHeader>
        <ModalBody className="post__ad-modal-body">
          <Card className="post__ad-modal-wrapper">
            {ad?.banners?.length > 0 ? (
              <Carousel
                dark={true}
                fade={false}
                slide={true}
                next={next}
                previous={previous}
                activeIndex={activeIndex}>
                <CarouselIndicators
                  items={ad?.banners || []}
                  activeIndex={activeIndex}
                  onClickHandler={goToIndex}
                />
                {ad.banners.map((item) => {
                  return (
                    <CarouselItem
                      onExiting={() => setAnimating(true)}
                      onExited={() => setAnimating(false)}
                      key={item}>
                      <img src={`https://e-marketplace.s3.ap-south-1.amazonaws.com/${item.fileUrl}`} />
                    </CarouselItem>
                  )
                })}
                <CarouselControl
                  direction="prev"
                  directionText="Previous"
                  onClickHandler={previous}
                />
                <CarouselControl
                  direction="next"
                  directionText="Next"
                  onClickHandler={next}
                />
              </Carousel>
            ) : (
              <img
                src={ImgPng}
                style={{ objectFit: 'contain' }}
              />
            )}

            <CardBody>
              <CardTitle
                className="row"
                tag="h5">
                <Col className="flex-grow-1 post__ad-modal-title">
                  <span id="tooltip1">{ad?.title || 'Not Available'}</span>
                </Col>
                {ad?.title && (
                  <Tooltip
                    placement="top"
                    isOpen={tooltipOpen.tooltip1}
                    autohide={false}
                    target="tooltip1"
                    toggle={() => toggleTooltip('tooltip1')}>
                    {ad?.title}
                  </Tooltip>
                )}
                <Col xs={'auto'}>
                  <Badge
                    pill
                    className="float-end"
                    color="primary">
                    <span className="text-decoration-none text-light d-flex align-items-center">
                      <FaEye /> <span className="ms-2">{ad?.viewsCount || 0}</span>
                    </span>
                  </Badge>
                </Col>
              </CardTitle>
            </CardBody>
            <ListGroup
              className="PostAdList"
              flush>
              <ListGroupItem>
                <CardText>
                  <span className="fw-bold">Category:</span> <span>{ad?.category?.hsnDescription || 'Not Available'}</span>
                </CardText>
              </ListGroupItem>
              <ListGroupItem>
                <CardText>
                  <span className="fw-bold">Offer Start & End Date:</span>{' '}
                  <span>
                    {ad?.offerStartDate?.split('T')[0]?.split('-').reverse().join('/') || 'Not Available'} -{' '}
                    {ad?.offerEndDate?.split('T')[0]?.split('-').reverse().join('/') || 'Not Available'}
                  </span>
                </CardText>
              </ListGroupItem>
              <ListGroupItem>
                <CardText>
                  <span className="fw-bold">Description:</span> <span>{ad?.description || 'Not Available'}</span>
                </CardText>
              </ListGroupItem>
              <ListGroupItem>
                <CardText>
                  <span className="fw-bold">Deal Terms:</span> <span>{ad?.dealTerms || 'Not Available'}</span>
                </CardText>
              </ListGroupItem>
            </ListGroup>
          </Card>
        </ModalBody>
      </Modal>

      <Modal
        isOpen={duplicateAdModal}
        toggle={duplicateAdModal}
        centered={true}
        fullscreen={true}
        size="xl">
        <ModalHeader
          className="duplicate__ad-modal-header"
          toggle={toggleDuplicateAdModal}>
          AD Clone
        </ModalHeader>
        <ModalBody className="duplicate__ad-modal-body">
          <Card className="postAdWrapper">
            <ListGroup
              className="PostAdList"
              flush>
              <ListGroupItem>
                <Row>
                  <Col
                    xs={12}
                    md={3}>
                    <FormGroup className="post-ad-form__input-container">
                      <Label
                        for="Ad Category"
                        className="mandatory-label">
                        AD Category
                      </Label>
                      <Controller
                        defaultValue=""
                        name="categoryId"
                        control={control}
                        rules={{
                          required: 'Category is required'
                        }}
                        render={({ field, fieldState: { error } }) => (
                          <>
                            <Input
                              {...field}
                              type="select"
                              id="categoryId"
                              invalid={error ? true : false}
                              className={error ? 'error-input' : ''}>
                              <option value="">Select Ad Catgeory</option>
                              {(adCategories || []).map((item) => (
                                <option
                                  key={item.id}
                                  value={item.id}>
                                  {item.hsnDescription} ({item.hsnCode.toString().padStart(4, '0')})
                                </option>
                              ))}
                            </Input>
                            {error && <span className="text-danger error-message">{error.message}</span>}
                          </>
                        )}
                      />
                    </FormGroup>
                  </Col>
                  <Col
                    xs={12}
                    md={6}>
                    <FormGroup className="post-ad-form__input-container">
                      <Label
                        for="Ad Title"
                        className="mandatory-label">
                        AD Title
                      </Label>

                      <Controller
                        defaultValue=""
                        name="title"
                        control={control}
                        rules={{
                          required: 'Title is required',
                          maxLength: { value: 1000, message: 'Title cannot exceed 1000 characters' }
                        }}
                        render={({ field, fieldState: { error } }) => (
                          <>
                            <Input
                              {...field}
                              type="text"
                              id="title"
                              placeholder="Enter title"
                              invalid={error ? true : false}
                              className={error ? 'error-input' : ''}
                            />

                            <Row className="justify-content-between mt-1">
                              <Col>
                                {error ? (
                                  <span className="text-danger error-message">{error.message}</span>
                                ) : (
                                  <span className="text-muted">Mention key features of your item</span>
                                )}
                              </Col>
                              <Col>
                                <span className="text-muted float-end">{field.value.length}/1000</span>
                              </Col>
                            </Row>
                          </>
                        )}
                      />
                    </FormGroup>
                  </Col>
                  <Col
                    xs={12}
                    md={3}
                    className="post-ad-form__input-container">
                    <Label
                      for="Ad Title"
                      className="mandatory-label">
                      Offer Start & End Date
                    </Label>
                    <div className="d-flex align-items-center justify-content-center border-primary-brand rounded bg-white">
                      <Controller
                        name="startDate"
                        control={control}
                        rules={{
                          required: 'Start date is required'
                        }}
                        defaultValue={null}
                        render={({ field, fieldState: { error } }) => (
                          <>
                            <DatePicker
                              {...field}
                              selected={field.value}
                              placeholderText="Start date"
                              className={`form-control border-0 ${error ? 'error-input' : ''}`}
                              dateFormat="dd/MM/yyyy"
                              minDate={new Date()}
                              maxDate={watch('endDate') ? new Date(new Date(watch('endDate')).getTime() - 86400000) : null}
                              onChange={(e) => field.onChange(e)}
                            />
                          </>
                        )}
                      />
                      <span className="mx-2">&#8594;</span>
                      <Controller
                        name="endDate"
                        control={control}
                        rules={{
                          required: 'End date is required'
                        }}
                        defaultValue={null}
                        render={({ field, fieldState: { error } }) => (
                          <>
                            <DatePicker
                              {...field}
                              selected={field.value}
                              placeholderText="End date"
                              className={`form-control border-0 ${error ? 'error-input' : ''}`}
                              dateFormat="dd/MM/yyyy"
                              minDate={
                                watch('startDate')
                                  ? new Date(new Date(watch('startDate')).getTime() + 86400000)
                                  : new Date(new Date().getTime() + 86400000)
                              }
                              onChange={(e) => field.onChange(e)}
                            />
                          </>
                        )}
                      />

                      <i
                        className="bi bi-calendar ms-2"
                        style={{ fontSize: '20px' }}></i>
                    </div>
                    {errors.startDate && errors.endDate ? (
                      <span className="text-danger error-message">Start & End Date is required</span>
                    ) : errors.startDate ? (
                      <span className="text-danger error-message">Start Date is required</span>
                    ) : (
                      errors.endDate && <span className="text-danger error-message">End Date is required</span>
                    )}
                  </Col>
                </Row>
              </ListGroupItem>
              <ListGroupItem>
                <Row>
                  <Col xs={12}>
                    <FormGroup className="post-ad-form__input-container description-container">
                      <Label
                        for="Description"
                        className="mandatory-label">
                        Description
                      </Label>
                      <Controller
                        defaultValue=""
                        name="description"
                        control={control}
                        rules={{
                          required: 'Description is required',
                          maxLength: { value: 1000, message: 'Description cannot exceed 1000 characters' }
                        }}
                        render={({ field, fieldState: { error } }) => (
                          <>
                            <Input
                              {...field}
                              type="textarea"
                              id="description"
                              placeholder="Enter Description"
                              invalid={error ? true : false}
                              className={error ? 'error-input' : ''}
                            />

                            <Row className="justify-content-between mt-1">
                              <Col>
                                {error ? (
                                  <span className="text-danger error-message">{error.message}</span>
                                ) : (
                                  <span className="text-muted">Include condition, features and reason for selling</span>
                                )}
                              </Col>
                              <Col>
                                <span className="text-muted float-end">{field.value.length}/3000</span>
                              </Col>
                            </Row>
                          </>
                        )}
                      />
                    </FormGroup>
                  </Col>
                  <Col xs={12}>
                    <FormGroup className="post-ad-form__input-container deal-term-container">
                      <Label
                        for="Description"
                        className="mandatory-label">
                        Deal Terms
                      </Label>
                      <Controller
                        defaultValue=""
                        name="dealTerms"
                        control={control}
                        rules={{
                          required: 'Deal Terms is required',
                          maxLength: { value: 1000, message: 'Deal Terms cannot exceed 1000 characters' }
                        }}
                        render={({ field, fieldState: { error } }) => (
                          <>
                            <Input
                              {...field}
                              type="textarea"
                              id="dealTerms"
                              placeholder="Enter Deal Terms"
                              invalid={error ? true : false}
                              className={error ? 'error-input' : ''}
                            />
                            <Row className="justify-content-between mt-1">
                              <Col>{error && <span className="text-danger error-message">{error.message}</span>}</Col>
                              <Col>
                                <span className="text-muted float-end">{field.value.length}/3000</span>
                              </Col>
                            </Row>
                          </>
                        )}
                      />
                    </FormGroup>
                  </Col>
                </Row>
              </ListGroupItem>
              <ListGroupItem>
                <Row>
                  <Col xs={12}>
                    <PhotoUpload
                      control={control}
                      errors={errors}
                      imgFiles={files}
                      setImgFiles={setFiles}
                      images={images}
                      setImages={setImages}
                      type="history-clone"
                    />
                  </Col>
                </Row>
              </ListGroupItem>
            </ListGroup>
            <CardBody className="text-end">
              <Button
                type="button"
                className="primary-btn ms-2"
                onClick={saveAsDraftAdHandler}>
                Save as Draft
              </Button>
              <Button
                type="button"
                color="success ms-2"
                onClick={handleSubmit(postAdHandler)}>
                Post
              </Button>
            </CardBody>
          </Card>
        </ModalBody>
      </Modal>

      <Modal
        centered={true}
        isOpen={deleteModal}
        toggle={toggleDeleteModal}
        className="flex justify-center items-center">
        <ModalHeader toggle={toggleDeleteModal}>Discard Ad</ModalHeader>
        <ModalBody>Are you sure you want to delete this ad? This action cannot be undone.</ModalBody>
        <ModalFooter>
          <Button
            color="danger"
            onClick={() => {
              deleteAdHandler()
            }}>
            Confirm
          </Button>
          <Button
            color="secondary"
            onClick={toggleDeleteModal}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>
    </div>
  )
}

export default DraftTable
