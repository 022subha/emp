import { toast } from 'react-toastify'
import { hideLoading, showLoading } from '../../store/slices/uiSlice'
import { paymentEndPoints } from '../api'
import { apiConnector } from '../apiConnector'

const { validateDiscount, makePayemnt: makePayemntAPI } = paymentEndPoints

export const validateDiscountCode = (discountCode) => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('POST', validateDiscount, { discountCode })
      dispatch(hideLoading())

      return response.data.data.discount
    } catch (error) {
      dispatch(hideLoading())
      console.log(error)
    }

    return null
  }
}

export const makePayment = (amount, subscriptionId, planDuration, otpVerificationToken) => {
  return async (dispatch) => {
    try {
      dispatch(showLoading())
      const response = await apiConnector('POST', makePayemntAPI, { amount, subscriptionId, planDuration, otpVerificationToken })
      toast.success(response.data.message)
      dispatch(hideLoading())

      return response.data.data
    } catch (error) {
      dispatch(hideLoading())
      toast.error(error.response.data.message)
      console.log(error)
    }

    return { mjPROLoginCodelist: [], jwtToken: null }
  }
}
