import './BuyPlan.scss'
import React from 'react'
import { useSelector } from 'react-redux'
import { Container, Row, Col } from 'reactstrap'
import Spinner from '../../components/common/spinner/Spinner'
import PaymentContact from '../../components/core/BuyPlan/PaymentContact'
import PlanCardSelected from '../../components/core/BuyPlan/PlanCardSelected'

const BuyPlan = () => {
  const isLoading = useSelector((state) => state.ui.isLoading)

  return (
    <>
      {isLoading && <Spinner />}
      <div className="buy-plan__container">
        <Container fluid>
          <Row className="pt-4 g-1">
            <Col
              xs={12}
              md={7}>
              <PlanCardSelected />
            </Col>
            <Col
              xs={12}
              md={5}>
              <Row>
                <Col>
                  <PaymentContact />
                </Col>
              </Row>
            </Col>
          </Row>
        </Container>
      </div>
    </>
  )
}

export default BuyPlan
