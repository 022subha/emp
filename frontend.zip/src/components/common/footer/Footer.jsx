import React from 'react'
import './FooterStyle.scss'
import Youtube from '../../../assets/images/icons/youtube.svg'
import Twitter from '../../../assets/images/icons/twitter.svg'
import LinkedIn from '../../../assets/images/icons/linkedin.svg'
import Facebook from '../../../assets/images/icons/facebook.svg'
import { Container, Row, Col, ListGroup, ListGroupItem } from 'reactstrap'

export default function Footer() {
  return (
    <footer className="footer__container">
      <Container fluid>
        <Row className="d-flex justify-content-evenly align-items-center">
          <Col
            xs="auto"
            className="p-0">
            <ListGroup horizontal>
              <ListGroupItem className="border-0">mjPRO is a Saas Product from mjunction services limited</ListGroupItem>
            </ListGroup>
          </Col>

          <Col
            xs="auto"
            className="p-0">
            <ListGroup
              horizontal
              className="footer__links">
              <ListGroupItem
                tag="a"
                target="_blank"
                href="/disclaimer"
                className="footer__link">
                Disclaimer
              </ListGroupItem>
              <ListGroupItem
                tag="a"
                target="_blank"
                href="/privacy-policy"
                className="footer__link border-left">
                Privacy Policy
              </ListGroupItem>
            </ListGroup>
          </Col>

          <Col
            xs="auto"
            className="p-0">
            <ListGroup
              horizontal
              className="footer__social">
              <ListGroupItem
                tag="a"
                target="_blank"
                href="https://in.linkedin.com/company/hellomjunction"
                className="footer__link">
                <img
                  src={LinkedIn}
                  alt="LinkedIn"
                  className="social-icon"
                />
              </ListGroupItem>
              <ListGroupItem
                tag="a"
                target="_blank"
                href="https://twitter.com/hellomjunction"
                className="footer__link">
                <img
                  src={Twitter}
                  alt="Twitter"
                  className="social-icon"
                />
              </ListGroupItem>
              <ListGroupItem
                tag="a"
                target="_blank"
                href="https://www.facebook.com/hellomjunction"
                className="footer__link">
                <img
                  src={Facebook}
                  alt="Facebook"
                  className="social-icon"
                />
              </ListGroupItem>
              <ListGroupItem
                tag="a"
                target="_blank"
                href="https://www.youtube.com/c/hellomjunction"
                className="footer__link">
                <img
                  src={Youtube}
                  alt="YouTube"
                  className="social-icon"
                />
              </ListGroupItem>
            </ListGroup>
          </Col>

          <Col
            xs="auto"
            className="p-0">
            <ListGroup horizontal>
              <ListGroupItem className="border-0">mjunction services limited 2024</ListGroupItem>
              <ListGroupItem className="border-start border-2 border-end-0 border-top-0 border-bottom-0">All rights reserved</ListGroupItem>
            </ListGroup>
          </Col>
        </Row>
      </Container>
    </footer>
  )
}
