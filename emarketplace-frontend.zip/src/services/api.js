import { BASE_URL } from '../../dotenv'

export const ssoEndPoints = {
  getSSOData: BASE_URL + '/sso/sso-data'
}

export const authEndPoints = {
  login: BASE_URL + '/auth/login',
  sendOtp: BASE_URL + '/auth/send-otp',
  verifyOtp: BASE_URL + '/auth/verify-otp',
  me: BASE_URL + '/auth/me',
  adSlotsRemaining: BASE_URL + '/auth/ad-slots-remaining',
  changeLoginCode: BASE_URL + '/auth/change-login-code',
  logout: BASE_URL + '/auth/logout'
}

export const masterEndPoints = {
  country: BASE_URL + '/master/countries',
  state: BASE_URL + '/master/states',
  city: BASE_URL + '/master/cities',
  uom: BASE_URL + '/master/uoms',
  hsn: BASE_URL + '/master/hsn-categories',
  adCategories: BASE_URL + '/master/ad-categories',
  bussinessScales: BASE_URL + '/master/bussiness-scales',
  natureOfBussiness: BASE_URL + '/master/nature-of-bussiness',
  subscriptionPlans: BASE_URL + '/master/subscriptions'
}

export const verificationEndPoints = {
  pan: BASE_URL + '/supplier/verify-pan',
  gstin: BASE_URL + '/supplier/verify-gstins',
  msme: BASE_URL + '/supplier/verify-msme'
}

export const supplierEndPoints = {
  saveOrgInfoAsDraft: BASE_URL + '/supplier/save-org-info-as-draft',
  saveOpInfoAsDraft: BASE_URL + '/supplier/save-op-info-as-draft',
  saveItemInfoAsDraft: BASE_URL + '/supplier/save-item-info-as-draft',
  supplierProfileInfo: BASE_URL + '/supplier/get-supplier-profile',
  sendOtpToContactPerson: BASE_URL + '/supplier/send-otp-to-contact-person',
  verifyOtpOfContactPerson: BASE_URL + '/supplier/verify-otp-of-contact-person',
  fetchOrgInfoBeforePublishing: BASE_URL + '/supplier/fetch-org-info-before-publishing',
  fetchOpInfoBeforePublishing: BASE_URL + '/supplier/fetch-op-info-before-publishing',
  fetchItemInfoBeforePublishing: BASE_URL + '/supplier/fetch-item-info-before-publishing',
  publishProfile: BASE_URL + '/supplier/publish-profile'
}

export const adEndPoints = {
  postAd: BASE_URL + '/ad/create-ad',
  saveAdAsDraft: BASE_URL + '/ad/create-draft-ad',
  fetchAdDetail: BASE_URL + '/ad/get-ad-detail',
  myAds: BASE_URL + '/ad/my-ads',
  myLiveAds: BASE_URL + '/ad/my-live-ads',
  adHistory: BASE_URL + '/ad/my-ad-history',
  myDraftAds: BASE_URL + '/ad/my-draft-ads',
  deleteAd: BASE_URL + '/ad/delete-ad',
  modifyAdAsDraft: BASE_URL + '/ad/update-draft-ad',
  postDraftAd: BASE_URL + '/ad/post-draft-ad',
  categoryWiseAdCount: BASE_URL + '/ad/category-wise-ad-count'
}

export const paymentEndPoints = {
  validateDiscount: BASE_URL + '/payment/validate-discount-code',
  makePayemnt: BASE_URL + '/payment/make-payment'
}
