import React from 'react'
import { Table } from 'reactstrap'

export default function ItemCategoryTable({ categoryInformation }) {
  return (
    <div>
      <Table
        bordered
        responsive
        rounded>
        <thead>
          <tr>
            <th>Item Category</th>
            <th>Value of order supplied</th>
            <th>Currency</th>
            <th>Capacity</th>
            <th>UOM</th>
            <th>Top Buyers</th>
          </tr>
        </thead>
        <tbody>
          {categoryInformation?.map((element, index) => (
            <tr key={index}>
              <td scope="row">{element?.materialCategoryHSN?.hsnDescription || 'Not Available'}</td>
              <td>{element.valueOfOrderSupplied || 'Not Available'}</td>
              <td>{element.currency || 'Not Available'}</td>
              <td>{element.capacity || 'Not Available'}</td>
              <td>{element?.materialCategoryUOM?.name || 'Not Available'}</td>
              <td>
                {element?.topBuyers?.length > 0 ? (
                  <ul className="list-inline">
                    {JSON.parse(element.topBuyers)?.map((element, index) => {
                      return (
                        <>
                          <li className="list-inline-item">{element}</li>
                        </>
                      )
                    })}
                  </ul>
                ) : (
                  'Not Available'
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  )
}
