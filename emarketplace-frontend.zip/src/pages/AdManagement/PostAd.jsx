import {
  Row,
  Col,
  Card,
  Label,
  Input,
  Modal,
  Badge,
  Button,
  CardBody,
  CardText,
  Carousel,
  ListGroup,
  CardTitle,
  ModalBody,
  ModalHeader,
  CarouselItem,
  ListGroupItem,
  CarouselControl,
  CarouselIndicators
} from 'reactstrap'
import './PostAdStyles.scss'
import Select from 'react-select'
import React, { useState } from 'react'
import PhotoUpload from './AdPhotoUpload'
import DatePicker from 'react-datepicker'
import 'react-datepicker/dist/react-datepicker.css'
import { Controller, useForm } from 'react-hook-form'
import { useDispatch, useSelector } from 'react-redux'
import { postAd } from '../../services/controller/adAPI'
import ImgPng from '../../assets/images/icons/image.webp'
import { saveAdAsDraft } from '../../services/controller/adAPI'

export default function PostAd({ toggle }) {
  const dispatch = useDispatch()

  const adCategories = useSelector((state) => state.master.adCategories)

  const [modal, setModal] = useState(false)
  const [files, setFiles] = useState(Array(10).fill(null))
  const [images, setImages] = useState(Array(10).fill(null))

  const [activeIndex, setActiveIndex] = useState(0)
  const [animating, setAnimating] = useState(false)

  const next = () => {
    if (animating) return
    const nextIndex = activeIndex === images.filter(Boolean).length - 1 ? 0 : activeIndex + 1
    setActiveIndex(nextIndex)
  }

  const previous = () => {
    if (animating) return
    const nextIndex = activeIndex === 0 ? images.filter(Boolean).length - 1 : activeIndex - 1
    setActiveIndex(nextIndex)
  }

  const goToIndex = (newIndex) => {
    if (animating) return
    setActiveIndex(newIndex)
  }

  const {
    watch,
    reset,
    control,
    getValues,
    handleSubmit,
    formState: { errors }
  } = useForm()

  const postAdHandler = (data) => {
    const isNotEmpty = (value) => value && value !== ''
    const parseNumber = (value) => (isNotEmpty(value) ? parseInt(value) : null)

    const payload = {
      categoryId: parseNumber(data.categoryId),
      title: isNotEmpty(data.title) ? data.title : null,
      description: isNotEmpty(data.description) ? data.description : null,
      dealTerms: isNotEmpty(data.dealTerms) ? data.dealTerms : null,
      offerStartDate: data.startDate ? new Date(data.startDate.getTime() + 86400000).toISOString().split('T')[0] : null,
      offerEndDate: data.endDate ? new Date(data.endDate.getTime() + 86400000).toISOString().split('T')[0] : null
    }

    const adFormData = new FormData()
    adFormData.append('data', JSON.stringify(payload))

    files.forEach((banner, index) => {
      if (banner) adFormData.append(`banners${index + 1}`, banner)
    })

    dispatch(postAd(adFormData)).then((success) => {
      if (success) {
        reset()
        setFiles(Array(10).fill(null))
        setImages(Array(10).fill(null))
        toggle('4')
      }
    })
  }

  const saveAdAsDraftHandler = () => {
    const data = getValues()

    const isNotEmpty = (value) => value && value !== ''
    const parseNumber = (value) => (isNotEmpty(value) ? parseInt(value) : null)

    const payload = {
      categoryId: parseNumber(data.categoryId),
      title: isNotEmpty(data.title) ? data.title : null,
      description: isNotEmpty(data.description) ? data.description : null,
      dealTerms: isNotEmpty(data.dealTerms) ? data.dealTerms : null,
      offerStartDate: data.startDate ? new Date(data.startDate.getTime() + 86400000).toISOString().split('T')[0] : null,
      offerEndDate: data.endDate ? new Date(data.endDate.getTime() + 86400000).toISOString().split('T')[0] : null
    }

    const adFormData = new FormData()
    adFormData.append('data', JSON.stringify(payload))

    files.forEach((banner, index) => {
      if (banner) adFormData.append(`banners${index + 1}`, banner)
    })

    dispatch(saveAdAsDraft(adFormData)).then((success) => {
      if (success) {
        reset()
        setFiles(Array(10).fill(null))
        setImages(Array(10).fill(null))
        toggle('3')
      }
    })
  }

  const toggleAdPreview = () => setModal(!modal)

  return (
    <div>
      <Card className="postAdWrapper">
        <ListGroup
          className="PostAdList"
          flush>
          <ListGroupItem style={{ border: 'none' }}>
            <Row>
              <Col
                xs={12}
                md={3}>
                <div className="post-ad-form__input-container">
                  <Label
                    for="Ad Category"
                    className="mandatory-label mb-0"
                    style={{ fontSize: '15px', fontWeight: '700' }}>
                    Category
                  </Label>
                  <Controller
                    defaultValue=""
                    name="categoryId"
                    control={control}
                    rules={{
                      required: 'Category is required'
                    }}
                    render={({ field, fieldState: { error } }) => (
                      <>
                        {/* <Select
                          // className="basic-single"
                          {...field}
                          classNamePrefix="select"
                          defaultValue=""
                          isClearable={true}
                          isSearchable={true}
                          name="color"
                          options={(adCategories || []).map((item) => ({
                            value: item.id,
                            label: `${item.hsnCode.toString().padStart(4, '0')}-${item.hsnDescription}`
                          }))}
                        /> */}
                        <Input
                          {...field}
                          type="select"
                          id="categoryId"
                          invalid={error ? true : false}
                          className={error ? 'error-input' : ''}>
                          <option value="">Select Ad Catgeory</option>
                          {(adCategories || []).map((item) => (
                            <option
                              key={item.id}
                              value={item.id}>
                              {item.hsnCode.toString().padStart(4, '0')}-{item.hsnDescription}
                            </option>
                          ))}
                        </Input>
                        {error && <span className="text-danger error-message">{error.message}</span>}
                      </>
                    )}
                  />
                </div>
              </Col>
              <Col
                xs={12}
                md={6}>
                <div className="post-ad-form__input-container">
                  <Label
                    for="Ad Title"
                    className="mandatory-label mb-0"
                    style={{ fontSize: '15px', fontWeight: '700' }}>
                    Title
                  </Label>

                  <Controller
                    defaultValue=""
                    name="title"
                    control={control}
                    rules={{
                      required: 'Title is required',
                      maxLength: { value: 1000, message: 'Title cannot exceed 1000 characters' }
                    }}
                    render={({ field, fieldState: { error } }) => (
                      <>
                        <Input
                          {...field}
                          type="text"
                          id="title"
                          placeholder="Mention key features of your item"
                          invalid={error ? true : false}
                          className={error ? 'error-input' : ''}
                        />
                        {error && <span className="text-danger error-message">{error.message}</span>}
                      </>
                    )}
                  />
                </div>
              </Col>
              <Col
                xs={12}
                md={3}
                className="post-ad-form__input-container">
                <Label
                  for="Ad Title"
                  className="mandatory-label mb-0"
                  style={{ fontSize: '15px', fontWeight: '700' }}>
                  Offer Start & End Date
                </Label>
                <div className="d-flex align-items-center justify-content-center rounded bg-white pe-2">
                  <Controller
                    name="startDate"
                    control={control}
                    rules={{
                      required: 'Start date is required'
                    }}
                    defaultValue={null}
                    render={({ field, fieldState: { error } }) => (
                      <>
                        <DatePicker
                          {...field}
                          selected={field.value}
                          placeholderText="Start date"
                          className={`form-control border-0 ${error ? 'error-input' : ''}`}
                          dateFormat="dd/MM/yyyy"
                          minDate={new Date()}
                          maxDate={watch('endDate') ? new Date(new Date(watch('endDate')).getTime() - 86400000) : null}
                          onChange={(e) => field.onChange(e)}
                        />
                      </>
                    )}
                  />
                  <span className="mx-2">&#8594;</span>
                  <Controller
                    name="endDate"
                    control={control}
                    rules={{
                      required: 'End date is required'
                    }}
                    defaultValue={null}
                    render={({ field, fieldState: { error } }) => (
                      <>
                        <DatePicker
                          {...field}
                          selected={field.value}
                          placeholderText="End date"
                          className={`form-control border-0 ${error ? 'error-input' : ''}`}
                          dateFormat="dd/MM/yyyy"
                          minDate={
                            watch('startDate')
                              ? new Date(new Date(watch('startDate')).getTime() + 86400000)
                              : new Date(new Date().getTime() + 86400000)
                          }
                          onChange={(e) => field.onChange(e)}
                        />
                      </>
                    )}
                  />

                  <i
                    className="bi bi-calendar ms-2"
                    style={{ fontSize: '20px' }}></i>
                </div>
                {errors.startDate && errors.endDate ? (
                  <span className="text-danger error-message">Start & End Date is required</span>
                ) : errors.startDate ? (
                  <span className="text-danger error-message">Start Date is required</span>
                ) : (
                  errors.endDate && <span className="text-danger error-message">End Date is required</span>
                )}
              </Col>
            </Row>
          </ListGroupItem>
          <ListGroupItem style={{ border: 'none' }}>
            <Row>
              <Col xs={12}>
                <div className="post-ad-form__input-container description-container">
                  <Label
                    for="Description"
                    className="mandatory-label mb-0"
                    style={{ fontSize: '15px', fontWeight: '700' }}>
                    Product Description
                  </Label>
                  <Controller
                    defaultValue=""
                    name="description"
                    control={control}
                    rules={{
                      required: 'Product Description is required',
                      maxLength: { value: 3000, message: 'Product Description cannot exceed 3000 characters' }
                    }}
                    render={({ field, fieldState: { error } }) => (
                      <>
                        <Input
                          {...field}
                          type="textarea"
                          id="description"
                          placeholder="Include features"
                          invalid={error ? true : false}
                          className={error ? 'error-input' : ''}
                        />

                        <Row className="justify-content-between mt-0">
                          <Col>{error && <span className="text-danger error-message">{error.message}</span>}</Col>
                          <Col>
                            <span
                              className="text-muted float-end"
                              style={{ fontSize: '12px' }}>
                              {field.value.length}/3000
                            </span>
                          </Col>
                        </Row>
                      </>
                    )}
                  />
                </div>
              </Col>
              <Col xs={12}>
                <div className="post-ad-form__input-container deal-term-container">
                  <Label
                    for="Description"
                    className="mandatory-label mb-0"
                    style={{ fontSize: '15px', fontWeight: '700' }}>
                    Description about Advertisement
                  </Label>
                  <Controller
                    defaultValue=""
                    name="dealTerms"
                    control={control}
                    rules={{
                      required: 'Description about Advertisement is required',
                      maxLength: { value: 3000, message: 'Description about Advertisement cannot exceed 3000 characters' }
                    }}
                    render={({ field, fieldState: { error } }) => (
                      <>
                        <Input
                          {...field}
                          type="textarea"
                          id="dealTerms"
                          placeholder="Enter Description about Advertisement"
                          invalid={error ? true : false}
                          className={error ? 'error-input' : ''}
                        />
                        <Row className="justify-content-between mt-0">
                          <Col>{error && <span className="text-danger error-message">{error.message}</span>}</Col>
                          <Col>
                            <span
                              className="text-muted float-end"
                              style={{ fontSize: '12px' }}>
                              {field.value.length}/3000
                            </span>
                          </Col>
                        </Row>
                      </>
                    )}
                  />
                </div>
              </Col>
            </Row>
          </ListGroupItem>
          <ListGroupItem>
            <Row>
              <Col xs={12}>
                <div className="post-ad-form__input-container deal-term-container">
                  <Label
                    for="Description"
                    className="mandatory-label mb-0"
                    style={{ fontSize: '15px', fontWeight: '700' }}>
                    Advertisement Photo <span style={{ fontSize: '12px', fontWeight: '200' }}> (JPEG and PNG formats allowed, maximum size 5MB)</span>
                  </Label>

                  <PhotoUpload
                    control={control}
                    errors={errors}
                    imgFiles={files}
                    setImgFiles={setFiles}
                    images={images}
                    setImages={setImages}
                    type="ad"
                  />
                </div>
              </Col>
            </Row>
          </ListGroupItem>
        </ListGroup>
        <div className="px-4 d-flex justify-content-end align-items-center">
          <Button
            type="button"
            className="ms-2 primary-btn"
            onClick={toggleAdPreview}>
            Preview
          </Button>
          <Button
            type="button"
            className="primary-btn ms-2"
            onClick={saveAdAsDraftHandler}>
            Save as Draft
          </Button>

          <Button
            type="button"
            color="success ms-2"
            onClick={handleSubmit(postAdHandler)}>
            Post
          </Button>
        </div>
      </Card>

      <Modal
        isOpen={modal}
        toggle={toggleAdPreview}
        centered={true}
        size="xl">
        <ModalHeader
          className="post__ad-modal-header"
          toggle={toggleAdPreview}>
          AD Preview
        </ModalHeader>
        <ModalBody className="post__ad-modal-body">
          <Card className="post__ad-modal-wrapper">
            {images.filter(Boolean).length > 0 ? (
              <Carousel
                slide={true}
                dark={true}
                next={next}
                previous={previous}
                activeIndex={activeIndex}>
                <CarouselIndicators
                  items={images.filter(Boolean)}
                  activeIndex={activeIndex}
                  onClickHandler={goToIndex}
                />
                {images.filter(Boolean).map((item) => {
                  return (
                    <CarouselItem
                      onExiting={() => setAnimating(true)}
                      onExited={() => setAnimating(false)}
                      key={item}>
                      <img src={item} />
                    </CarouselItem>
                  )
                })}
                <CarouselControl
                  direction="prev"
                  directionText="Previous"
                  onClickHandler={previous}
                />
                <CarouselControl
                  direction="next"
                  directionText="Next"
                  onClickHandler={next}
                />
              </Carousel>
            ) : (
              <img
                src={ImgPng}
                style={{ objectFit: 'contain' }}
              />
            )}

            <CardBody>
              <CardTitle
                className="row"
                tag="h5">
                <Col className="flex-grow-1 post__ad-modal-title">
                  <span id="tooltip1">{watch('title') || 'Not Available'}</span>
                </Col>
              </CardTitle>
            </CardBody>
            <ListGroup
              className="PostAdList"
              flush>
              <ListGroupItem>
                <CardText>
                  <span className="fw-bold">Category:</span>{' '}
                  <span>{adCategories.find((item) => item.id == watch('categoryId'))?.hsnDescription || 'Not Available'}</span>
                  <span className="fw-bold ms-4">Offer Start & End Date:</span>{' '}
                  <span>
                    {watch('startDate')?.toLocaleDateString('en-GB') || 'Not Available'} -{' '}
                    {watch('endDate')?.toLocaleDateString('en-GB') || 'Not Available'}
                  </span>
                </CardText>
              </ListGroupItem>

              <ListGroupItem>
                <CardText>
                  <span className="fw-bold">Description:</span> <span>{watch('description') || 'Not Available'}</span>
                </CardText>
              </ListGroupItem>
              <ListGroupItem>
                <CardText>
                  <span className="fw-bold">Deal Terms:</span> <span>{watch('dealTerms') || 'Not Available'}</span>
                </CardText>
              </ListGroupItem>
            </ListGroup>
          </Card>
        </ModalBody>
      </Modal>
    </div>
  )
}
