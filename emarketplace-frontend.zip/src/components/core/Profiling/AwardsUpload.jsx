import React from 'react'
import { toast } from 'react-toastify'
import './ProfilingComponentStyles.scss'
import { ImAttachment } from 'react-icons/im'
import { FaTimes, FaRedo, FaCheck, FaUpload } from 'react-icons/fa'
import { Button, Progress, ListGroup, ListGroupItem, Row, Col, Card } from 'reactstrap'

const AwardUpload = ({ files, setFiles }) => {
  const MAX_FILES = 10
  const MAX_FILE_SIZE = 2 * 1024 * 1024

  const handleFileSelect = (event) => {
    const selectedFiles = Array.from(event.target.files)
      .filter((file) => {
        if (file.size > MAX_FILE_SIZE) {
          toast.error(`File "${file.name}" exceeds the 2MB size limit.`)
          return false
        }
        return true
      })
      .map((file) => ({
        file,
        name: file.name,
        size: file.size,
        status: 'uploading',
        progress: 0
      }))

    if (files.length + selectedFiles.length > MAX_FILES) {
      toast.error(`Maximum ${MAX_FILES} files can be uploaded.`)
      return
    }

    setFiles((prevFiles) => [...prevFiles, ...selectedFiles])
    uploadFiles(selectedFiles)
  }

  const uploadFiles = (fileList) => {
    fileList.forEach((fileObj) => {
      const interval = setInterval(() => {
        setFiles((prevFiles) =>
          prevFiles.map((f) => {
            if (f.name === fileObj.name) {
              const newProgress = f.progress + 10
              if (newProgress >= 100) clearInterval(interval)
              return {
                ...f,
                progress: newProgress,
                status: newProgress >= 100 ? 'success' : 'uploading'
              }
            }
            return f
          })
        )
      }, 500)
    })
  }

  const handleRemoveFile = (fileName) => {
    setFiles((prevFiles) => prevFiles.filter((file) => file.name !== fileName))
  }

  const handleRemoveAll = () => {
    setFiles([])
  }

  const handleRetry = (fileName) => {
    setFiles((prevFiles) => prevFiles.map((file) => (file.name === fileName ? { ...file, progress: 0, status: 'uploading' } : file)))
    const fileToRetry = files.find((file) => file.name === fileName)
    if (fileToRetry) uploadFiles([fileToRetry])
  }

  return (
    <div>
      <Card className="awardCard_header">
        <Row>
          <Col>
            <Button
              color="brand-color"
              tag="label"
              disabled={files.length >= MAX_FILES}>
              <ImAttachment className="me-2" />
              {files.length >= MAX_FILES ? 'Max Limit Reached' : 'Select Files'}
              <input
                type="file"
                multiple
                hidden
                accept="application/pdf, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                onChange={handleFileSelect}
              />
            </Button>
          </Col>
          <Col className="text-end">
            <Button
              color="danger"
              onClick={handleRemoveAll}
              disabled={files.length === 0}>
              Remove All
            </Button>
          </Col>
        </Row>
      </Card>

      <Card
        body
        className="awardCard_body">
        <ListGroup>
          {files.map((file) => (
            <ListGroupItem
              key={file.name}
              className="d-flex align-items-center awardFile_list">
              <div className="me-auto">
                <FaUpload className="me-2" />
                {file.name}
                <div>
                  <small>
                    {(file.size / 1024).toFixed(2)} KB - {file.status === 'success' && <span className="text-success">Uploaded</span>}
                    {file.status === 'failed' && <span className="text-danger">Failed to upload</span>}
                    {file.status === 'uploading' && 'Uploading...'}
                  </small>
                </div>
              </div>
              {file.status === 'uploading' && (
                <>
                  <Progress
                    value={file.progress}
                    className="me-2"
                    style={{ width: '150px' }}
                  />
                  <Button
                    size="sm"
                    color="danger"
                    onClick={() => handleRemoveFile(file.name)}>
                    <FaTimes />
                  </Button>
                </>
              )}
              {file.status === 'failed' && (
                <Button
                  size="sm"
                  color="warning"
                  onClick={() => handleRetry(file.name)}>
                  <FaRedo />
                </Button>
              )}
              {file.status === 'success' && <FaCheck className="text-success" />}
            </ListGroupItem>
          ))}
        </ListGroup>
      </Card>
    </div>
  )
}

export default AwardUpload
