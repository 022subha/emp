import './PhoneInputStyles.scss'
import { CiSearch } from 'react-icons/ci'
import { useSelector } from 'react-redux'
import { Controller } from 'react-hook-form'
import React, { useEffect, useRef, useState } from 'react'
import { IoIosArrowDown, IoIosArrowUp } from 'react-icons/io'
import { WHATSAPP_NUMBER_REGEX } from '../../../utils/regexHelper'
import { Button, Input } from 'reactstrap'

const PhoneInput = ({ watch, name, control, setValue, errors, disabled = false }) => {
  const dropdownRef = useRef(null)
  const countries = useSelector((state) => state.master.countryList)

  const [selectedCountry, setSelectedCountry] = useState(101)
  const [isDropdownOpen, setIsDropdownOpen] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [filteredCountries, setFilteredCountries] = useState(countries)
  const selectedPhoneCode = countries.find((item) => item.id === selectedCountry)?.phoneCode || ''

  const handleCountrySelect = (countryId) => {
    setSelectedCountry(countryId)
    const newPhoneCode = countries.find((item) => item.id === countryId)?.phoneCode || ''
    setValue('phoneCode', `+${newPhoneCode}`)
    setIsDropdownOpen(false)
    setSearchTerm('')
    setFilteredCountries(countries)
  }

  const toggleDropdown = () => {
    if (!disabled) setIsDropdownOpen(!isDropdownOpen)
  }

  const handleSearchChange = (e) => {
    const term = e.target.value
    setSearchTerm(term)

    if (term.trim() === '') {
      setFilteredCountries(countries)
    } else {
      const filtered = countries.filter(
        (country) => country.countryName.toLowerCase().includes(term.toLowerCase()) || country.phoneCode.toString().startsWith(term.replace('+', ''))
      )
      setFilteredCountries(filtered)
    }
  }

  const closeDropdownOnOutsideClick = (e) => {
    if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
      setIsDropdownOpen(false)
    }
  }

  useEffect(() => {
    document.addEventListener('click', closeDropdownOnOutsideClick)
    return () => document.removeEventListener('click', closeDropdownOnOutsideClick)
  }, [])

  return (
    <div
      className="pn-input"
      ref={dropdownRef}>
      <div className="pn-input__container">
        <Button
          style={{ background: 'transparent', border: 'none' }}
          color="white"
          disabled={disabled}
          className="pn-input__selected-value"
          onClick={toggleDropdown}>
          <img
            className="pn-selected-prefix__flag"
            src={`https://flagpedia.net/data/flags/icon/20x15/${countries.find((item) => item.id === selectedCountry)?.iso2.toLowerCase()}.png`}
            alt="flag"
          />
          <Controller
            name="phoneCode"
            control={control}
            defaultValue={`+${selectedPhoneCode}`}
            render={({ field }) => <span {...field}>{field.value}</span>}
          />
          {isDropdownOpen ? <IoIosArrowUp onClick={toggleDropdown} /> : <IoIosArrowDown onClick={toggleDropdown} />}
        </Button>
        <Controller
          name={name}
          control={control}
          defaultValue=""
          rules={{
            required: 'Whatsapp number is required',
            validate: (value) => {
              const fullPhoneNumber = `+${selectedPhoneCode}${value}`
              return WHATSAPP_NUMBER_REGEX.test(fullPhoneNumber) ? true : 'Invalid Whatsapp Number'
            }
          }}
          render={({ field }) => (
            <Input
              {...field}
              type="tel"
              invalid={errors[name] ? true : false}
              className={errors[name] ? 'contact-form__input error-input' : ''}
              placeholder="Mobile Number"
              disabled={disabled}
            />
          )}
        />
      </div>
      {isDropdownOpen && (
        <div className="pn-input__options">
          <div className="pn-country-search">
            <input
              type="text"
              placeholder="Search Country Name"
              value={searchTerm}
              onChange={handleSearchChange}
            />
            <CiSearch className="search-icon" />
          </div>
          <ul>
            {filteredCountries.length > 0 ? (
              filteredCountries.map((country) => (
                <li
                  key={country.id}
                  onClick={() => handleCountrySelect(country.id)}>
                  <img
                    className="pn-selected-prefix__flag"
                    src={`https://flagpedia.net/data/flags/icon/20x15/${country.iso2.toLowerCase()}.png`}
                    alt={country.countryName}
                  />
                  <span>{country.countryName}</span>
                  <span>+{country.phoneCode}</span>
                </li>
              ))
            ) : (
              <li className="">No results found</li>
            )}
          </ul>
        </div>
      )}
    </div>
  )
}

export default PhoneInput
