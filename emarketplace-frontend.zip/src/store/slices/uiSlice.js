import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  isLoading: false,
  loaderCount: 0
}

export const uiSlice = createSlice({
  name: 'ui',
  initialState,
  reducers: {
    showLoading: (state) => {
      state.isLoading = true
      state.loaderCount++
    },

    hideLoading: (state) => {
      if (state.loaderCount > 0) state.loaderCount--
      if (state.loaderCount === 0) state.isLoading = false
    }
  }
})

export const { showLoading, hideLoading } = uiSlice.actions

export default uiSlice.reducer
