import React, { useEffect, useState, useCallback } from 'react'
import { Nav, NavItem, NavLink, TabContent, TabPane } from 'reactstrap'
import { useDispatch } from 'react-redux'
import AdManage from './AdManage'
import PostAd from './PostAd'
import DraftAd from './DraftAd'
import LiveAds from './LiveAds'
import AdHistory from './AdHistory'
import classnames from 'classnames'
import { fetchAdHistory, fetchMyAds, fetchMyDraftAdList, fetchMyLiveAds, getCategoryWiseAdCount } from '../../services/controller/adAPI'
import './AdManagementComponentsStyle.scss'
import { getAdSlotsRemaining } from '../../services/controller/authAPI'

const CreateAD = () => {
  const [activeTab, setActiveTab] = useState('1')
  const [adsCount, setAdsCount] = useState({
    liveAd: 0,
    draftAd: 0,
    adHistory: 0
  })
  const [adList, setAdList] = useState([])
  const [liveAds, setLiveAds] = useState([])
  const [draftAdList, setDraftAdList] = useState([])
  const [adHistory, setAdHistory] = useState([])

  const dispatch = useDispatch()

  const toggle = (tab) => {
    if (activeTab !== tab) setActiveTab(tab)
  }

  const fetchAdsData = useCallback(async () => {
    try {
      dispatch(getAdSlotsRemaining())
      dispatch(getCategoryWiseAdCount()).then((countData) => setAdsCount(countData))

      if (activeTab === '1') {
        dispatch(fetchMyAds()).then((adsData) => setAdList(adsData || []))
      } else if (activeTab === '3') {
        dispatch(fetchMyDraftAdList()).then((draftData) => setDraftAdList(draftData || []))
      } else if (activeTab === '4') {
        dispatch(fetchMyLiveAds()).then((liveData) => setLiveAds(liveData || []))
      } else if (activeTab === '5') {
        dispatch(fetchAdHistory()).then((historyData) => setAdHistory(historyData))
      }
    } catch (error) {
      console.error('Error fetching ads data:', error)
    }
  }, [activeTab, dispatch])

  useEffect(() => {
    fetchAdsData()
  }, [fetchAdsData])

  const tabItems = [
    { id: '1', label: 'AD Management' },
    { id: '2', label: 'Post New AD' },
    { id: '3', label: 'Draft ADs', count: adsCount.draftAd },
    { id: '4', label: 'Live ADs', count: adsCount.liveAd },
    { id: '5', label: 'AD History', count: adsCount.adHistory }
  ]

  return (
    <div>
      <Nav
        justified
        pills
        className="customNav_CreateAD">
        {tabItems.map((tab) => (
          <NavItem key={tab.id}>
            <NavLink
              className={classnames({ active: activeTab === tab.id })}
              onClick={() => toggle(tab.id)}
              style={{
                color: activeTab === tab.id ? 'white' : '#000',
                backgroundColor: activeTab === tab.id ? '#00AEEF' : '#E0F4FA',
                cursor: 'pointer'
              }}>
              {tab.count && (
                <span
                  style={{
                    fontSize: '16px',
                    fontWeight: '800',
                    paddingRight: '10px'
                  }}>
                  {tab.count || 0}
                </span>
              )}
              <span>{tab.label}</span>
            </NavLink>
          </NavItem>
        ))}
      </Nav>

      <TabContent
        className="customTabContent mb-0"
        activeTab={activeTab}>
        <TabPane tabId="1">
          <AdManage
            adList={adList}
            toggle={toggle}
          />
        </TabPane>
        <TabPane tabId="2">
          <PostAd toggle={toggle} />
        </TabPane>
        <TabPane tabId="3">
          <DraftAd
            draftAdList={draftAdList}
            toggle={toggle}
            fetchAdsData={fetchAdsData}
          />
        </TabPane>
        <TabPane tabId="4">
          <LiveAds
            liveAds={liveAds}
            fetchAdsData={fetchAdsData}
          />
        </TabPane>
        <TabPane tabId="5">
          <AdHistory
            adHistory={adHistory}
            setAdHistory={setAdHistory}
            fetchAdsData={fetchAdsData}
            toggle={toggle}
          />
        </TabPane>
      </TabContent>
    </div>
  )
}

export default CreateAD
