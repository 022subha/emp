import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  countryList: [],
  stateList: {},
  cityList: {},
  uomList: [],
  hsnCategories: [],
  bussinessScales: [],
  natureOfBussiness: [],
  adCategories: [],
  subscriptionPlans: []
}

export const masterSlice = createSlice({
  name: 'master',
  initialState,
  reducers: {
    setCountryList: (state, action) => {
      state.countryList = action.payload
    },

    setStateList: (state, action) => {
      state.stateList = { ...state.stateList, [action.payload.country]: action.payload.states }
    },

    setCityList: (state, action) => {
      state.cityList = { ...state.cityList, [action.payload.state]: action.payload.cities }
    },

    setUomList: (state, action) => {
      state.uomList = action.payload
    },

    setHsnCategories: (state, action) => {
      state.hsnCategories = action.payload
    },

    setBussinessScales: (state, action) => {
      state.bussinessScales = action.payload
    },

    setNatureOfBussiness: (state, action) => {
      state.natureOfBussiness = action.payload
    },

    setAdCategories: (state, action) => {
      state.adCategories = action.payload
    },

    setSubscriptionPlans: (state, action) => {
      state.subscriptionPlans = action.payload
    }
  }
})

export const {
  setCountryList,
  setStateList,
  setCityList,
  setHsnCategories,
  setUomList,
  setBussinessScales,
  setNatureOfBussiness,
  setAdCategories,
  setSubscriptionPlans
} = masterSlice.actions

export default masterSlice.reducer
