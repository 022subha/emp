import './Home.scss'
import { debounce } from 'lodash'
import PrevBtn from '../../assets/images/icons/prev-btn-up.svg'
import NextBtn from '../../assets/images/icons/next-btn-down.svg'
import React, { useState, useEffect, useRef, useCallback } from 'react'
import LandingPage from '../../components/core/Home/Landing/LandingPage'
import TabSection from '../../components/core/Home/TabSection/TabSection'
import { FaAnglesDown, FaAnglesUp } from 'react-icons/fa6'

const Home = () => {
  const sectionRefs = useRef([])

  const [activeTab, setActiveTab] = useState('1')
  const [currentSection, setCurrentSection] = useState(1)

  const updateCurrentSection = useCallback(
    debounce(() => {
      const scrollPosition = window.scrollY + window.innerHeight / 2
      sectionRefs.current.forEach((section, index) => {
        if (section && section.offsetTop <= scrollPosition && section.offsetTop + section.offsetHeight > scrollPosition) {
          setCurrentSection(index + 1)
        }
      })
    }, 100),
    []
  )

  const scrollToSection = (sectionId) => {
    const targetSection = sectionRefs.current[sectionId - 1]
    if (targetSection) {
      const topOffset = targetSection.offsetTop - (sectionId === 1 ? 64 : 0)
      window.scrollTo({ top: topOffset, behavior: 'smooth' })
      setCurrentSection(sectionId)
    }
  }

  const handleScroll = (direction) => {
    const nextSection = direction === 'up' ? currentSection - 1 : currentSection + 1
    if (nextSection >= 1 && nextSection <= sectionRefs.current.length) {
      scrollToSection(nextSection)
    }
  }

  const showPlanSelectionPage = () => {
    setActiveTab('3')
    scrollToSection(2)
  }

  useEffect(() => {
    sectionRefs.current = sectionRefs.current.slice(0, 2)
  }, [])

  useEffect(() => {
    window.addEventListener('scroll', updateCurrentSection)
    return () => {
      window.removeEventListener('scroll', updateCurrentSection)
    }
  }, [updateCurrentSection])

  return (
    <div className="home__container p-2">
      <div
        id="section1"
        ref={(el) => (sectionRefs.current[0] = el)}>
        <LandingPage showPlanSelectionPage={showPlanSelectionPage} />
      </div>
      <div
        id="section2"
        ref={(el) => (sectionRefs.current[1] = el)}
        className="d-flex flex-column justify-content-center align-items-center">
        <TabSection
          handleScroll={handleScroll}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
        />
      </div>
      {currentSection === 2 && (
        <button
          onClick={() => handleScroll('up')}
          className="scrollBtn prev"
          aria-label="Scroll to previous section">
          {/* <img
            src={PrevBtn}
            alt="Previous Section"
          /> */}
          <FaAnglesUp style={{ fontSize: '40px', color: 'rgb(44 228 43)' }} />
        </button>
      )}
      {currentSection === 1 && (
        <button
          onClick={() => handleScroll('down')}
          className="scrollBtn next"
          aria-label="Scroll to next section">
          {/* <img
            src={NextBtn}
            alt="Next Section"
          /> */}
          <FaAnglesDown style={{ fontSize: '40px', color: 'rgb(44 228 43)' }} />
        </button>
      )}
    </div>
  )
}

export default Home
