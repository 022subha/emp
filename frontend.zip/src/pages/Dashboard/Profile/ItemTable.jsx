import React from 'react'
import { Table } from 'reactstrap'

export default function ItemTable({ itemInformation }) {
  return (
    <div>
      <Table
        bordered
        responsive
        rounded>
        <thead>
          <tr>
            <th>Material Name</th>
            <th>Material Category</th>
            <th>MOQ</th>
            <th>UOM</th>
            <th>Material Description</th>
          </tr>
        </thead>
        <tbody>
          {(itemInformation || []).map((element, index) => (
            <tr key={index}>
              <td
                scope="row"
                style={{ minWidth: '400px' }}>
                {element?.materialName || 'Not Available'}
              </td>
              <td>{element?.materialHSN?.hsnDescription || 'Not Available'}</td>
              <td>{element?.minimumOrderQuantity || 'Not Available'}</td>
              <td>{element?.materialUOM?.name || 'Not Available'}</td>
              <td style={{ minWidth: '400px' }}>{element?.materialDescription || 'Not Available'}</td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  )
}
