import {
  Row,
  Col,
  Card,
  Badge,
  Modal,
  Button,
  CardImg,
  Tooltip,
  Carousel,
  CardBody,
  CardText,
  ModalBody,
  CardTitle,
  ListGroup,
  Container,
  ModalHeader,
  CarouselItem,
  CardSubtitle,
  ListGroupItem,
  CarouselControl,
  CarouselIndicators,
} from "reactstrap";
import { FaEye } from "react-icons/fa";
import { useDispatch } from "react-redux";
import React, { useEffect, useState } from "react";
import ImgPng from "../../../assets/images/icons/image.webp";
import {
  fetchAdDetail,
  fetchMyLiveAds,
} from "../../../services/controller/adAPI";

const AdList = ({ fetchAdsData }) => {
  const dispatch = useDispatch();
  const [ad, setAd] = useState(null);

  const [liveAds, setLiveAds] = useState([]);

  useEffect(() => {
    dispatch(fetchMyLiveAds()).then((liveData) =>
      setLiveAds([...liveData, ...liveData, ...liveData])
    );
  }, []);

  const [tooltipOpen, setTooltipOpen] = useState({});

  const toggleTooltip = (id) =>
    setTooltipOpen((prev) => ({ ...prev, [id]: !prev[id] }));

  const [modal, setModal] = useState(false);

  const toggleLiveAdPreview = () => {
    setModal((prev) => !prev);
  };

  const handleLiveAdPreview = (id) => {
    dispatch(fetchAdDetail(id)).then((adDetail) => {
      if (adDetail) {
        setAd(adDetail);
        toggleLiveAdPreview();
      }
    });
  };

  const [carouselIndex, setCarouselIndex] = useState(0);
  const [carouselAnimating, setCarouselAnimating] = useState(false);

  const handleCarouselNext = () =>
    !carouselAnimating &&
    setCarouselIndex((i) => (i + 1) % (ad?.banners?.length || 1));
  const handleCarouselPrev = () =>
    !carouselAnimating &&
    setCarouselIndex((i) => (i === 0 ? (ad?.banners?.length || 1) - 1 : i - 1));

  const formatDate = (dateString) => {
    const date = new Date(dateString);

    const day = date.getDate();
    const suffix = ["th", "st", "nd", "rd"][
      day % 10 > 3 || Math.floor((day % 100) / 10) === 1 ? 0 : day % 10
    ];

    const options = { month: "long", year: "numeric" };
    const formattedDate = new Intl.DateTimeFormat("en-US", options).format(
      date
    );

    const timeOptions = { hour: "2-digit", minute: "2-digit", hour12: true };
    const formattedTime = new Intl.DateTimeFormat("en-US", timeOptions).format(
      date
    );

    return `${formattedDate} ${day}${suffix} | ${formattedTime}`;
  };

  return (
    <Container>
      <h5 style={{ fontSize: "22px" }}>Suppliers AD</h5>
      <Row className="p-0 ad-list__wrapper">
        {liveAds.map((ad, index) => (
          <Col
            xs="12"
            md="6"
            xl="3"
            className="ad-list__container p-1"
            key={index}
          >
            <Card
              className="ad-list__card m-0"
              style={{ background: "#eff1fc", boxShadow: "none" }}
            >
              {ad?.banners?.[0]?.fileUrl ? (
                <CardImg
                  alt="Card image cap"
                  src={
                    "https://e-marketplace.s3.ap-south-1.amazonaws.com/" +
                    ad?.banners?.[0]?.fileUrl
                  }
                  top
                  width="100%"
                  height={"250px"}
                  onClick={() => handleLiveAdPreview(ad.id)}
                  style={{ cursor: "pointer", objectFit: "contain" }}
                />
              ) : (
                <CardImg
                  alt="Card image cap"
                  src={ImgPng}
                  top
                  width="100%"
                  height={"250px"}
                  onClick={() => handleLiveAdPreview(ad.id)}
                  style={{ cursor: "pointer", objectFit: "contain" }}
                />
              )}

              <CardBody>
                <CardTitle tag="h5" className="row">
                  <Col
                    className="flex-grow-1 cardTitle_text"
                    id={`tooltip-title-${index}`}
                  >
                    <span
                      className="text-truncate"
                      style={{ fontSize: "18px" }}
                    >
                      {ad.title}
                    </span>
                  </Col>
                  <Tooltip
                    placement="top"
                    isOpen={tooltipOpen[`title-${index}`]}
                    target={`tooltip-title-${index}`}
                    toggle={() => toggleTooltip(`title-${index}`)}
                  >
                    {ad.title}
                  </Tooltip>
                  {ad?.viewsCount ? (
                    <Col xs={"auto"}>
                      <Badge pill className="float-end" color="primary">
                        <span className="text-decoration-none text-light d-flex align-items-center">
                          <FaEye />{" "}
                          <span className="ms-2">{ad?.viewsCount || 0}</span>
                        </span>
                      </Badge>
                    </Col>
                  ) : (
                    <></>
                  )}
                </CardTitle>
                <CardSubtitle
                  className="mb-2 cardCategory_text"
                  style={{ fontSize: "15px" }}
                >
                  <span className="fw-bold">Category:</span>{" "}
                  <span id={`tooltip-category-${index}`}>
                    {ad?.category?.hsnDescription || "Not Available"}
                  </span>
                  <Tooltip
                    placement="top"
                    isOpen={tooltipOpen[`category-${index}`]}
                    target={`tooltip-category-${index}`}
                    toggle={() => toggleTooltip(`category-${index}`)}
                  >
                    {ad?.category?.hsnDescription}
                  </Tooltip>
                </CardSubtitle>
                <CardSubtitle className="mb-2" style={{ fontSize: "15px" }}>
                  <span className="fw-bold">Offer Start Date: </span>
                  <span>
                    {ad?.offerStartDate
                      ?.split("T")[0]
                      ?.split("-")
                      ?.reverse()
                      ?.join("/") || "Not Available"}
                  </span>
                </CardSubtitle>
                <CardSubtitle className="mb-2" style={{ fontSize: "15px" }}>
                  <span className="fw-bold">Offer End Date: </span>
                  <span>
                    {ad?.offerEndDate
                      ?.split("T")[0]
                      ?.split("-")
                      ?.reverse()
                      ?.join("/") || "Not Available"}
                  </span>
                </CardSubtitle>
                <Row>
                  <Col
                    xs="auto"
                    className="flex-grow-1 d-flex align-items-center text-muted"
                    style={{ fontSize: "15px" }}
                  >
                    {formatDate(ad?.createdAt)}
                  </Col>
                </Row>
                <Row>
                  <Col xs="auto mt-3">
                    <Button
                      type="button"
                      className="btn border-0 me-1"
                      style={{
                        background: "#00b1f1",
                        color: "#fff",
                        padding: "4px 10px",
                        fontSize: "14px",
                      }}
                      onClick={() => handleLiveAdPreview(ad.id)}
                    >
                      View Deal
                    </Button>
                  </Col>
                </Row>
              </CardBody>
            </Card>
          </Col>
        ))}
      </Row>

      <Modal isOpen={modal} toggle={toggleLiveAdPreview} size="xl">
        <ModalHeader
          className="ad-list__ad-modal-header"
          toggle={toggleLiveAdPreview}
        >
          AD Details
        </ModalHeader>
        <ModalBody className="ad-list__ad-modal-body">
          <Card className="ad-list__ad-modal-wrapper">
            <Carousel
              dark={true}
              activeIndex={carouselIndex}
              next={handleCarouselNext}
              previous={handleCarouselPrev}
            >
              <CarouselIndicators
                items={ad?.banners || []}
                activeIndex={carouselIndex}
                onClickHandler={(newIndex) =>
                  !carouselAnimating && setCarouselIndex(newIndex)
                }
              />
              {(ad?.banners?.length ? ad.banners : [{}]).map((item, i) => (
                <CarouselItem
                  key={i}
                  onExiting={() => setCarouselAnimating(true)}
                  onExited={() => setCarouselAnimating(false)}
                >
                  <img
                    src={
                      item?.fileUrl
                        ? `https://e-marketplace.s3.ap-south-1.amazonaws.com/${item.fileUrl}`
                        : ImgPng
                    }
                    alt="Ad Image"
                  />
                </CarouselItem>
              ))}
              <CarouselControl
                direction="prev"
                directionText="Previous"
                onClickHandler={handleCarouselPrev}
              />
              <CarouselControl
                direction="next"
                directionText="Next"
                onClickHandler={handleCarouselNext}
              />
            </Carousel>

            <CardBody>
              <CardTitle className="row" tag="h5">
                <Col className="flex-grow-1 ad-list__ad-modal-title">
                  <span id="tooltip1">{ad?.title || "Not Available"}</span>
                </Col>
                {ad?.title && (
                  <Tooltip
                    placement="top"
                    isOpen={tooltipOpen.tooltip1}
                    autohide={false}
                    target="tooltip1"
                    toggle={() => toggle("tooltip1")}
                  >
                    {ad?.title}
                  </Tooltip>
                )}
                {ad?.viewsCount ? (
                  <Col xs={"auto"}>
                    <Badge pill className="float-end" color="primary">
                      <span className="text-decoration-none text-light d-flex align-items-center">
                        <FaEye />{" "}
                        <span className="ms-2">{ad?.viewsCount || 0}</span>
                      </span>
                    </Badge>
                  </Col>
                ) : (
                  <></>
                )}
              </CardTitle>
            </CardBody>
            <ListGroup className="PostAdList" flush>
              <ListGroupItem>
                <CardText>
                  <span className="fw-bold">Category:</span>{" "}
                  <span>{ad?.category?.hsnDescription || "Not Available"}</span>
                </CardText>
              </ListGroupItem>
              <ListGroupItem>
                <CardText>
                  <span className="fw-bold">Offer Start & End Date:</span>{" "}
                  <span>
                    {ad?.offerStartDate
                      .split("T")[0]
                      .split("-")
                      .reverse()
                      .join("/") || "Not Available"}{" "}
                    -{" "}
                    {ad?.offerEndDate
                      .split("T")[0]
                      .split("-")
                      .reverse()
                      .join("/") || "Not Available"}
                  </span>
                </CardText>
              </ListGroupItem>
              <ListGroupItem>
                <CardText>
                  <span className="fw-bold">Description:</span>{" "}
                  <span>{ad?.description || "Not Available"}</span>
                </CardText>
              </ListGroupItem>
              <ListGroupItem>
                <CardText>
                  <span className="fw-bold">Deal Terms:</span>{" "}
                  <span>{ad?.dealTerms || "Not Available"}</span>
                </CardText>
              </ListGroupItem>
            </ListGroup>
          </Card>
        </ModalBody>
      </Modal>
    </Container>
  );
};

export default AdList;
