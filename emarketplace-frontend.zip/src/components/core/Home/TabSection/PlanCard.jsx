import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { MdRocketLaunch } from 'react-icons/md'
import { setPlanDuration, setPlanId } from '../../../../store/slices/planSlice'
import { Badge, Card, CardBody, Button, CardTitle, CardText, Container, Row, Col, ListGroup, ListGroupItem } from 'reactstrap'

const PlanCard = () => {
  const dispatch = useDispatch()
  const navigate = useNavigate()

  const subscriptionPlans = useSelector((state) => state.master.subscriptionPlans)

  const handlePlanSelection = (planId, planDuration) => {
    dispatch(setPlanId(planId))
    dispatch(setPlanDuration(planDuration))
    navigate('/buy-plan')
  }

  return (
    <div>
      <Container fluid>
        <Row>
          <Col
            xs={12}
            className="p-0 mt-3">
            <Card
              body
              color="primary"
              className="PlanCard GlossBg"
              outline>
              <Badge
                pill
                bg="light"
                className="Enterprise CardBadge fs-3">
                <MdRocketLaunch /> {subscriptionPlans[0]?.planName} Plan
              </Badge>
              <CardBody className="p-0">
                {/* <CardTitle tag="h5">
                  <h3 className="display-5 text-light mb-0">
                    {new Intl.NumberFormat('en-IN').format(subscriptionPlans[0]?.planPrice)}
                    /month
                  </h3>
                </CardTitle> */}
                <CardText className="text-light fs-4 fw-bold mb-2">
                  For large suppliers who want maximum visibility, detailed analytics, and the ability to post multiple high-impact ads to attract top
                  buyers.
                </CardText>
                <CardText>
                  <ListGroup numbered>
                    <ListGroupItem className="px-0 border-0">
                      Access to an enhanced supplier profile: Include additional details to better showcase your business.
                    </ListGroupItem>
                    <ListGroupItem className="px-0 border-0">
                      Ability to post {subscriptionPlans[0]?.adCountPerMonth} Ads/month in the Advertisement Repository, allowing for maximum
                      exposure.
                    </ListGroupItem>
                    <ListGroupItem className="px-0 border-0">
                      Ads placed in featured ad slots with 60-day visibility and guaranteed top placement in ad rotations.
                    </ListGroupItem>
                    <ListGroupItem className="px-0 border-0">
                      Access to full ad analytics:
                      <ul>
                        <li>Number of views, Viewer</li>
                        <li>Info will be displayed</li>
                        <li>Demographic breakdown of viewers (location, industry).</li>
                      </ul>
                    </ListGroupItem>
                    <ListGroupItem className="px-0 border-0">
                      Highest-priority listing in the supplier search results for maximum exposure to buyers.
                    </ListGroupItem>
                  </ListGroup>
                </CardText>
              </CardBody>
              <div className="d-flex justify-content-center align-items-center gap-5">
                <Button
                  className="fs-5 Enterprise px-53 d-flex flex-column justify-content-center align-items-center px-4"
                  onClick={() => handlePlanSelection(subscriptionPlans[0]?.id, 1)}>
                  <span>6 month subscription</span>
                  <span>₹ {new Intl.NumberFormat('en-IN').format(subscriptionPlans[0]?.planPrice6Months)}</span>
                </Button>

                <Button
                  className="fs-5 Enterprise px-53 d-flex flex-column justify-content-center align-items-center px-4"
                  onClick={() => handlePlanSelection(subscriptionPlans[0]?.id, 2)}>
                  <span>12 month subscription</span>
                  <span>₹ {new Intl.NumberFormat('en-IN').format(subscriptionPlans[0]?.planPrice12Months)}</span>
                </Button>
              </div>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  )
}

export default PlanCard
