import React from 'react'
import { Card, Button, Row, Col } from 'reactstrap'
import DraftTable from './DraftAdTable'

export default function DraftAd({ draftAdList, fetchAdsData, toggle }) {
  return (
    <div>
      <Card
        body
        className="bg-transparent border-0 shadow-none mb-0"
        style={{ height: 'calc(100vh - 175px)', overflowY: 'auto' }}>
        <Row>
          <DraftTable
            draftAdList={draftAdList}
            fetchAdsData={fetchAdsData}
            toggle={toggle}
          />
        </Row>
      </Card>
    </div>
  )
}
