import React, { useState, useMemo, useCallback } from 'react'
import ImgPng from '../../assets/images/icons/image.webp'
import { Card, CardTitle, CardText, Row, Col, CardBody, CardSubtitle, Tooltip } from 'reactstrap'

export default function UseSlots({ adList, toggle }) {
  const [activeIndexes, setActiveIndexes] = useState({})
  const [animating, setAnimating] = useState(false)
  const [tooltipOpen, setTooltipOpen] = useState({})

  const toggleTooltip = (id) => {
    setTooltipOpen((prev) => ({ ...prev, [id]: !prev[id] }))
  }

  const next = useCallback(
    (id, length) => {
      if (animating) return
      setActiveIndexes((prev) => ({ ...prev, [id]: (prev[id] + 1) % length }))
    },
    [animating]
  )

  const previous = useCallback(
    (id, length) => {
      if (animating) return
      setActiveIndexes((prev) => ({ ...prev, [id]: prev[id] === 0 ? length - 1 : prev[id] - 1 }))
    },
    [animating]
  )

  const onExiting = useCallback(() => setAnimating(true), [])
  const onExited = useCallback(() => setAnimating(false), [])

  const renderedCards = useMemo(
    () =>
      (adList || []).map((item) => {
        const itemId = item.id
        const banners = item.banners.length > 0 ? item.banners : [{}]
        return (
          <Col
            xs={12}
            sm={6}
            xl={4}
            xxl={2}
            key={itemId}>
            <Card
              className="used-slots__card mb-0"
              style={{ width: 'auto' }}>
              <div className="used-slots__image-container">
                <img
                  className="useSlotsImg"
                  alt="Sample"
                  src={banners[0]?.fileUrl || ImgPng}
                  onClick={() => toggle('4')}
                />
              </div>

              <CardBody className="p-2">
                <CardTitle
                  tag="h6"
                  className="used-card__view-count">
                  {item?.viewsCount || 0} Views
                </CardTitle>
                <CardSubtitle
                  id={`tooltip-title-${itemId}`}
                  className="mb-1 text-dark fw-bold text-truncate"
                  tag="h5">
                  {item?.title || 'Not Available'}
                </CardSubtitle>
                <Tooltip
                  placement="top"
                  isOpen={tooltipOpen[`tooltip-title-${itemId}`]}
                  target={`tooltip-title-${itemId}`}
                  toggle={() => toggleTooltip(`tooltip-title-${itemId}`)}>
                  {item?.title || 'Not Available'}
                </Tooltip>
                <CardSubtitle
                  id={`tooltip-category-${itemId}`}
                  className="mb-1 text-muted text-truncate"
                  tag="p">
                  {item?.category?.categoryName || 'Not Available'}
                </CardSubtitle>
                <Tooltip
                  placement="top"
                  isOpen={tooltipOpen[`tooltip-category-${itemId}`]}
                  target={`tooltip-category-${itemId}`}
                  toggle={() => toggleTooltip(`tooltip-category-${itemId}`)}>
                  {item?.category?.categoryName || 'Not Available'}
                </Tooltip>
                <CardText className="text-muted">
                  {item?.offerStartDate?.split('T')[0]?.split('-').reverse().join('/') || 'Not Available'} -{' '}
                  {item?.offerEndDate?.split('T')[0]?.split('-').reverse().join('/') || 'Not Available'}
                </CardText>
              </CardBody>
            </Card>
          </Col>
        )
      }),
    [adList, activeIndexes, next, previous, onExiting, onExited, tooltipOpen]
  )

  return <Row className="row-gap-4">{renderedCards}</Row>
}
