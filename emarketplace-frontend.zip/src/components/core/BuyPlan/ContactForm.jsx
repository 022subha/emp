import React, { useState } from 'react'
import { useDispatch } from 'react-redux'
import { IoMdClose } from 'react-icons/io'
import OTPInputEmail from './OtpInputEmail'
import OTPInputMobile from './OtpInputMobile'
import PhoneInput from '../../ui/mobile/PhoneInput'
import { Controller, useForm } from 'react-hook-form'
import { EMAIL_REGEX } from '../../../utils/regexHelper'
import { sendOtp, verifyOtp } from '../../../services/controller/authAPI'
import { Row, Col, Form, Label, Modal, Button, FormGroup, ModalBody, ModalHeader, Input } from 'reactstrap'

const ContactForm = ({ className, isOtpVerified, setIsOtpVerified, setOtpVerificationToken }) => {
  const dispatch = useDispatch()
  const {
    watch,
    register,
    handleSubmit,
    formState: { errors },
    control,
    setValue
  } = useForm()

  const [modal, setModal] = useState(false)

  const [emailOtp, setEmailOtp] = useState(new Array(6).fill(''))
  const [whatsappNumberOtp, setWhatsappNumberOtp] = useState(new Array(6).fill(''))

  const toggle = () => {
    setEmailOtp(new Array(6).fill(''))
    setWhatsappNumberOtp(new Array(6).fill(''))
    setModal(!modal)
  }

  const handleSendOTP = (data) => {
    dispatch(sendOtp({ email: data.email, whatsappNumber: data.phoneCode + data.whatsappNumber })).then((success) => {
      /*  if (success) */ toggle()
    })
  }

  const handleValidateOTP = (data) => {
    dispatch(
      verifyOtp({
        email: data.email,
        whatsappNumber: data.phoneCode + data.whatsappNumber,
        mjPROId: null,
        emailOtp: emailOtp.join(''),
        whatsappNumberOtp: whatsappNumberOtp.join('')
      })
    ).then((token) => {
      if (token) {
        setOtpVerificationToken(token)
        setIsOtpVerified(true)
        toggle()
      }
    })
  }

  const resendOTP = async (data) => {
    dispatch(sendOtp(data))
  }

  const closeBtn = (
    <button
      className="otp-modal__close-btn"
      onClick={toggle}
      type="button">
      <IoMdClose />
    </button>
  )

  return (
    <div>
      <Form onSubmit={handleSubmit(handleSendOTP)}>
        <Row className="">
          {/* <Col md={4}> */}
          <FormGroup className="contact-form__input-container">
            <Label style={{ fontSize: '20px', color: '#fff', margin: 0 }}>Email</Label>
            <Controller
              defaultValue=""
              name="email"
              control={control}
              rules={{
                required: 'Email is required',
                pattern: {
                  value: EMAIL_REGEX,
                  message: 'Invalid email address'
                }
              }}
              render={({ field, fieldState: { error } }) => (
                <>
                  <Input
                    {...field}
                    type="text"
                    id="email"
                    disabled={isOtpVerified}
                    placeholder="Enter Email ID"
                    invalid={error ? true : false}
                    className={error ? 'contact-form__input error-input' : 'contact-form__input'}
                  />
                  {error && <span className="text-danger contact-form__error-message">{error.message}</span>}
                </>
              )}
            />
          </FormGroup>
          {/* </Col> */}
          {/* <Col md={4}> */}
          <FormGroup className="contact-form__input-container">
            <Label style={{ fontSize: '20px', color: '#fff', margin: 0 }}>WhatsApp Number</Label>
            <PhoneInput
              watch={watch}
              errors={errors}
              control={control}
              disabled={isOtpVerified}
              setValue={setValue}
              name="whatsappNumber"
            />
            {errors.whatsappNumber && <p className="contact-form__error-message">{errors.whatsappNumber.message}</p>}
          </FormGroup>
          {/* </Col> */}
          {/* <Col
            md={'auto'}
            className="d-flex flex-column justify-content-end"> */}
          <div className="d-flex justify-content-end">
            {isOtpVerified ? (
              <Button
                className="mjPrimary-btn"
                type="button"
                color="brand-color"
                disabled={isOtpVerified}>
                Verified
              </Button>
            ) : (
              <Button
                className="mjPrimary-btn"
                type="button"
                color="brand-color"
                onClick={handleSubmit(handleSendOTP)}>
                Send OTP
              </Button>
            )}
          </div>
          {/* </Col> */}
        </Row>
      </Form>

      <Modal
        isOpen={modal}
        toggle={toggle}
        className={className}
        size="lg">
        <ModalHeader
          className="custom-modal-header"
          toggle={toggle}
          close={closeBtn}>
          OTP Verification
        </ModalHeader>
        <ModalBody className="text-center">
          <Row>
            <Col xs={12}>
              <p>An OTP has been sent to your Mobile Number and Email ID. Please enter the OTPs below to verify your contact details.</p>
            </Col>
            <Col
              xs={12}
              className="mb-4">
              <Label className="modal-form-label">Please enter the OTP sent to your mobile number.</Label>
              <OTPInputMobile
                otp={whatsappNumberOtp}
                setOtp={setWhatsappNumberOtp}
              />
            </Col>
            <Col
              xs={12}
              className="mb-4">
              <Label className="modal-form-label">Please enter the OTP sent to your email ID.</Label>
              <OTPInputEmail
                otp={emailOtp}
                setOtp={setEmailOtp}
              />
            </Col>
            <Col
              xs={12}
              className="mb-2">
              <Button
                className="mjPrimary-btn btn-lg"
                onClick={handleSubmit(handleValidateOTP)}>
                Validate
              </Button>
            </Col>
            <Col xs={12}>
              <Button
                className="mjPrimary-btn-outlined btn-lg"
                onClick={handleSubmit(resendOTP)}>
                Resend OTP
              </Button>
            </Col>
          </Row>
        </ModalBody>
      </Modal>
    </div>
  )
}

export default ContactForm
