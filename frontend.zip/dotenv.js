export const BASE_URL = "http://localhost:8080/api/v1";
export const INDIA_CODE = 101;
export const HELPDESK_EMAIL = "support.mjpro@mjunction.in";
export const HELPDESK_MOBILE = "033-6603-1747";
