import FAQ from './FAQ'
import React from 'react'
import WorkCard from './WorkCard'
import PlanCard from './PlanCard'
import OfferCard from './OfferCard'
import './TabSectionComponentStyles.scss'
import { TabContent, TabPane, Nav, NavItem, NavLink, Container, Row, Col } from 'reactstrap'

const TabSection = ({ activeTab, setActiveTab }) => {
  const toggle = (tab) => {
    if (activeTab !== tab) setActiveTab(tab)
  }

  const showPlanSelectionPage = () => {
    setActiveTab('3')
  }

  return (
    <Container
      fluid
      className="p-0">
      <div className="tab-section__container">
        <Row>
          <Col
            lg="auto"
            className="d-flex flex-column justify-content-start">
            <div className="tab-section__tab-area overflow-x-auto">
              <Nav
                pills
                className="tab-section__nav w-mx-auto">
                <NavItem className="cursor-pointer">
                  <NavLink
                    className={activeTab === '1' ? 'active' : ''}
                    onClick={() => {
                      toggle('1')
                    }}>
                    What we offer
                  </NavLink>
                </NavItem>
                <NavItem className="cursor-pointer">
                  <NavLink
                    className={activeTab === '2' ? 'active' : ''}
                    onClick={() => {
                      toggle('2')
                    }}>
                    How it works?
                  </NavLink>
                </NavItem>
                <NavItem className="cursor-pointer">
                  <NavLink
                    className={activeTab === '3' ? 'active' : ''}
                    onClick={() => {
                      toggle('3')
                    }}>
                    Select Your Plan
                  </NavLink>
                </NavItem>
                <NavItem className="cursor-pointer">
                  <NavLink
                    className={activeTab === '4' ? 'active' : ''}
                    onClick={() => {
                      toggle('4')
                    }}>
                    FAQ
                  </NavLink>
                </NavItem>
              </Nav>
            </div>
          </Col>

          <Col className="p-2">
            <TabContent
              className="tab-content__container"
              activeTab={activeTab}>
              <TabPane tabId="1">
                <OfferCard showPlanSelectionPage={showPlanSelectionPage} />
              </TabPane>
              <TabPane tabId="2">
                <WorkCard showPlanSelectionPage={showPlanSelectionPage} />
              </TabPane>
              <TabPane tabId="3">
                <PlanCard />
              </TabPane>
              <TabPane tabId="4">
                <FAQ />
              </TabPane>
            </TabContent>
          </Col>
        </Row>
      </div>
    </Container>
  )
}

export default TabSection
