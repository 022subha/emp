import Header from "./Header/Header";
import Footer from "./Footer/Footer";
import { Container } from "reactstrap";
import Sidebar from "./Sidebar/Sidebar";
import { Outlet } from "react-router-dom";
import "./DashboardLayoutComponentsStyle.scss";
import { useDispatch, useSelector } from "react-redux";
import { ToggleMobileSidebar } from "../../../store/slices/CustomizerSlice";

const FullLayout = () => {
  const dispatch = useDispatch();
  const showMobileSidebar = useSelector(
    (state) => state.customizer.isMobileSidebar
  );

  return (
    <>
      {showMobileSidebar && (
        <div
          className="sidebarOverlay"
          onClick={() => dispatch(ToggleMobileSidebar())}
        />
      )}

      <div className={`pageWrapper d-md-block d-lg-flex `}>
        <aside
          className={`sidebarArea ${showMobileSidebar ? "showSidebar" : ""}`}
        >
          <Sidebar />
        </aside>

        <div className={`contentArea fixedTopbar`}>
          <Header />
          <Container fluid className="p-2 h-100 w-100">
            <Outlet />
          </Container>
          <Footer />
        </div>
      </div>
    </>
  );
};

export default FullLayout;
