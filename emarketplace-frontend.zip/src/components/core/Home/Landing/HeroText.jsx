import React from 'react'
import { Row, Col, Container } from 'reactstrap'

export default function HeroText() {
  return (
    <div>
      <Container>
        <Row>
          <Col xs={12}>
            <Row className="text-center">
              <Col>
                <div className="d-flex justify-content-center">
                  <h1 className="display-2 text-light ms-2">Welcome to mjPROConnect</h1>
                </div>
                <div className="d-flex justify-content-center">
                  <h3 className="display-6 fw-bold text-light">Where Buyers and Suppliers Connect Seamlessly</h3>
                </div>
              </Col>
            </Row>
          </Col>
        </Row>
      </Container>
    </div>
  )
}
