import './Profiling.scss'
import { toast } from 'react-toastify'
import { TiTick } from 'react-icons/ti'
import { useForm } from 'react-hook-form'
import { INDIA_CODE } from '../../../dotenv'
import React, { useEffect, useState } from 'react'
import { CONTACT_TYPE } from '../../data/enum'
import { useDispatch, useSelector } from 'react-redux'
import Spinner from '../../components/common/spinner/Spinner'
import mjPRO_Logo from '../../assets/images/logos/mjPRo_Logo.svg'
import MaterialForm from '../../components/core/Profiling/MaterialForm'
import OperationForm from '../../components/core/Profiling/OperationForm'
import OrganizationForm from '../../components/core/Profiling/OrganizationForm'
import { fetchCityList, fetchStateList } from '../../services/controller/masterAPI'
import { Button, Col, Row, Container, Card, CardText, CardFooter } from 'reactstrap'
import { saveOpInfoAsDraft, saveOrgInfoAsDraft } from '../../services/controller/supplierAPI'
import { fetchOpInfoBeforePublishing, fetchOrgInfoBeforePublishing } from '../../services/controller/supplierAPI'
import { fetchItemInfoBeforePublishing, publishProfile, saveItemInfoAsDraft } from '../../services/controller/supplierAPI'

const Profiling = () => {
  const dispatch = useDispatch()

  const {
    watch: orgWatch,
    control: orgControl,
    register: orgRegister,
    setValue: orgSetValue,
    getValues: orgGetValues,
    handleSubmit: orgHandleSubmit,
    formState: { errors: orgErrors }
  } = useForm({
    defaultValues: {
      hasGstin: 'Y',
      isMsme: 'N',
      gstinInformation: [],
      keyPartnership: [],
      contactDetails: [
        {
          contactPersonName: '',
          contactPersonEmail: '',
          contactPersonWhatsappNumber: '',
          contactPersonDesignation: '',
          contactVerificationToken: null,
          isContactPersonVerified: false,
          contactPersonType: 'primary'
        }
      ]
    }
  })

  const {
    control: contactControl,
    setValue: contactSetValue,
    handleSubmit: contactHandleSubmit,
    formState: { errors: contactErrors }
  } = useForm({
    defaultValues: {
      contactDetails: [
        {
          contactPersonName: '',
          contactPersonEmail: '',
          contactPersonWhatsappNumber: '',
          contactPersonDesignation: '',
          isContactPersonVerified: false,
          contactVerificationToken: null,
          contactPersonType: 'primary'
        }
      ]
    }
  })

  const {
    watch: opWatch,
    control: opControl,
    register: opRegister,
    setValue: opSetValue,
    getValues: opGetValues,
    handleSubmit: opHandleSubmit,
    formState: { errors: opErrors }
  } = useForm({
    defaultValues: {
      manufacturingLocations: [{ country: '', state: '', city: '', address: '', pinCode: '' }],
      productionCapacities: [{ materialName: '', capacity: '', uom: '' }],
      subsidiaries: [],
      countriesDoingBussinessIn: [],
      top10Buyers: [],
      itemCategories: [{ category: '', value: '', currency: '', capacity: '', uom: '', topBuyers: [] }]
    }
  })

  const {
    watch: itemWatch,
    control: itemControl,
    register: itemRegister,
    setValue: itemSetValue,
    getValues: itemGetValues,
    handleSubmit: itemHandleSubmit,
    formState: { errors: itemErrors }
  } = useForm({
    defaultValues: { materials: [{ materialName: '', hsnCategoryId: '', orderQuantity: '', uom: '', materialDescription: '' }] }
  })

  const isLoading = useSelector((state) => state.ui.isLoading)
  const cities = useSelector((state) => state.master.cityList)
  const states = useSelector((state) => state.master.stateList)

  const [currentStep, setCurrentStep] = useState(1)
  const [financialYear, setFinancialYear] = useState('')

  const [orgLogo, setOrgLogo] = useState(null)
  const [orgAwards, setOrgAwards] = useState([])
  const [opBrochures, setOpBrochures] = useState([])
  const [opTradeMarks, setOpTradeMarks] = useState([])
  const [opPatents, setOpPatents] = useState([])
  const [itemCertifications, setItemCertifications] = useState([])

  const steps = [
    { id: 1, title: 'Organizational Data' },
    { id: 2, title: 'Operational Data' },
    { id: 3, title: 'Material Data' }
  ]

  const changeOrgLogoHandler = (e) => {
    const file = e.target.files[0]
    if (file) {
      if (file.size < 5 * 1024 * 1024) {
        const reader = new FileReader()
        reader.onloadend = () => {
          setOrgLogo(file)
        }
        reader.readAsDataURL(file)
      } else {
        toast.error(`File "${file.name}" exceeds the 5MB size limit.`)
      }
    }
  }

  const handleOrganizationalNext = (data) => {
    const isNotEmpty = (value) => value && value !== ''
    const parseNumber = (value) => (isNotEmpty(value) ? parseInt(value) : null)

    const payload = {
      countryId: parseNumber(data?.countryId),
      stateId: parseNumber(data?.stateId),
      cityId: parseNumber(data?.cityId),
      ...(data?.countryId == INDIA_CODE
        ? {
            panNumber: isNotEmpty(data?.panNumber) ? data.panNumber : null,
            panHolderName: isNotEmpty(data?.panHolderName) ? data.panHolderName : null,
            panHolderDOB: isNotEmpty(data?.panHolderDOB) ? data.panHolderDOB : null,
            msmeNumber: data?.isMsme === 'Y' && isNotEmpty(data?.msmeNumber) ? data.msmeNumber : null,
            gstinInformation:
              data?.hasGstin === 'Y' && Array.isArray(data.gstinInformation)
                ? data.gstinInformation.map((item) => ({
                    gstinNumber: item.gstinNumber
                  }))
                : []
          }
        : {
            uinNumber: isNotEmpty(data?.uinNumber) ? data.uinNumber : null
          }),
      companyName: isNotEmpty(data?.companyName) ? data.companyName : null,
      companyOverview: isNotEmpty(data?.companyOverview) ? data.companyOverview : null,
      establishmentYear: parseNumber(data?.establishmentYear),
      bussinessScaleId: parseNumber(data?.bussinessScaleId),
      annualRevenue: parseNumber(data?.annualRevenue),
      twitterId: isNotEmpty(data?.twitterId) ? data.twitterId : null,
      linkedInId: isNotEmpty(data?.linkedInId) ? data.linkedInId : null,
      facebookId: isNotEmpty(data?.facebookId) ? data.facebookId : null,
      contactDetails: Array.isArray(data?.contactDetails)
        ? data.contactDetails.map((item) => ({
            contactPersonName: isNotEmpty(item.contactPersonName) ? item.contactPersonName : null,
            contactPersonEmail: isNotEmpty(item.contactPersonEmail) ? item.contactPersonEmail : null,
            contactPersonWhatsappNumber: isNotEmpty(item.contactPersonWhatsappNumber) ? item.contactPersonWhatsappNumber : null,
            contactPersonDesignation: isNotEmpty(item.contactPersonDesignation) ? item.contactPersonDesignation : null,
            contactPersonVerificationToken: item.contactVerificationToken || null,
            isContactPersonVerified: item.isContactPersonVerified || false,
            contactPersonType: item.contactPersonType
          }))
        : [],
      logoUrl: null,
      awardUrls: []
    }

    const orgFormDraft = new FormData()
    orgFormDraft.append('data', JSON.stringify(payload))
    orgFormDraft.append('logo', orgLogo)

    orgAwards.forEach((award, index) => {
      orgFormDraft.append(`awards${index + 1}`, award.file)
    })

    if (data.contactDetails.filter((item) => !item.isContactPersonVerified).length > 0) {
      toast.error('All contact persons must be verified.')
    } else {
      dispatch(saveOrgInfoAsDraft(orgFormDraft)).then((success) => {
        if (success) {
          setCurrentStep((prev) => (prev < steps.length ? prev + 1 : prev))
        } else {
          toast.error('Something went wrong.')
        }
      })
    }
  }

  const handleOrganizationalDraft = async () => {
    const data = orgGetValues()

    const isNotEmpty = (value) => value && value !== ''
    const parseNumber = (value) => (isNotEmpty(value) ? parseInt(value) : null)

    const payload = {
      countryId: parseNumber(data?.countryId),
      stateId: parseNumber(data?.stateId),
      cityId: parseNumber(data?.cityId),
      ...(data?.countryId == INDIA_CODE
        ? {
            panNumber: isNotEmpty(data?.panNumber) ? data.panNumber : null,
            panHolderName: isNotEmpty(data?.panHolderName) ? data.panHolderName : null,
            panHolderDOB: isNotEmpty(data?.panHolderDOB) ? data.panHolderDOB : null,
            msmeNumber: data?.isMsme === 'Y' && isNotEmpty(data?.msmeNumber) ? data.msmeNumber : null,
            gstinInformation:
              data?.hasGstin === 'Y' && Array.isArray(data.gstinInformation)
                ? data.gstinInformation.map((item) => ({
                    gstinNumber: item.gstinNumber
                  }))
                : []
          }
        : {
            uinNumber: isNotEmpty(data?.uinNumber) ? data.uinNumber : null
          }),
      companyName: isNotEmpty(data?.companyName) ? data.companyName : null,
      companyOverview: isNotEmpty(data?.companyOverview) ? data.companyOverview : null,
      establishmentYear: parseNumber(data?.establishmentYear),
      bussinessScaleId: parseNumber(data?.bussinessScaleId),
      annualRevenue: parseNumber(data?.annualRevenue),
      twitterId: isNotEmpty(data?.twitterId) ? data.twitterId : null,
      linkedInId: isNotEmpty(data?.linkedInId) ? data.linkedInId : null,
      facebookId: isNotEmpty(data?.facebookId) ? data.facebookId : null,
      contactDetails: Array.isArray(data?.contactDetails)
        ? data.contactDetails.map((item) => ({
            contactPersonName: isNotEmpty(item.contactPersonName) ? item.contactPersonName : null,
            contactPersonEmail: isNotEmpty(item.contactPersonEmail) ? item.contactPersonEmail : null,
            contactPersonWhatsappNumber: isNotEmpty(item.contactPersonWhatsappNumber) ? item.contactPersonWhatsappNumber : null,
            contactPersonDesignation: isNotEmpty(item.contactPersonDesignation) ? item.contactPersonDesignation : null,
            contactPersonVerificationToken: item.contactVerificationToken || null,
            isContactPersonVerified: item.isContactPersonVerified || false,
            contactPersonType: item.contactPersonType
          }))
        : [],
      logoUrl: null,
      awardUrls: []
    }

    const orgFormDraft = new FormData()
    orgFormDraft.append('data', JSON.stringify(payload))
    orgFormDraft.append('logo', orgLogo)

    orgAwards.forEach((award, index) => {
      orgFormDraft.append(`awards${index + 1}`, award.file)
    })

    dispatch(saveOrgInfoAsDraft(orgFormDraft))
  }

  const handleOperationalNext = (data) => {
    const isNotEmpty = (value) => value && value !== ''
    const parseNumber = (value) => (isNotEmpty(value) ? parseInt(value) : null)

    const payload = {
      manufacturingInformation: data.manufacturingLocations.map((item) => ({
        manufacturingCountryId: parseNumber(item.country),
        manufacturingStateId: parseNumber(item.state),
        manufacturingCityId: parseNumber(item.city),
        manufacturingAddress: isNotEmpty(item.address) ? item.address : null,
        manufacturingPinCode: parseNumber(item.pinCode)
      })),
      productionCapacityInformation: data.productionCapacities.map((item) => ({
        materialName: isNotEmpty(item.materialName) ? item.materialName : null,
        productionCapacity: parseNumber(item.capacity),
        uomId: parseNumber(item.uom)
      })),
      natureOfBussinessId: parseNumber(data.natureOfBussiness),
      countriesDoingBussinessIn: data.countriesDoingBussinessIn,
      top10Buyers: data.top10Buyers,
      totalNumberOfEmployees: parseNumber(data.employeesNumber),
      whyUs: isNotEmpty(data.whyUs) ? data.whyUs : null,
      year1: parseNumber(financialYear),
      year1Turnover: parseNumber(data.year1Turnover),
      year2: parseInt(financialYear) - 1,
      year2Turnover: parseNumber(data.year2Turnover),
      year3: parseInt(financialYear) - 2,
      year3Turnover: parseNumber(data.year3Turnover),
      creditRating: isNotEmpty(data.creditRating) ? data.creditRating : null,
      isOEMService: isNotEmpty(data.oemService) ? data.oemService === 'Y' : null,
      subsidaries: data.subsidiaries.map((item) => item.name),
      materialCategory: data.itemCategories.map((item) => ({
        hsnCategoryId: parseNumber(item.category),
        valueOfOrderSupplied: parseNumber(item.value),
        currency: isNotEmpty(item.currency) ? item.currency : null,
        capacity: parseNumber(item.capacity),
        uomId: parseNumber(item.uom),
        topBuyers: item.topBuyers
      }))
    }

    const opFormDraft = new FormData()
    opFormDraft.append('data', JSON.stringify(payload))

    opBrochures.forEach((brochure, index) => {
      opFormDraft.append(`brochures${index + 1}`, brochure.file)
    })

    opPatents.forEach((patent, index) => {
      opFormDraft.append(`patents${index + 1}`, patent.file)
    })

    opTradeMarks.forEach((trademark, index) => {
      opFormDraft.append(`trademarks${index + 1}`, trademark.file)
    })

    dispatch(saveOpInfoAsDraft(opFormDraft)).then((success) => {
      if (success) {
        setCurrentStep((prev) => (prev < steps.length ? prev + 1 : prev))
      }
    })
  }

  const handleOperationalDraft = () => {
    const data = opGetValues()

    const isNotEmpty = (value) => value && value !== ''
    const parseNumber = (value) => (isNotEmpty(value) ? parseInt(value) : null)

    const payload = {
      manufacturingInformation: data.manufacturingLocations.map((item) => ({
        manufacturingCountryId: parseNumber(item.country),
        manufacturingStateId: parseNumber(item.state),
        manufacturingCityId: parseNumber(item.city),
        manufacturingAddress: isNotEmpty(item.address) ? item.address : null,
        manufacturingPinCode: parseNumber(item.pinCode)
      })),
      productionCapacityInformation: data.productionCapacities.map((item) => ({
        materialName: isNotEmpty(item.materialName) ? item.materialName : null,
        productionCapacity: parseNumber(item.capacity),
        uomId: parseNumber(item.uom)
      })),
      natureOfBussinessId: parseNumber(data.natureOfBussiness),
      countriesDoingBussinessIn: data.countriesDoingBussinessIn,
      top10Buyers: data.top10Buyers,
      totalNumberOfEmployees: parseNumber(data.employeesNumber),
      whyUs: isNotEmpty(data.whyUs) ? data.whyUs : null,
      year1: parseNumber(financialYear),
      year1Turnover: parseNumber(data.year1Turnover),
      year2: parseInt(financialYear) - 1,
      year2Turnover: parseNumber(data.year2Turnover),
      year3: parseInt(financialYear) - 2,
      year3Turnover: parseNumber(data.year3Turnover),
      creditRating: isNotEmpty(data.creditRating) ? data.creditRating : null,
      isOEMService: isNotEmpty(data.oemService) ? data.oemService === 'Y' : null,
      subsidaries: data.subsidiaries.map((item) => item.name),
      materialCategory: data.itemCategories.map((item) => ({
        hsnCategoryId: parseNumber(item.category),
        valueOfOrderSupplied: parseNumber(item.value),
        currency: isNotEmpty(item.currency) ? item.currency : null,
        capacity: parseNumber(item.capacity),
        uomId: parseNumber(item.uom),
        topBuyers: item.topBuyers
      }))
    }

    const opFormDraft = new FormData()
    opFormDraft.append('data', JSON.stringify(payload))

    opBrochures.forEach((brochure, index) => {
      opFormDraft.append(`brochures${index + 1}`, brochure.file)
    })

    opPatents.forEach((patent, index) => {
      opFormDraft.append(`patents${index + 1}`, patent.file)
    })

    opTradeMarks.forEach((trademark, index) => {
      opFormDraft.append(`trademarks${index + 1}`, trademark.file)
    })

    dispatch(saveOpInfoAsDraft(opFormDraft))
  }

  const handlePublishProfile = (data) => {
    const isNotEmpty = (value) => value && value !== ''
    const parseNumber = (value) => (isNotEmpty(value) ? parseInt(value) : null)

    const payload = {
      materials: data.materials.map((item) => ({
        materialName: isNotEmpty(item.materialName) ? item.materialName : null,
        hsnCategoryId: parseNumber(item.hsnCategoryId),
        orderQuantity: parseNumber(item.orderQuantity),
        uomId: parseNumber(item.uom),
        materialDescription: isNotEmpty(item.materialDescription) ? item.materialDescription : null
      }))
    }

    const itemFormDraft = new FormData()
    itemFormDraft.append('data', JSON.stringify(payload))

    itemCertifications.forEach((certification, index) => {
      itemFormDraft.append(`certifications${index + 1}`, certification.file)
    })

    dispatch(publishProfile(itemFormDraft)).then((res) => {
      if (res) {
        toast.success('Profile Published Successfully')
      }
    })
  }

  const handleItemDraft = () => {
    const data = itemGetValues()

    const isNotEmpty = (value) => value && value !== ''
    const parseNumber = (value) => (isNotEmpty(value) ? parseInt(value) : null)

    const payload = {
      materials: data.materials.map((item) => ({
        materialName: isNotEmpty(item.materialName) ? item.materialName : null,
        hsnCategoryId: parseNumber(item.hsnCategoryId),
        orderQuantity: parseNumber(item.orderQuantity),
        uomId: parseNumber(item.uom),
        materialDescription: isNotEmpty(item.materialDescription) ? item.materialDescription : null
      }))
    }

    const itemFormDraft = new FormData()
    itemFormDraft.append('data', JSON.stringify(payload))

    itemCertifications.forEach((certification, index) => {
      itemFormDraft.append(`certifications${index + 1}`, certification.file)
    })

    dispatch(saveItemInfoAsDraft(itemFormDraft))
  }

  const tabPanels = {
    1: (
      <OrganizationForm
        watch={orgWatch}
        errors={orgErrors}
        control={orgControl}
        register={orgRegister}
        setValue={orgSetValue}
        getValues={orgGetValues}
        handleSubmit={orgHandleSubmit}
        contactErrors={contactErrors}
        contactControl={contactControl}
        contactSetValue={contactSetValue}
        contactHandleSubmit={contactHandleSubmit}
        changeOrgLogoHandler={changeOrgLogoHandler}
        orgAwards={orgAwards}
        setOrgAwards={setOrgAwards}
      />
    ),
    2: (
      <OperationForm
        watch={opWatch}
        errors={opErrors}
        register={opRegister}
        control={opControl}
        setValue={opSetValue}
        handleSubmit={opHandleSubmit}
        opBrochures={opBrochures}
        setOpBrochures={setOpBrochures}
        opTradeMarks={opTradeMarks}
        setOpTradeMarks={setOpTradeMarks}
        opPatents={opPatents}
        setOpPatents={setOpPatents}
        keyPartnership={orgWatch('keyPartnership')}
      />
    ),
    3: (
      <MaterialForm
        watch={itemWatch}
        errors={itemErrors}
        control={itemControl}
        register={itemRegister}
        itemCertifications={itemCertifications}
        setItemCertifications={setItemCertifications}
      />
    )
  }

  const getStepStyle = (stepId) => {
    if (stepId < currentStep)
      return {
        backgroundColor: 'green',
        color: '#fff',
        fontSize: '20px',
        border: '2px solid green'
      }
    if (stepId === currentStep)
      return {
        backgroundColor: '#007bff',
        color: '#fff',
        fontSize: '20px',
        boxShadow: '0px 0px 15px rgba(255, 255, 255, 0.65)'
      }
    return {
      backgroundColor: '#fff',
      color: '#000',
      fontSize: '20px',
      boxShadow: '0px 0px 5px rgba(0, 0, 0, 0.1)',
      border: '2px solid #ccc'
    }
  }

  const getCircleSize = (stepId) => {
    return stepId === currentStep ? '60px' : '60px'
  }

  const getLineStyle = (stepId) => {
    return {
      backgroundColor: stepId < currentStep ? 'green' : stepId === currentStep ? '#007bff' : '#fff',
      width: '4px',
      height: '40px',
      margin: '0 auto',
      boxShadow: stepId < currentStep ? '0px 0px 5px rgba(0, 128, 0, 0.5)' : '0px 0px 5px rgba(0, 123, 255, 0.5)'
    }
  }

  const calculateFinancialYear = () => {
    const currentDate = new Date()
    const currentMonth = currentDate.getMonth()
    const currentYear = currentDate.getFullYear()

    let startYear
    if (currentMonth < 3) {
      startYear = currentYear - 2
    } else {
      startYear = currentYear - 1
    }

    return `${startYear}`
  }

  useEffect(() => {
    setFinancialYear(calculateFinancialYear())
  }, [])

  useEffect(() => {
    if (currentStep === 1) {
      dispatch(fetchOrgInfoBeforePublishing()).then((res) => {
        const countryId = res?.draftOrganizationInfo?.countryId || ''
        const stateId = res?.draftOrganizationInfo?.stateId || ''
        const cityId = res?.draftOrganizationInfo?.cityId || ''

        if (countryId !== '' && !states[countryId]) {
          dispatch(fetchStateList(countryId))
        }

        if (countryId !== '' && stateId !== '' && !cities[`${countryId}-${stateId}`]) {
          dispatch(fetchCityList(countryId, stateId))
        }

        orgSetValue('countryId', countryId)
        orgSetValue('stateId', stateId)
        orgSetValue('cityId', cityId)
        orgSetValue('panNumber', res?.draftOrganizationInfo?.panNumber || '')
        orgSetValue('panHolderName', res?.draftOrganizationInfo?.panHolderName || '')
        orgSetValue('panHolderDOB', res?.draftOrganizationInfo?.panHolderDOB || '')
        orgSetValue('companyName', res?.draftOrganizationInfo?.companyName || '')
        orgSetValue('hasGstin', res?.draftGstinInformation?.length > 0 ? 'Y' : 'N')
        orgSetValue(
          'gstinInformation',
          (res?.draftGstinInformation || []).map((gstin) => ({ gstinNumber: gstin.gstinNumber }))
        )
        orgSetValue('isMsme', res?.draftOrganizationInfo?.msmeNumber && res?.draftOrganizationInfo?.msmeNumber !== '' ? 'Y' : 'N')
        orgSetValue('msmeNumber', res?.draftOrganizationInfo?.msmeNumber || '')
        orgSetValue('companyOverview', res?.draftOrganizationInfo?.companyDescription || '')
        orgSetValue('establishmentYear', res?.draftOrganizationInfo?.yearOfEstablishment || '')
        orgSetValue('bussinessScaleId', res?.draftOrganizationInfo?.scaleOfBussinessId || '')
        orgSetValue('annualRevenue', res?.draftOrganizationInfo?.annualRevenue || '')
        orgSetValue('twitterId', res?.draftOrganizationInfo?.twitterId || '')
        orgSetValue('linkedInId', res?.draftOrganizationInfo?.linkedInId || '')
        orgSetValue('facebookId', res?.draftOrganizationInfo?.facebookId || '')
        orgSetValue(
          'contactDetails',
          (res?.draftContactDetails && res?.draftContactDetails.length > 0 ? res?.draftContactDetails : [{}]).map((item) => ({
            contactPersonName: item.contactName || '',
            contactPersonEmail: item.contactEmail || '',
            contactPersonWhatsappNumber: item.contactWhatsappNumber || '',
            contactPersonDesignation: item.contactPersonDesignation || '',
            isContactPersonVerified: item.isOtpVerified || false,
            contactVerificationToken: item.contactVerificationToken || null,
            contactPersonType: item.contactType || CONTACT_TYPE.PRIMARY
          }))
        )
        contactSetValue(
          'contactDetails',
          (res?.draftContactDetails && res?.draftContactDetails.length > 0 ? res?.draftContactDetails : [{}]).map((item) => ({
            contactPersonEmail: item.contactEmail || '',
            contactPersonWhatsappNumber: item.contactWhatsappNumber || '',
            isContactPersonVerified: item.isOtpVerified || false,
            contactVerificationToken: null,
            contactPersonType: item.contactType
          }))
        )
      })
    } else if (currentStep === 2) {
      dispatch(fetchOpInfoBeforePublishing()).then(async (res) => {
        const fetchPromises = res?.draftMfgLocationsInfo.map((item) => {
          const countryId = item.countryId
          const stateId = item.stateId
          const promises = []

          if (countryId !== '' && !states[countryId]) {
            promises.push(dispatch(fetchStateList(countryId)))
          }

          if (countryId !== '' && stateId !== '' && !cities[`${countryId}-${stateId}`]) {
            promises.push(dispatch(fetchCityList(countryId, stateId)))
          }

          return Promise.all(promises)
        })

        await Promise.all(fetchPromises)

        opSetValue(
          'manufacturingLocations',
          (res?.draftMfgLocationsInfo || [{}]).map((item) => ({
            country: item.countryId || '',
            state: item.stateId || '',
            city: item.cityId || '',
            address: item.address || '',
            pinCode: item.pinCode || ''
          }))
        )

        opSetValue(
          'productionCapacities',
          (res?.draftProductionCapacity || [{}]).map((item) => ({
            materialName: item.materialName || '',
            capacity: item.productionCapacity || '',
            uom: item.uomId || ''
          }))
        )

        opSetValue('natureOfBussiness', res?.draftOperationalInfo?.natureOfBussinessId || '')

        opSetValue('countriesDoingBussinessIn', res?.draftOperationalInfo?.countriesDoingBussinessIn || [])
        opSetValue('top10Buyers', res?.draftOperationalInfo?.top10Buyer)
        opSetValue('employeesNumber', res?.draftOperationalInfo?.totalNumberOfEmployees || '')
        opSetValue('whyUs', res?.draftOperationalInfo?.whyUs || '')
        opSetValue('year1Turnover', res?.draftOperationalInfo?.year1Turnover || '')
        opSetValue('year2Turnover', res?.draftOperationalInfo?.year2Turnover || '')
        opSetValue('year3Turnover', res?.draftOperationalInfo?.year3Turnover || '')
        opSetValue('creditRating', res?.draftOperationalInfo?.creditRating || '')
        opSetValue('isOEMService', res?.draftOperationalInfo?.isOEMService)

        opSetValue(
          'subsidiaries',
          (res?.draftSubsidaries || []).map((item) => ({ name: item.subsideriesName }))
        )

        opSetValue(
          'itemCategories',
          (res?.draftMaterialCategory || [{}]).map((item) => ({
            category: item.hsnCategoryId || '',
            value: item.valueOfOrderSupplied || '',
            currency: item.currency || '',
            capacity: item.capacity || '',
            uom: item.uomId || '',
            topBuyers: item.topBuyers
          }))
        )
      })
    } else if (currentStep === 3) {
      dispatch(fetchItemInfoBeforePublishing()).then((res) => {
        itemSetValue(
          'materials',
          (res?.draftMaterials || [{}]).map((item) => ({
            materialName: item.materialName || '',
            hsnCategoryId: item.hsnCategoryId || '',
            orderQuantity: item.minimumOrderQuantity || '',
            uom: item.uomId || '',
            materialDescription: item.materialDescription || ''
          }))
        )
      })
    }
  }, [currentStep])

  return (
    <>
      {isLoading && <Spinner />}

      <div className="registrationLayout">
        <Container
          fluid
          className="p-2 px-0 h-100">
          <Row className="h-100 w-100 m-auto">
            <Col
              md={4}
              lg={4}
              className="h-100 px-2">
              <Card className="cardTemplate_Left">
                <div className="logoArea">
                  <img
                    src={mjPRO_Logo}
                    alt="mjPRO Logo"
                  />
                </div>
                <CardText
                  className="display-5 text-light mb-2"
                  style={{ lineHeight: '1' }}>
                  Welcome to mjPROConnect
                </CardText>
                <CardText className="text-light fw-bold fs-1 mb-1">Let’s Get You Started</CardText>
                <CardText className="text-light fs-2 mb-2">Complete the registration process to be a verified vendor</CardText>
                <div className="StepperStart">
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ display: 'flex', flexDirection: 'column', marginTop: '30px' }}>
                      {steps.map((step, index) => (
                        <div
                          key={step.id}
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            marginBottom: index !== steps.length - 1 ? '20px' : '0'
                          }}>
                          <div style={{ position: 'relative' }}>
                            <div
                              style={{
                                width: getCircleSize(step.id),
                                height: getCircleSize(step.id),
                                borderRadius: '50%',
                                border: '2px solid #007bff',
                                display: 'flex',
                                justifyContent: 'center',
                                alignItems: 'center',
                                fontWeight: 'bold',
                                cursor: 'pointer',
                                transition: 'all 0.3s ease',
                                ...getStepStyle(step.id)
                              }}>
                              {step.id < currentStep ? <TiTick style={{ fontSize: '26px' }} /> : step.id}
                            </div>

                            {/* Line Connector */}
                            {index !== steps.length - 1 && (
                              <div
                                style={{
                                  position: 'absolute',
                                  top: getCircleSize(step.id),
                                  left: '50%',
                                  transform: 'translateX(-50%)',
                                  ...getLineStyle(step.id + 1)
                                }}
                              />
                            )}
                          </div>

                          {/* Step Capsule */}
                          <div
                            className="step-capsule"
                            style={{
                              ...getStepStyle(step.id)
                            }}>
                            {step.title}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </Card>
            </Col>
            <Col
              md={8}
              lg={8}
              className="h-100 px-2">
              {/* Tab Panel Content */}
              <div className="dataForm_container GlossBg">
                <Card className="dataForm_card">{tabPanels[currentStep]}</Card>
                <CardFooter className="dataForm_cardFooter">
                  <Row>
                    <Col sm={6}>
                      <Button
                        color="prev-btn"
                        onClick={() => setCurrentStep((prev) => (prev > 1 ? prev - 1 : prev))}
                        disabled={currentStep === 1}>
                        Previous
                      </Button>
                      &nbsp;
                      {currentStep === 1 && (
                        <Button
                          color="next-btn"
                          onClick={orgHandleSubmit(handleOrganizationalNext)}
                          disabled={currentStep === steps.length}>
                          Next
                        </Button>
                      )}
                      {currentStep === 2 && (
                        <Button
                          color="next-btn"
                          onClick={opHandleSubmit(handleOperationalNext)}
                          disabled={currentStep === steps.length}>
                          Next
                        </Button>
                      )}
                      {currentStep === 3 && (
                        <Button
                          color="next-btn"
                          disabled={currentStep === steps.length}>
                          Next
                        </Button>
                      )}
                    </Col>
                    <Col
                      sm={6}
                      className="text-end">
                      {currentStep === 1 && (
                        <Button
                          color="draft-btn"
                          onClick={handleOrganizationalDraft}>
                          Save as Draft
                        </Button>
                      )}
                      {currentStep === 2 && (
                        <Button
                          color="draft-btn"
                          onClick={handleOperationalDraft}>
                          Save as Draft
                        </Button>
                      )}
                      {currentStep === 3 && (
                        <Button
                          color="draft-btn"
                          onClick={handleItemDraft}>
                          Save as Draft
                        </Button>
                      )}
                      &nbsp;
                      <Button
                        color="submit-btn"
                        disabled={currentStep !== 3}
                        onClick={itemHandleSubmit(handlePublishProfile)}>
                        Submit
                      </Button>
                    </Col>
                  </Row>
                </CardFooter>
              </div>
              {/* Navigation Buttons */}
              <div style={{ marginTop: '20px' }}></div>
            </Col>
          </Row>
        </Container>
      </div>
    </>
  )
}

export default Profiling
