import React from 'react'
import { MdStars } from 'react-icons/md'
import { MdShoppingBasket } from 'react-icons/md'
import { MdOutlineRedeem } from 'react-icons/md'
import { MdLocalActivity } from 'react-icons/md'
import { Row, Col, Card, CardText, CardBody, Container } from 'reactstrap'

export default function LandingKpi() {
  return (
    <div>
      <Container
        fluid
        className="landing-kpi__container-fluid">
        <Row className="flex-row landing-kpi__container">
          <Col
            xs="6"
            md="3"
            lg="6"
            className="p-2">
            <Card className="landing-kpi__card GlossBg m-0">
              <MdShoppingBasket className="landing-kpi__icon" />
              <CardBody className="p-0 w-100">
                <CardText className="mb-2">
                  <small className="text-light">Connect with</small>
                </CardText>
                <CardText className="d-flex flex-column justify-content-center align-items-center">
                  <span className="text-light fw-bold align-self-start">500+</span>{' '}
                  <span className="text-light text-custom-1 align-self-start">Buyers</span>
                </CardText>
              </CardBody>
            </Card>
          </Col>
          <Col
            xs="6"
            md="3"
            lg="6"
            className="p-2">
            <Card className="landing-kpi__card GlossBg m-0">
              <MdStars className="landing-kpi__icon" />
              <CardBody className="p-0 w-100">
                <CardText className="mb-2">
                  <small className="text-light">Experience</small>
                </CardText>
                <CardText className="d-flex flex-column justify-content-center align-items-center">
                  <div>
                    <span className="text-light fw-bold">20+</span> <span className="text-light text-custom-1 align-self-end">Years</span>
                  </div>
                </CardText>
              </CardBody>
            </Card>
          </Col>
          <Col
            xs="6"
            md="3"
            lg="6"
            className="p-2">
            <Card className="landing-kpi__card GlossBg m-0">
              <MdOutlineRedeem className="landing-kpi__icon" />
              <CardBody className="p-0 w-100">
                <CardText className="mb-2">
                  <small className="text-light">Annual Buys</small>
                </CardText>
                <CardText className="d-flex flex-column justify-content-center align-items-center">
                  <div className="">
                    <span className="text-light fw-bold">60K+</span>
                    <span className="text-light text-custom-1 align-self-end">Cr</span>
                  </div>
                  {/* <span className="text-light text-custom-1 align-self-end">Cr</span> */}
                </CardText>
              </CardBody>
            </Card>
          </Col>
          <Col
            xs="6"
            md="3"
            lg="6"
            className="p-2">
            <Card className="landing-kpi__card GlossBg m-0">
              <MdLocalActivity className="landing-kpi__icon" />
              <CardBody className="p-0 w-100">
                <CardText className="mb-2">
                  <small className="text-light">Annual</small>
                </CardText>
                <CardText className="d-flex flex-column justify-content-center align-items-center">
                  <div>
                    {' '}
                    <span className="text-light fw-bold">40K+</span> <span className="text-light text-custom-1 align-self-end">RFQ</span>
                  </div>
                </CardText>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  )
}
