import React, { useState } from 'react'
import { Card, CardBody, Button, Row, Col, AccordionBody, AccordionHeader, Accordion, AccordionItem } from 'reactstrap'

const FAQ = () => {
  const [open, setOpen] = useState('0')
  const toggle = (id) => {
    if (open === id) {
      setOpen()
    } else {
      setOpen(id)
    }
  }

  return (
    <div>
      <Row className="mb-3">
        <Col>
          <h1 className="display-5 text-white fw-medium text-lg-start mb-2">Frequently Asked Questions</h1>
        </Col>
      </Row>

      <Row className="">
        <Accordion
          open={open}
          toggle={toggle}
          // flush
          className="faq-accordion__container">
          <AccordionItem className="faq-accordion__item">
            <AccordionHeader
              targetId="1"
              className="faq-accordion__header">
              What is mjPROConnect?
            </AccordionHeader>
            <AccordionBody
              accordionId="1"
              className="faq-accordion__body">
              mjPROConnect is a B2B eMarketplace that enables suppliers to showcase their business, improve visibility through profiling, and promote
              products/services through advertisements.
            </AccordionBody>
          </AccordionItem>
          <AccordionItem className="faq-accordion__item">
            <AccordionHeader
              targetId="2"
              className="faq-accordion__header">
              How do I register on mjPROConnect?
            </AccordionHeader>
            <AccordionBody
              accordionId="2"
              className="faq-accordion__body">
              Click on "Register", verify your mobile & email, and choose a subscription plan to complete registration.
            </AccordionBody>
          </AccordionItem>
          <AccordionItem className="faq-accordion__item">
            <AccordionHeader
              targetId="3"
              className="faq-accordion__header">
              Is mjPROConnect free to use?
            </AccordionHeader>
            <AccordionBody
              accordionId="3"
              className="faq-accordion__body">
              No, mjPROConnect requires a subscription. Pricing plan is available based on features like ad slots and visibility enhancements.
            </AccordionBody>
          </AccordionItem>
          <AccordionItem className="faq-accordion__item">
            <AccordionHeader
              targetId="4"
              className="faq-accordion__header">
              What is Supplier Profiling in mjPROConnect?
            </AccordionHeader>
            <AccordionBody
              accordionId="4"
              className="faq-accordion__body">
              Supplier Profiling allows businesses to create a detailed company profile, showcasing their products, certifications, social media
              presence, and more.
            </AccordionBody>
          </AccordionItem>
          <AccordionItem className="faq-accordion__item">
            <AccordionHeader
              targetId="5"
              className="faq-accordion__header">
              How can I improve my profile visibility?
            </AccordionHeader>
            <AccordionBody
              accordionId="5"
              className="faq-accordion__body">
              ✔ Fill in all required details
              <br />✔ Add your products and services
              <br />✔ Keep your information updated
              <br />✔ Post advertisements regularly
            </AccordionBody>
          </AccordionItem>
          <AccordionItem className="faq-accordion__item">
            <AccordionHeader
              targetId="6"
              className="faq-accordion__header">
              Can I edit my profile after registration?
            </AccordionHeader>
            <AccordionBody
              accordionId="6"
              className="faq-accordion__body">
              Yes, non-mandatory fields can be edited anytime. However, core details like PAN And company name cannot be changed after registration.
            </AccordionBody>
          </AccordionItem>
          <AccordionItem className="faq-accordion__item">
            <AccordionHeader
              targetId="7"
              className="faq-accordion__header">
              What is the Ad Management feature in mjPROConnect?
            </AccordionHeader>
            <AccordionBody
              accordionId="7"
              className="faq-accordion__body">
              The Ad Management feature lets suppliers promote their products and services by posting advertisements that buyers can view.
            </AccordionBody>
          </AccordionItem>
          <AccordionItem className="faq-accordion__item">
            <AccordionHeader
              targetId="8"
              className="faq-accordion__header">
              How many ads can I post?
            </AccordionHeader>
            <AccordionBody
              accordionId="8"
              className="faq-accordion__body">
              Your ad slots depend on your subscription plan. Each ad slot allows one active advertisement at a time.
            </AccordionBody>
          </AccordionItem>
          <AccordionItem className="faq-accordion__item">
            <AccordionHeader
              targetId="9"
              className="faq-accordion__header">
              What happens when I use all my ad slots?
            </AccordionHeader>
            <AccordionBody
              accordionId="9"
              className="faq-accordion__body">
              If all slots are used, you can delete an existing ad to free up a slot for a new one.
            </AccordionBody>
          </AccordionItem>
          <AccordionItem className="faq-accordion__item">
            <AccordionHeader
              targetId="10"
              className="faq-accordion__header">
              Can I Track my ad performance?
            </AccordionHeader>
            <AccordionBody
              accordionId="10"
              className="faq-accordion__body">
              Yes, You can view impressions, clicks, and engagement analytics in the Ad Management Dashboard.
            </AccordionBody>
          </AccordionItem>
          <AccordionItem className="faq-accordion__item">
            <AccordionHeader
              targetId="11"
              className="faq-accordion__header">
              Can I upgrade my plan later?
            </AccordionHeader>
            <AccordionBody
              accordionId="11"
              className="faq-accordion__body">
              Yes, you can upgrade anytime from "My Plan." The new plan will be activated immediately.
            </AccordionBody>
          </AccordionItem>
          <AccordionItem className="faq-accordion__item">
            <AccordionHeader
              targetId="12"
              className="faq-accordion__header">
              Who do I contact for support?
            </AccordionHeader>
            <AccordionBody
              accordionId="12"
              className="faq-accordion__body">
              You can reach out to our helpdesk via:
              <br /> 📧 Email: [Helpdesk Email]
              <br /> 📞 Phone: [Helpdesk Number]
            </AccordionBody>
          </AccordionItem>
        </Accordion>
      </Row>
    </div>
  )
}

export default FAQ
